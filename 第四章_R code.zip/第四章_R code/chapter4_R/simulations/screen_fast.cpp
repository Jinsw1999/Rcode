#include <Rcpp.h>
#include <cmath>
using namespace Rcpp;

// Computes the same grouped left-limit product and reverse cumulative risks
// as local_km_from_gram in cHSIC.R. No RNG is used here.
// [[Rcpp::export]]
NumericVector native_local_km(NumericMatrix K, List plan) {
  const int n = K.nrow();
  IntegerVector ord = plan["ord"], starts = plan["starts"];
  NumericVector values = plan["values"], eval_time = plan["eval_time"];
  LogicalVector censored = plan["censored"];
  List groups = plan["groups"];
  if (K.ncol() != n || ord.size() != n || eval_time.size() != n)
    stop("Incompatible local KM dimensions.");
  NumericMatrix risk(n, n);
  NumericVector ans(n, 1.0);
  for (int col = 0; col < n; ++col) {
    long double s = 0.0L;
    for (int row = n - 1; row >= 0; --row) {
      s += K(ord[row] - 1, col);
      risk(row, col) = static_cast<double>(s);
    }
  }
  for (int g = 0; g < groups.size(); ++g) {
    IntegerVector ix = groups[g];
    bool has_event = false;
    for (int j = 0; j < ix.size(); ++j)
      if (censored[ix[j] - 1]) { has_event = true; break; }
    if (!has_event) continue;
    for (int col = 0; col < n; ++col) {
      if (!(values[g] < eval_time[col])) continue;
      double denom = risk(starts[g] - 1, col);
      if (!std::isfinite(denom) || denom <= 0)
        stop("Nonpositive local risk mass at an eligible sample evaluation point.");
      long double sum = 0.0L;
      for (int j = 0; j < ix.size(); ++j) {
        int row = ix[j] - 1;
        if (censored[row]) sum += K(ord[row] - 1, col);
      }
      double jump = static_cast<double>(sum) / denom;
      if (jump > 1 + 1e-10 || jump < -1e-10) stop("Invalid KM jump.");
      jump = std::min(1.0, std::max(0.0, jump));
      ans[col] *= (1.0 - jump);
    }
  }
  for (int col = 0; col < n; ++col)
    ans[col] = std::min(1.0, std::max(0.0, ans[col]));
  return ans;
}

using namespace Rcpp;

double whsic_cpp(const NumericMatrix &A,const NumericMatrix &B,const NumericVector &W) {
 int n=W.size(); double m=0,M=0;
 for(int i=0;i<n;++i){m+=W[i];M+=W[i]*W[i];}
 NumericVector ai(n),bi(n),a2(n),b2(n);
 double s1=0;
 for(int j=0;j<n;++j) for(int i=0;i<n;++i) {
   double wi=W[i],wj=W[j],a=A(i,j),b=B(i,j);
   ai[i]+=a*wj;bi[i]+=b*wj;a2[i]+=a*wj*wj;b2[i]+=b*wj*wj;
   s1+=wi*wj*a*b*(m*m-M-m*(wi+wj)+2*wi*wj);
 }
 double sa=0,sb=0,res=s1;
 for(int i=0;i<n;++i){double w=W[i];res+=-2*w*(m+w)*ai[i]*bi[i]+2*w*a2[i]*bi[i]+2*w*ai[i]*b2[i];sa+=w*ai[i];sb+=w*bi[i];}
 return (res+sa*sb)/(double(n)*(n-1)*(n-2)*(n-3));
}
// [[Rcpp::export]]
List screen_fast_cpp(NumericMatrix X, NumericMatrix B,
 NumericMatrix V,NumericMatrix Ds,List plan1,List plan2,double h,double gs,bool common,double sigma_x=1) {
 int n=X.nrow(),p=X.ncol();
 NumericMatrix scores(p,3),diagnostics(p,6);
 const double norm=1.0/(std::sqrt(2.0*M_PI)*sigma_x);
 for(int k=0;k<p;++k) {
  if(k%50==0)checkUserInterrupt();
  NumericMatrix K(n,n),A(n,n);
  for(int j=0;j<n;++j)for(int i=0;i<n;++i){double d=X(i,k)-X(j,k);K(i,j)=std::exp(-d*d/(2*h*h));A(i,j)=i==j?0:std::exp(-d*d/(2*sigma_x*sigma_x))*norm;}
  NumericVector g1=native_local_km(K,plan1),g2=native_local_km(K,plan2),W(n),W1(n),W2(n),rank(n);
  double clip=0,cclip=0,complete=0,maxw=0,ming=1,sw=0,sw2=0;
  for(int i=0;i<n;++i){double g=common?std::min(g1[i],g2[i]):g1[i]*g2[i],d=Ds(i,0)*Ds(i,1);
   W[i]=d/std::max(g,gs);W1[i]=Ds(i,0)/std::max(g1[i],gs);W2[i]=Ds(i,1)/std::max(g2[i],gs);
   clip+=(g<gs);cclip+=d*(g<gs);complete+=d;maxw=std::max(maxw,W[i]);ming=std::min(ming,g);sw+=W[i];sw2+=W[i]*W[i];
   int r=0;for(int j=0;j<n;++j)r+=(X(j,k)<=X(i,k));rank[i]=double(r)/n;
  }
  scores(k,0)=whsic_cpp(A,B,W);
  double cs[2]={0,0},rs[2]={0,0};
  for(int s=0;s<2;++s)for(int j=0;j<n;++j){double a=0,b=0;
    for(int i=0;i<n;++i)if(V(i,s)<=V(j,s)){double w=s==0?W1[i]:W2[i];a+=w*X(i,k);b+=w*(rank[i]-.5);}
    cs[s]+=std::abs(a)/(double(n)*n);rs[s]+=std::abs(b)/(double(n)*n);
  }
  scores(k,1)=cs[0]*cs[0]+cs[1]*cs[1];scores(k,2)=rs[0]*rs[0]+rs[1]*rs[1];
  diagnostics(k,0)=clip/n;diagnostics(k,1)=complete>0?cclip/complete:0;diagnostics(k,2)=maxw;diagnostics(k,3)=ming;diagnostics(k,4)=sw2>0?sw*sw/sw2:0;diagnostics(k,5)=sw/n;
 }
 return List::create(_["scores"]=scores,_["diagnostics"]=diagnostics);
}
