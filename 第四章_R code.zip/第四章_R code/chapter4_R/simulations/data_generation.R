# Both experiments use the same event model; only censoring differs.
softplus <- function(z) pmax(z, 0) + log1p(exp(-abs(z)))

gaussian_ar1 <- function(n, p, rho) {
  assert_scalar(rho, "rho", -0.99, 0.99)
  X <- matrix(rnorm(n * p), n, p)
  if (p > 1L && rho != 0) for (j in 2:p)
    X[, j] <- rho * X[, j - 1L] + sqrt(1-rho^2) * X[, j]
  X
}

generate_event_data <- function(n, p, model, rho_x=0.5, rho_e=0.5, error_sd=1) {
  if (n<4L || p<5L) stop("Use n>=4 and p>=5.")
  assert_scalar(rho_e,"rho_e",-0.99,0.99)
  assert_scalar(error_sd,"error_sd",1e-10)
  X <- gaussian_ar1(n,p,rho_x)
  e1 <- rnorm(n); e2 <- rho_e*e1 + sqrt(1-rho_e^2)*rnorm(n)
  eps <- error_sd*cbind(e1,e2)
  if (model=="song") {
    T <- cbind(softplus(log(2)-X[,1]-X[,2]+eps[,1])/2,
               softplus(log(2)-X[,3]^2-X[,4]^2+eps[,2])/2)
    active <- 1:4
  } else stop("Unknown event model.")
  if (any(!is.finite(T)) || any(T<=0)) stop("Nonpositive or non-finite event time.")
  list(X=X,T=T,epsilon=eps,active=active)
}

censor_scales <- function(X, covariate_dependent, censor_type) {
  ct <- normalize_censor_type(censor_type)
  if (!covariate_dependent) return(matrix(1,nrow(X),2))
  if (ncol(X)<22) stop("Covariate-dependent censoring needs X8,X12,X18,X22: use p>=22.")
  s1 <- exp(X[,8]+X[,12])
  s2 <- if (ct=="common") s1 else exp(X[,18]+X[,22])
  S <- cbind(s1,s2)
  if (any(!is.finite(S)) || any(S<=0)) stop("Invalid censoring scales.")
  S
}

calibrate_censor_scale <- function(pilot, target_censor, v, admin_prob,
                                   covariate_dependent, censor_type) {
  assert_scalar(v,"v",1e-8)
  assert_scalar(admin_prob,"admin_prob",1e-8,1-1e-8)
  S <- censor_scales(pilot$X,covariate_dependent,censor_type)
  T <- pilot$T
  above <- T>v
  minimum <- mean(above)
  maximum <- minimum+(1-admin_prob)*(1-minimum)
  if (!is.finite(target_censor) || target_censor<=minimum || target_censor>=maximum)
    stop("Target original-event censoring fraction is not attainable for this v and admin_prob.")
  raw_probability <- function(log_a) {
    q <- (1-admin_prob)*pmin(1,T/(exp(log_a)*S))
    q[above] <- 1
    mean(q)
  }
  objective <- function(log_a) raw_probability(log_a)-target_censor
  lo <- -20; hi <- 20
  while (objective(lo)<0 && lo> -600) lo <- lo-20
  while (objective(hi)>0 && hi<600) hi <- hi+20
  log_a <- uniroot(objective,c(lo,hi),tol=1e-11)$root
  a <- exp(log_a)
  list(a=a,pilot_raw_censor=raw_probability(log_a),
       pilot_window_missing=mean((1-admin_prob)*pmin(1,pmin(T,v)/(a*S))),
       pilot_event_cap_fraction=mean(above))
}

pilot_kernel_bandwidths <- function(model, v, rho_x, rho_e, error_sd, n=2000L, seed=571L) {
  set.seed(seed)
  dat <- generate_event_data(n,22L,model,rho_x,rho_e,error_sd)
  # One common coordinate bandwidth because every X_k has the N(0,1) marginal law.
  sx <- median(as.numeric(dist(dat$X[,1])))
  sy <- median(as.numeric(dist(pmin(dat$T,v))))
  if (!is.finite(sx) || !is.finite(sy) || min(sx,sy)<=0)
    stop("Degenerate pilot bandwidth; inspect the pilot design.")
  list(sigma_x=sx,sigma_y=sy,kernel_pilot_n=n,kernel_pilot_seed=seed)
}

full_X_censor_survival <- function(V,S,a,v,admin_prob,censor_type) {
  ct <- normalize_censor_type(censor_type)
  marginal <- admin_prob+(1-admin_prob)*pmax(1-V/(a*S),0)
  marginal[V>v] <- 0
  if (ct=="common") {
    tt <- pmax(V[,1],V[,2])
    ans <- admin_prob+(1-admin_prob)*pmax(0,1-tt/(a*S[,1]))
    ans[tt>v] <- 0
    ans
  } else marginal[,1]*marginal[,2]
}

generate_admin_observation <- function(X,T,a,v,admin_prob,covariate_dependent,censor_type) {
  assert_scalar(a,"a",1e-12)
  assert_scalar(v,"v",1e-8)
  assert_scalar(admin_prob,"admin_prob",0,1)
  ct <- normalize_censor_type(censor_type)
  n <- nrow(T); S <- censor_scales(X,covariate_dependent,ct)
  # Draw the same underlying U and Bernoulli uniforms across design cells.
  U <- matrix(runif(2L*n),n,2L)
  Z <- matrix(runif(2L*n),n,2L)
  if (ct=="common") {
    cc <- pmin(a*S[,1]*U[,1],v)
    cc[Z[,1]<admin_prob] <- v
    C <- cbind(cc,cc)
  } else {
    C <- pmin(a*S*U,v)
    C[Z<admin_prob] <- v
  }
  Y <- pmin(T,C); delta <- 1L*(T<=C)
  V <- pmin(Y,v); Ds <- 1L*((delta==1L)|(Y>=v))
  R <- pmin(T,v)
  list(Y=Y,delta=delta,V=V,Ds=Ds,D=Ds[,1]*Ds[,2],R=R,C=C,
       G_given_full_X=full_X_censor_survival(V,S,a,v,admin_prob,ct))
}

evaluate_ranking <- function(scores, active, n, tie_key) {
  p <- nrow(scores); d <- min(p, max(1L, ceiling(n / log(n))))
  ans <- vector("list", ncol(scores))
  for (j in seq_len(ncol(scores))) {
    # Independent, reproducible tie keys avoid favouring low-numbered active variables.
    ord <- order(-scores[, j], tie_key)
    ranks <- match(active, ord)
    selected <- ord[seq_len(d)]
    row <- data.frame(method = colnames(scores)[j], d = d,
                      all_selected = as.integer(all(ranks <= d)),
                      s_min = max(ranks), stringsAsFactors = FALSE)
    for (k in 1:4) row[[paste0("selected_X", k)]] <-
      if (k %in% active) as.integer(k %in% selected) else NA_integer_
    ans[[j]] <- row
  }
  do.call(rbind, ans)
}
