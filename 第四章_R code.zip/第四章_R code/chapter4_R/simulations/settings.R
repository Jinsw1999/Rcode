# Parameters shared by experiments 1 and 2.
n <- c(100L, 200L)
p <- 2000L
M <- 100L
censor_rate <- c(0.15, 0.30, 0.50)
censor_type <- c("common", "component")  # (a), (b)
workers <- 1L                            # Increase to use parallel R workers.
engine <- "auto"                         # "auto", "R", or "cpp".
seed <- 260913L

simulation_settings <- list(
  n = n, p = p, M = M, censor_rate = censor_rate, censor_type = censor_type,
  workers = workers, engine = engine, seed = seed,
  rho_x = 0.5, rho_e = 0.5, error_sd = 1,
  v = 100, admin_prob = 0.1, g_star = 0.005, h_factor = 1,
  pilot_n = 50000L, kernel_pilot_n = 2000L,
  save_scores = FALSE
)
# For a quick installation check only: n <- c(30L, 40L), p <- 30L, M <- 2L.
# Edit the parameters above before simulation_settings is constructed.
# Keep the paper settings for formal runs. Simulation d = ceiling(n/log(n)).
