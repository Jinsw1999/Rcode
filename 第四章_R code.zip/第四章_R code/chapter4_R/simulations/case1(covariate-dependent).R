if (.Platform$OS.type == "windows") invisible(Sys.setlocale("LC_CTYPE", ".UTF-8"))
# Experiment 1: all three censoring rates. Source the whole file.
local({

  files <- Filter(Negate(is.null), lapply(sys.frames(), function(x) x$ofile))
  cli <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  script <- if (length(files)) tail(files, 1)[[1]] else sub("^--file=", "", cli[1])
  directory <- dirname(normalizePath(script, winslash = "/", mustWork = TRUE))
  project <- dirname(directory)

  source(file.path(directory, "cHSIC.R"), local = TRUE, encoding = "UTF-8")
  source(file.path(directory, "data_generation.R"), local = TRUE, encoding = "UTF-8")
  source(file.path(directory, "simulation_functions.R"), local = TRUE, encoding = "UTF-8")
  source(file.path(directory, "settings.R"), local = TRUE, encoding = "UTF-8")
  run_experiment(1L, simulation_settings, project)
})
