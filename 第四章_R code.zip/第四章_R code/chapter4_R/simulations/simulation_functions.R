# Simulation execution and summaries. Model/estimators are in the adjacent files.
stable_seed <- function(...) {
  h <- 17
  for (z in utf8ToInt(paste(..., collapse = "|"))) h <- (131*h + z) %% 2147483647
  as.integer(1 + h %% 2147483646)
}

prepare_scenarios <- function(experiment, cfg) {
  stopifnot(experiment %in% 1:2, all(cfg$n >= 4), cfg$p >= 22,
            cfg$M >= 1, cfg$M == as.integer(cfg$M),
            all(cfg$censor_rate > 0 & cfg$censor_rate < 1-cfg$admin_prob),
            cfg$g_star > 0, cfg$g_star <= cfg$admin_prob^2)
  set.seed(stable_seed(cfg$seed, "calibration", "song"))
  pilot <- generate_event_data(cfg$pilot_n, 22L, "song", cfg$rho_x, cfg$rho_e, cfg$error_sd)
  band <- pilot_kernel_bandwidths("song", cfg$v, cfg$rho_x, cfg$rho_e, cfg$error_sd,
                                 cfg$kernel_pilot_n, stable_seed(cfg$seed, "kernel", "song"))
  band$calibration_pilot_seed <- stable_seed(cfg$seed, "calibration", "song")
  grid <- list()
  for (rate in cfg$censor_rate) for (ct in cfg$censor_type) {
    cal <- calibrate_censor_scale(pilot, rate, cfg$v, cfg$admin_prob, experiment == 1L, ct)
    for (nn in cfg$n) {
      row <- c(list(experiment = experiment,
                    design_id = paste0("song_", if (experiment == 1) "cov" else "nocov", round(100*rate)),
                    model = "song", covariate_dependent = experiment == 1,
                    target_censor = rate, n = nn, p = cfg$p, censor_type = ct), cal, band,
               cfg[c("rho_x","rho_e","error_sd","v","admin_prob","g_star","h_factor")],
               list(kernel_normalization = TRUE, h = cfg$h_factor * nn^(-1/5)))
      grid[[length(grid)+1L]] <- as.data.frame(row, stringsAsFactors = FALSE)
    }
  }
  grid <- do.call(rbind, grid)
  grid$scenario <- seq_len(nrow(grid))
  grid
}

run_one_replication <- function(job) {
  if (file.exists(job$file)) return(invisible(job$file))
  c <- job$config
  set.seed(job$seed)
  dat <- generate_event_data(c$n, c$p, "song", c$rho_x, c$rho_e, c$error_sd)
  obs <- generate_admin_observation(dat$X, dat$T, c$a, c$v, c$admin_prob,
                                    c$covariate_dependent, c$censor_type)
  fit <- screen_data(dat$X, obs$Y, obs$delta, c$v, c$h, c$g_star,
                     c$sigma_x, c$sigma_y, c$censor_type, TRUE)
  metrics <- evaluate_ranking(fit$scores, dat$active, c$n, runif(c$p))
  metrics$scenario <- c$scenario
  metrics$replication <- job$replication
  w <- fit$weight_diagnostics
  diagnostics <- data.frame(scenario = c$scenario, replication = job$replication,
    raw_censor_fraction = mean(1-obs$delta),
    joint_window_missing_fraction = mean(1-obs$D), complete_count = sum(obs$D),
    max_weight = max(w[,"max_weight"]), min_Ghat = min(w[,"min_Ghat"]),
    mean_complete_clip_fraction = mean(w[,"complete_clip_fraction"]),
    max_complete_clip_fraction = max(w[,"complete_clip_fraction"]),
    ESS_min = min(w[,"ESS"]), ESS_median = median(w[,"ESS"]), ESS_max = max(w[,"ESS"]))
  result <- list(config = c, seed = job$seed, metrics = metrics, diagnostics = diagnostics,
                 scores = if (job$save_scores) fit$scores else NULL)
  temp <- paste0(job$file, ".tmp-", Sys.getpid())
  saveRDS(result, temp)
  if (!file.rename(temp, job$file)) stop("Cannot save: ", job$file)
  invisible(job$file)
}

run_experiment <- function(experiment, cfg, project, out = NULL) {
  stopifnot(length(cfg$workers)==1, cfg$workers >= 1, cfg$workers == as.integer(cfg$workers),
            !anyDuplicated(cfg$n), !anyDuplicated(cfg$censor_rate), !anyDuplicated(cfg$censor_type))
  if (is.null(out)) out <- file.path(project, "simulations/results", paste0("case", experiment))
  dir.create(file.path(out, "replications"), recursive = TRUE, showWarnings = FALSE)
  engine <- setup_engine(project, cfg$engine, envir = environment(screen_data))
  old <- options(chapter4.engine = engine)
  on.exit(options(old), add = TRUE)
  files <- file.path(project, "simulations", c("cHSIC.R","screen_fast.cpp","data_generation.R","simulation_functions.R"))
  # Worker count is excluded: serial and parallel runs use identical per-replicate seeds.
  signature <- list(experiment = experiment, config = cfg[setdiff(names(cfg),c("workers","engine"))],
                    engine = engine, R = as.character(getRversion()),
                    code = setNames(unname(tools::md5sum(files)), basename(files)))
  sf <- file.path(out, "run_signature.rds")
  if (file.exists(sf)) {
    if (!identical(readRDS(sf), signature)) stop("Settings/code differ from this output. Choose a new output directory.")
  } else {
    if (length(list.files(file.path(out,"replications")))) stop("Untracked checkpoints: use an empty output directory.")
    saveRDS(signature, sf)
  }
  gridfile <- file.path(out, "scenarios.rds")
  grid <- if (file.exists(gridfile)) readRDS(gridfile) else prepare_scenarios(experiment, cfg)
  saveRDS(grid, gridfile)
  write.csv(grid, file.path(out, "scenarios.csv"), row.names = FALSE)
  jobs <- list()
  for (i in seq_len(nrow(grid))) for (b in seq_len(cfg$M)) {
    c <- as.list(grid[i,])
    jobs[[length(jobs)+1L]] <- list(config = c, replication = b,
      seed = stable_seed(cfg$seed, "data", "song", c$n, c$p, b),
      file = file.path(out, "replications", sprintf("scenario_%03d_rep_%03d.rds", i, b)),
      save_scores = cfg$save_scores)
  }
  pending <- jobs[!vapply(jobs, function(j) file.exists(j$file), FALSE)]
  cat(sprintf("Experiment %d: %d settings x %d replications; %d pending.\n", experiment, nrow(grid), cfg$M, length(pending)))
  cl <- NULL
  if (cfg$workers > 1 && length(pending)) {
    cl <- parallel::makePSOCKcluster(cfg$workers)
    on.exit(parallel::stopCluster(cl), add = TRUE)
    parallel::clusterCall(cl, function(project, engine) {
      if (.Platform$OS.type=="windows") invisible(Sys.setlocale("LC_CTYPE",".UTF-8"))
      for (f in c("cHSIC.R", "data_generation.R", "simulation_functions.R"))
        source(file.path(project, "simulations", f), local = .GlobalEnv, encoding = "UTF-8")
      options(chapter4.engine = setup_engine(project, engine, envir = .GlobalEnv))
      NULL
    }, project, engine)
  }
  if (length(pending)) for (start in seq.int(1L, length(pending), by = cfg$workers)) {
    ix <- start:min(length(pending), start+cfg$workers-1L)
    if (is.null(cl)) lapply(pending[ix], run_one_replication) else
      parallel::parLapplyLB(cl, pending[ix], run_one_replication)
    cat(sprintf("Completed %d/%d pending replications\n", max(ix), length(pending)))
    flush.console()
  }
  records <- lapply(jobs, function(j) readRDS(j$file))
  metrics <- do.call(rbind, lapply(records, `[[`, "metrics"))
  diagnostics <- do.call(rbind, lapply(records, `[[`, "diagnostics"))
  stopifnot(nrow(metrics) == nrow(grid)*cfg$M*3L)
  write.csv(metrics, file.path(out,"replication_metrics.csv"), row.names = FALSE)
  write.csv(diagnostics, file.path(out,"replication_diagnostics.csv"), row.names = FALSE)
  writeLines(capture.output(sessionInfo()), file.path(out,"sessionInfo.txt"))
  summarize_folder(out)
  cat("Results:", normalizePath(out, winslash="/"), "\n")
  invisible(out)
}

summarize_screening <- function(metrics, grid) {
  stopifnot(!anyNA(metrics), !anyDuplicated(metrics[c("scenario","replication","method")]),
            setequal(unique(metrics$method), c("cHSIC-SIS","CSIS","rCSIS")),
            setequal(unique(metrics$scenario), grid$scenario))
  counts <- table(metrics$scenario, metrics$method)
  if (any(counts == 0) || any(apply(counts, 1, function(x) length(unique(x)) != 1))) stop("Incomplete method records.")
  parts <- lapply(split(metrics, interaction(metrics$scenario,metrics$method,drop=TRUE)), function(z) {
    prob <- mean(z$all_selected)
    q <- quantile(z$s_min, c(.05,.25,.5,.75,.95), type=7, names=FALSE)
    ans <- data.frame(scenario=z$scenario[1], method=z$method[1], repetitions=nrow(z), d=z$d[1],
      all_selected_probability=prob, all_selected_mc_se=sqrt(prob*(1-prob)/nrow(z)),
      s_min_mean=mean(z$s_min), s_min_q05=q[1], s_min_q25=q[2], s_min_median=q[3], s_min_q75=q[4], s_min_q95=q[5])
    for (k in 1:4) ans[[paste0("selection_probability_X",k)]] <- mean(z[[paste0("selected_X",k)]])
    ans
  })
  ans <- merge(grid, do.call(rbind,parts), by="scenario")
  ans[order(ans$scenario,match(ans$method,c("cHSIC-SIS","CSIS","rCSIS"))),]
}

summarize_folder <- function(folder) {
  grid <- read.csv(file.path(folder,"scenarios.csv"), check.names=FALSE)
  metrics <- read.csv(file.path(folder,"replication_metrics.csv"), check.names=FALSE)
  summary <- summarize_screening(metrics, grid)
  write.csv(summary, file.path(folder,"summary_screening.csv"), row.names=FALSE)
  diagnostic_file <- file.path(folder,"replication_diagnostics.csv")
  if (file.exists(diagnostic_file)) {
    diagnostics <- read.csv(diagnostic_file)
    rows <- lapply(split(diagnostics,diagnostics$scenario),function(z) {
      data.frame(scenario=z$scenario[1],repetitions=nrow(z),
        raw_censor_mean=mean(z$raw_censor_fraction),
        joint_window_missing_mean=mean(z$joint_window_missing_fraction),
        complete_count_mean=mean(z$complete_count),
        repetitions_with_clipping=sum(z$mean_complete_clip_fraction>0),
        mean_complete_clip_fraction=mean(z$mean_complete_clip_fraction),
        max_weight=max(z$max_weight))
    })
    diagnostic_summary <- merge(grid,do.call(rbind,rows),by="scenario")
    write.csv(diagnostic_summary,file.path(folder,"weight_diagnostics.csv"),row.names=FALSE)
  }
  export_tables(summary, folder)
  invisible(summary)
}

combine_experiments <- function(folders, out) {
  grids <- metrics <- diagnostics <- list(); offset <- 0L
  for (folder in folders) {
    g <- read.csv(file.path(folder,"scenarios.csv"))
    m <- read.csv(file.path(folder,"replication_metrics.csv"))
    dg <- read.csv(file.path(folder,"replication_diagnostics.csv"))
    ids <- setNames(seq_len(nrow(g))+offset, g$scenario)
    m$scenario <- unname(ids[as.character(m$scenario)])
    dg$scenario <- unname(ids[as.character(dg$scenario)])
    g$scenario <- unname(ids[as.character(g$scenario)])
    grids[[length(grids)+1L]] <- g; metrics[[length(metrics)+1L]] <- m
    diagnostics[[length(diagnostics)+1L]] <- dg
    offset <- offset+nrow(g)
  }
  dir.create(out, recursive=TRUE, showWarnings=FALSE)
  write.csv(do.call(rbind,grids),file.path(out,"scenarios.csv"),row.names=FALSE)
  write.csv(do.call(rbind,metrics),file.path(out,"replication_metrics.csv"),row.names=FALSE)
  write.csv(do.call(rbind,diagnostics),file.path(out,"replication_diagnostics.csv"),row.names=FALSE)
  summarize_folder(out)
}

export_tables <- function(summary, out) {
  lines <- c("% Mean selection frequencies and type-7 model-size quantiles.",
             "% Requires booktabs and multirow. Tables correspond to Chapter 4.")
  fields <- c(paste0("selection_probability_X",1:4),"all_selected_probability",
              "s_min_q05","s_min_q25","s_min_median","s_min_q75","s_min_q95")
  for (ex in sort(unique(summary$experiment))) for (rate in sort(unique(summary$target_censor))) {
    dd <- summary[summary$experiment==ex & summary$target_censor==rate,]
    if (!nrow(dd)) next
    label <- sprintf("tab:h4-%s-%g",if(ex==1)"dependent" else "independent",100*rate)
    lines <- c(lines,"\\begin{table}[!htbp]","\\centering",
      sprintf("\\caption{删失比例为$%g\\%%$时实验%d的模拟结果}\\label{%s}",100*rate,ex,label),
      "\\begingroup\\small\\setlength{\\tabcolsep}{2pt}",
      "\\begin{tabular*}{\\textwidth}{@{\\extracolsep{\\fill}}cclrrrrrrrrrr@{}}\\toprule",
      "\\multirow{2}{*}{删失结构}&\\multirow{2}{*}{$n$}&\\multirow{2}{*}{方法}&\\multicolumn{5}{c}{活跃变量入选比例}&\\multicolumn{5}{c}{最小模型规模分位数}\\\\",
      "\\cmidrule(lr){4-8}\\cmidrule(l){9-13}",
      "&&&$X_1$&$X_2$&$X_3$&$X_4$&全部&$5\\%$&$25\\%$&$50\\%$&$75\\%$&$95\\%$\\\\\\midrule")
    for (ct in c("common","component")) {
      sub <- dd[dd$censor_type==ct,]; if (!nrow(sub)) next
      ns <- sort(unique(sub$n)); first <- TRUE
      for (nn in ns) {
        for (method in c("cHSIC-SIS","CSIS","rCSIS")) {
          row <- sub[sub$n==nn & sub$method==method,]; stopifnot(nrow(row)==1)
          lead <- c(if(first)sprintf("\\multirow{%d}{*}{(%s)}",nrow(sub),if(ct=="common")"a" else "b") else "",
                    if(method=="cHSIC-SIS")sprintf("\\multirow{3}{*}{%d}",nn) else "", method)
          cells <- sprintf("%.2f",as.numeric(row[,fields]))
          lines <- c(lines,paste0(paste(c(lead,cells),collapse="&"),"\\\\")); first <- FALSE
        }
        if(nn!=tail(ns,1)) lines <- c(lines,"\\cmidrule(l){2-13}")
      }
      if(ct=="common" && any(dd$censor_type=="component")) lines <- c(lines,"\\midrule")
    }
    lines <- c(lines,"\\bottomrule\\end{tabular*}","\\endgroup","\\end{table}","")
  }
  con <- file(file.path(out,"tables_results.tex"),open="w",encoding="UTF-8")
  on.exit(close(con),add=TRUE); writeLines(lines,con)
}
