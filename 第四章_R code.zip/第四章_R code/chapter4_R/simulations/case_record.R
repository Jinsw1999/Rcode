if (.Platform$OS.type == "windows") invisible(Sys.setlocale("LC_CTYPE", ".UTF-8"))
# Summarize both experiments and export the six manuscript tables.
local({

  files <- Filter(Negate(is.null), lapply(sys.frames(), function(x) x$ofile))
  cli <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  script <- if (length(files)) tail(files, 1)[[1]] else sub("^--file=", "", cli[1])
  directory <- dirname(normalizePath(script, winslash = "/", mustWork = TRUE))
  project <- dirname(directory)

  source(file.path(directory, "simulation_functions.R"), local = TRUE, encoding = "UTF-8")
  use_saved_results <- TRUE  # FALSE: read your completed case1/case2 runs.
  if (use_saved_results) {
    folder <- file.path(directory, "paper_results")
    summarize_folder(folder)
  } else {
    folders <- file.path(directory, "results", c("case1", "case2"))
    combine_experiments(folders, file.path(directory, "results/combined"))
  }
})
