# cHSIC-SIS, CSIS and rCSIS for the bivariate window response.
# Pure R formulas are retained; optional C++ implements the same statistics.

assert_scalar <- function(x, name, lower = -Inf, upper = Inf) {
  if (length(x) != 1L || !is.finite(x) || x < lower || x > upper)
    stop(name, " must be a finite scalar in [", lower, ", ", upper, "].")
}

normalize_censor_type <- function(censor_type) {
  if (is.numeric(censor_type)) {
    if (length(censor_type)!=1L || !censor_type %in% 1:2) stop("Use censor_type 1 or 2.")
    censor_type <- c("common", "component")[censor_type]
  }
  if (identical(censor_type, "independent")) censor_type <- "component"
  if (length(censor_type)!=1L || !censor_type %in% c("common","component"))
    stop("Use common or component censoring.")
  censor_type
}

gaussian_gram <- function(Z, sigma, normalized = TRUE) {
  assert_scalar(sigma, "Gaussian kernel bandwidth", 1e-12)
  Z <- as.matrix(Z)
  d2 <- as.matrix(dist(Z))^2
  A <- exp(-d2 / (2 * sigma^2))
  if (normalized) A <- A / (sqrt(2*pi)*sigma)^ncol(Z)
  diag(A) <- 0
  A
}

weighted_hsic <- function(A, B, W) {
  n <- length(W)
  if (n < 4L) stop("HSIC U statistic requires n >= 4.")
  if (any(!is.finite(W)) || any(W < 0)) stop("Invalid weights.")
  m <- sum(W); M <- sum(W^2)
  Ai <- as.vector(A %*% W); Bi <- as.vector(B %*% W)
  A2 <- as.vector(A %*% (W^2)); B2 <- as.vector(B %*% (W^2))
  AB <- A * B
  s1 <- sum(W * as.vector(AB %*% ((m^2 - M) * W - 2 * m * W^2))) +
    2 * sum(W^2 * as.vector(AB %*% (W^2)))
  numerator <- s1 - 2 * sum(W * (m + W) * Ai * Bi) +
    2 * sum(W * A2 * Bi) + 2 * sum(W * Ai * B2) +
    sum(W * Ai) * sum(W * Bi)
  as.numeric(numerator / (n * (n - 1) * (n - 2) * (n - 3)))
}

make_km_plan <- function(time, delta, eval_time) {
  ord <- order(time)
  tt <- time[ord]
  rr <- rle(tt)
  ends <- cumsum(rr$lengths)
  starts <- c(1L, head(ends, -1L) + 1L)
  groups <- lapply(seq_along(starts), function(j) seq.int(starts[j], ends[j]))
  list(ord = ord, values = rr$values, starts = starts, groups = groups,
       censored = (delta[ord] == 0L), eval_time = eval_time)
}

local_km_from_gram <- function(K, plan) {
  n <- nrow(K)
  Ko <- K[plan$ord, , drop = FALSE]
  # Reverse cumulative sums avoid cancellation when far-tail kernel weights vanish.
  risk <- apply(Ko, 2L, function(w) rev(cumsum(rev(w))))
  ans <- rep(1, n)
  for (g in seq_along(plan$groups)) {
    ix <- plan$groups[[g]]
    ev <- ix[plan$censored[ix]]
    if (!length(ev)) next
    eligible <- which(plan$values[g] < plan$eval_time)
    if (!length(eligible)) next
    denom <- risk[plan$starts[g], eligible]
    if (any(!is.finite(denom)) || any(denom <= 0))
      stop("Nonpositive local risk mass at an eligible sample evaluation point.")
    numer <- colSums(Ko[ev, eligible, drop = FALSE])
    jump <- numer / denom
    if (any(jump > 1 + 1e-10) || any(jump < -1e-10)) stop("Invalid KM jump.")
    ans[eligible] <- ans[eligible] * (1 - pmin(1, pmax(0, jump)))
  }
  pmin(1, pmax(0, ans))
}

local_km_sample <- function(x, time, delta, h, eval_time = time) {
  assert_scalar(h, "local KM bandwidth", 1e-12)
  if (length(x) != length(time) || length(delta) != length(x) ||
      length(eval_time) != length(x) || any(eval_time > time))
    stop("Local KM sample evaluation requires t_i <= Y_i.")
  K <- exp(-outer(x, x, "-")^2 / (2 * h^2))
  local_km_from_gram(K, make_km_plan(time, delta, eval_time))
}

screen_observed <- function(X, Y, delta, v, h, g_star, sigma_x = 1, sigma_y = 1,
                            censor_type = "common", kernel_normalization = TRUE) {
  censor_type <- normalize_censor_type(censor_type)
  X <- as.matrix(X); Y <- as.matrix(Y); delta <- as.matrix(delta)
  n <- nrow(X); p <- ncol(X)
  if (n < 4L || !identical(dim(Y), c(n, 2L)) || !identical(dim(delta), dim(Y)))
    stop("Expected n x p X, n x 2 Y and delta, with n >= 4.")
  if (any(!is.finite(X)) || any(!is.finite(Y)) || any(Y <= 0) ||
      any(!delta %in% c(0, 1))) stop("Invalid observed data.")
  assert_scalar(v, "v", 1e-12); assert_scalar(h, "h", 1e-12)
  assert_scalar(g_star, "g_star", 1e-12, 1)
  assert_scalar(sigma_x,"sigma_x",1e-12)
  V <- pmin(Y, v)
  Ds <- 1L * ((delta == 1L) | (Y >= v))
  D <- Ds[, 1] * Ds[, 2]
  B <- gaussian_gram(V, sigma_y, kernel_normalization)
  plans <- lapply(1:2, function(s) make_km_plan(Y[, s], delta[, s], V[, s]))
  IY <- lapply(1:2, function(s) 1 * outer(V[, s], V[, s], "<="))
  methods <- c("cHSIC-SIS", "CSIS", "rCSIS")
  scores <- matrix(NA_real_, p, length(methods), dimnames = list(NULL, methods))
  Ghat <- matrix(NA_real_, n, p)
  diag_rows <- vector("list", p)
  for (k in seq_len(p)) {
    x <- X[, k]  # N(0,1) population scale: no sample standardization.
    d2 <- outer(x, x, "-")^2
    K <- exp(-d2 / (2 * h^2))
    g1 <- local_km_from_gram(K, plans[[1]])
    g2 <- local_km_from_gram(K, plans[[2]])
    g <- if (censor_type == "common") pmin(g1, g2) else g1 * g2
    W <- D / pmax(g, g_star)
    Ghat[, k] <- g
    A <- exp(-d2 / (2 * sigma_x^2))
    if (kernel_normalization) A <- A / (sqrt(2*pi)*sigma_x)
    diag(A) <- 0
    scores[k, "cHSIC-SIS"] <- weighted_hsic(A, B, W)
    # Adaptations of the original marginal comparison scores to the window target.
    # Use the same joint floor for marginal denominators; true marginals exceed it.
    W1 <- Ds[, 1] / pmax(g1, g_star)
    W2 <- Ds[, 2] / pmax(g2, g_star)
    Fx <- rank(x, ties.method = "max") / n
    cs <- rs <- numeric(2)
    for (s in 1:2) {
      ww <- if (s == 1) W1 else W2
      cs[s] <- mean(abs(as.vector((ww * x) %*% IY[[s]]))) / n
      rs[s] <- mean(abs(as.vector((ww * (Fx - 0.5)) %*% IY[[s]]))) / n
    }
    scores[k, "CSIS"] <- sum(cs^2)
    scores[k, "rCSIS"] <- sum(rs^2)
    diag_rows[[k]] <- c(clip_fraction = mean(g < g_star),
                        complete_clip_fraction = if (any(D == 1)) mean(g[D == 1] < g_star) else 0,
                        max_weight = max(W), min_Ghat = min(g))
  }
  if (any(!is.finite(scores))) stop("Non-finite screening scores.")
  list(scores = scores, Ghat = Ghat, weight_diagnostics = do.call(rbind, diag_rows),
       V = V, Ds = Ds, D = D)
}

# Optional source compilation; no precompiled binary or machine-specific path.
setup_engine <- function(project, engine=c("auto","R","cpp"), envir=parent.frame()) {
  engine <- match.arg(engine)
  if(engine=="R") return("R")
  ans <- tryCatch({
    if(!requireNamespace("Rcpp",quietly=TRUE)) stop("Install Rcpp for C++ acceleration")
    Rcpp::sourceCpp(file.path(project,"simulations","screen_fast.cpp"),
      cacheDir=file.path(tempdir(),"chapter4_rcpp"),env=envir,verbose=FALSE)
    TRUE
  },error=function(e) e)
  if(inherits(ans,"error")) {
    if(engine=="cpp") stop(conditionMessage(ans))
    warning("C++ unavailable; using complete pure-R implementation: ",conditionMessage(ans))
    return("R")
  }
  "cpp"
}


screen_data <- function(X,Y,delta,v,h,g_star,sigma_x=1,sigma_y=1,
                              censor_type="common",kernel_normalization=TRUE) {
  engine<-getOption("chapter4.engine","R")
  if(engine!="cpp" || !kernel_normalization) {
    f<-screen_observed(X,Y,delta,v,h,g_star,sigma_x,sigma_y,censor_type,kernel_normalization)
    w<-f$D/pmax(f$Ghat,g_star);ss<-colSums(w^2)
    f$weight_diagnostics<-cbind(f$weight_diagnostics,
      ESS=ifelse(ss>0,colSums(w)^2/ss,0),mean_weight=colMeans(w))
    return(f)
  }
  X<-as.matrix(X);Y<-as.matrix(Y);delta<-as.matrix(delta)
  if(nrow(X)<4 || ncol(Y)!=2 || !identical(dim(Y),dim(delta)) || nrow(X)!=nrow(Y) ||
     any(!is.finite(X)) || any(!is.finite(Y)) || any(Y<=0) || any(!delta%in%c(0,1)))stop("Invalid simulation input")
  assert_scalar(h,"h",1e-12);assert_scalar(g_star,"g_star",1e-12,1)
  assert_scalar(sigma_x,"sigma_x",1e-12);assert_scalar(sigma_y,"sigma_y",1e-12)
  ct<-normalize_censor_type(censor_type);V<-pmin(Y,v);Ds<-1*((delta==1)|(Y>=v))
  B<-gaussian_gram(V,sigma_y,TRUE)
  plans<-lapply(1:2,function(s)make_km_plan(Y[,s],delta[,s],V[,s]))
  f<-screen_fast_cpp(X,B,V,Ds,plans[[1]],plans[[2]],h,g_star,ct=="common",sigma_x)
  colnames(f$scores)<-c("cHSIC-SIS","CSIS","rCSIS")
  colnames(f$diagnostics)<-c("clip_fraction","complete_clip_fraction","max_weight","min_Ghat","ESS","mean_weight")
  if(any(!is.finite(f$scores))||any(!is.finite(f$diagnostics)))stop("Nonfinite simulation output")
  list(scores=f$scores,weight_diagnostics=f$diagnostics,V=V,Ds=Ds,D=Ds[,1]*Ds[,2])
}
