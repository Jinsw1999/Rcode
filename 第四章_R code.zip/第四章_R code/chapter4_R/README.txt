第四章 R code

本代码对应第四章的两个模拟实验及GSE31312真实数据分析。
目录与第二、三章一致，分为simulations和real data；各实验脚本调用公共函数，record脚本负责汇总。

一、运行方式

先解压整个文件夹。在RStudio中打开需要运行的.R文件，点击Source运行整个文件。
脚本自动定位所在目录，无需修改绝对路径，也无需清空当前R环境。
首次使用可运行根目录install_packages.R安装所需R包。

simulations/
  settings.R                         样本量、维数、重复次数、删失率及计算设置
  case1(covariate-dependent).R        实验1：删失依赖协变量
  case2(independent).R               实验2：删失不依赖协变量
  case_record.R                      汇总两个实验，导出六张LaTeX表格
  cHSIC.R                            cHSIC-SIS、CSIS和rCSIS的公共计算函数
  data_generation.R                  生存时间、删失时间生成及删失率校准
  simulation_functions.R             重复模拟、保存和汇总
  screen_fast.cpp                    可选的C++加速实现
  paper_results/                     与正文对应的逐次指标、设置、汇总和表格

real data/
  GSE31312_preprocessing.R            下载、校验原始资料并匹配表达数据与临床记录
  GSE31312_screening.R                三方法筛选、10次划分及预测评价
  GSE31312_sensitivity.R              局部窗宽及随访窗口敏感性分析
  GSE31312_record.R                   预测结果汇总及LaTeX表格
  settings.R                         真实数据分析参数
  data_io.R、realdata_functions.R     公共函数
  data/                              临床整理表和原始资料的下载地址、校验值
  paper_results/                     正文对应的预测、权重与敏感性结果

二、模拟实验

两个实验均取：n=100、200；p=2000；重复100次；删失率为15%、30%、50%；
考虑共同删失(a)和分量删失(b)。共24种设置、2400次样本生成，每次比较三种方法。
筛选规模为ceiling(n/log(n))。模型规模分位数采用R的type=7定义。
独立先导样本分别用于删失参数校准（50000例）和HSIC核宽度选择（2000例）。
不同删失设置在相同n、p和重复编号下共用基础随机数；每个设置内的100次重复相互独立。

依次运行两个case脚本。结果分别写入simulations/results/case1和case2。
中断后重新运行相同脚本即可续算。更改模型参数、计算引擎或代码后，需使用新的结果目录，
避免将不同设置的记录混在一起；仅修改workers可继续同一批计算。

settings.R中的workers控制并行进程数，默认1。可根据计算机配置增加。
engine="auto"优先使用C++，无法编译时自动使用完整的纯R实现。
Windows下C++加速需要与R版本匹配的Rtools；engine="R"无需编译器，但运行较慢。

三、结果汇总

case_record.R与GSE31312_record.R中的use_saved_results默认TRUE：
直接从paper_results中的正式逐次记录重新计算表格，无需重跑模拟或下载表达数据。
设为FALSE后，汇总自己在results目录生成的结果。
paper_results是论文结果参照，results是本机重新运行的输出；两者不自动混合。

四、真实数据分析

按preprocessing、screening、sensitivity的顺序运行；record可单独重建论文预测表。
表达矩阵较大，原始资料按data/source_manifest.csv中的地址下载并验证SHA-256，
不随代码包重复分发。clinical_475.csv是从公开临床PDF整理的记录，来源见DATA_SOURCE.txt。
需要重新核对PDF转录时，可调用data_io.R中的audit_clinical_pdf；这一步需pdftools或pdftotext。

分析采用466例患者，训练集/测试集为324/142，重复10次；每次仅用训练集方差预选5000个探针，
并用训练集均值、标准差进行标准化。筛选56个探针后分别拟合OS、PFS的Cox岭回归，lambda=0.1。
分层依据为36个月内两个终点的事件发生指标组合。随访窗口为36个月。
预测评价为Uno型一致性指数和IBS；IBS按73个等距时间点积分，评价用删失概率下限为0.05。
筛选权重的分母下限为0.005，与上述预测评价下限用途不同。
敏感性分析在全样本中比较0.7h、1.5h及24、48个月窗口，保留前75个探针。

五、运行示例

命令行示例（在本目录执行）：
  Rscript "simulations/case1(covariate-dependent).R"
  Rscript "simulations/case2(independent).R"
  Rscript "simulations/case_record.R"
  Rscript "real data/GSE31312_preprocessing.R"
  Rscript "real data/GSE31312_screening.R"
  Rscript "real data/GSE31312_sensitivity.R"

修改参数作试运行时，可取n=c(30,40)、p=30、M=2；真实数据可取p=60、splits=2。
试运行结果仅用于检查安装，不能代替正文的正式结果。
