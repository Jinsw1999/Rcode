if (.Platform$OS.type == "windows") invisible(Sys.setlocale("LC_CTYPE", ".UTF-8"))
# Run explicitly once; no package installation occurs during analysis.
needed<-c("data.table","survival","glmnet","digest","Rcpp")
missing<-needed[!vapply(needed,requireNamespace,logical(1),quietly=TRUE)]
if(length(missing))install.packages(missing,repos="https://cloud.r-project.org")
cat("Required packages available. Optional PDF re-extraction: install.packages('pdftools').\n")
cat("C++ acceleration needs an R-compatible toolchain (Rtools on Windows). engine='R' needs no compiler.\n")
print(vapply(needed,function(x)as.character(packageVersion(x)),""))
