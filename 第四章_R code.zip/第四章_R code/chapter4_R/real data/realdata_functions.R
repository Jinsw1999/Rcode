# GSE31312 preprocessing within the cohort, screening, prediction and sensitivity.
prepare_x <- function(X, train, test=NULL, p=5000L) {
  mu <- colMeans(X[train,,drop=FALSE])
  sdv <- sqrt(pmax(0,(colSums(X[train,,drop=FALSE]^2)-length(train)*mu^2)/(length(train)-1)))
  keep <- which(is.finite(mu) & is.finite(sdv) & sdv>1e-8)
  keep <- keep[order(-sdv[keep],colnames(X)[keep])][seq_len(min(p,length(keep)))]
  z <- function(ix) sweep(sweep(X[ix,keep,drop=FALSE],2,mu[keep],"-"),2,sdv[keep],"/")
  list(train=z(train),test=if(!is.null(test))z(test) else NULL,keep=keep)
}

prepare_cohort <- function(dat) {
  cl <- dat$clinical; X <- dat$X
  stopifnot(identical(rownames(X),cl$gsm))
  valid <- with(cl,is.finite(pfs)&is.finite(os)&pfs>0&os>0&pfs<=os+0.001 & pfs_censor %in% 0:1 & os_censor %in% 0:1)
  excluded <- cl[!valid,]; cl <- cl[valid,]; X <- X[valid,,drop=FALSE]
  cl$os_time <- cl$os; cl$os_event <- 1-cl$os_censor
  cl$pfs_time <- cl$pfs; cl$pfs_event <- 1-cl$pfs_censor
  death <- with(cl,pfs_censor==1 & os_censor==0 & abs(pfs-os)<=0.001)
  cl$pfs_event[death] <- 1
  earlier <- with(cl,pfs_censor==1 & pfs<os-0.001)
  stopifnot(all(cl$os_event[earlier]==0))
  cl$os_time[earlier] <- cl$pfs[earlier]
  cl$endpoint_change <- ifelse(death,"death_added_to_PFS",ifelse(earlier,"OS_followup_harmonized","none"))
  list(X=X,clinical=cl,excluded=excluded,
       Y=as.matrix(cl[,c("os_time","pfs_time")]),
       delta=as.matrix(cl[,c("os_event","pfs_event")]),
       death_adjustments=sum(death),followup_adjustments=sum(earlier))
}

screen_probes <- function(x,y,delta,v=36,hfactor=1,g_star=.005,tag="fit") {
  n <- nrow(x); p <- ncol(x)
  sy <- median(as.numeric(dist(pmin(y,v)))); stopifnot(sy>0)
  scores <- diagnostics <- list()
  for(a in seq(1L,p,by=500L)) {
    ix <- a:min(p,a+499L)
    fit <- screen_data(x[,ix,drop=FALSE],y,delta,v,hfactor*n^(-1/5),g_star,1,sy,"common",TRUE)
    scores[[length(scores)+1L]] <- fit$scores
    diagnostics[[length(diagnostics)+1L]] <- fit$weight_diagnostics
    cat(tag,":",max(ix),"/",p,"probes\n"); flush.console()
  }
  scores <- do.call(rbind,scores); diagnostics <- do.call(rbind,diagnostics)
  rownames(scores) <- rownames(diagnostics) <- colnames(x)
  list(scores=scores,diagnostics=diagnostics,sigma_y=sy,h=hfactor*n^(-1/5),v=v)
}

km_censor <- function(t,d) {
  times <- sort(unique(t)); g <- numeric(length(times)); cur <- 1
  for(i in seq_along(times)) {cur<-cur*(1-sum(t==times[i]&d==0)/sum(t>=times[i]));g[i]<-cur}
  function(z,left=FALSE) {
    j<-findInterval(z,times)
    if(left) j<-j-as.integer(j>0 & times[pmax(j,1)]==z)
    c(1,g)[j+1]
  }
}

evaluate_model <- function(xt,xs,yt,dt,ys,ds,v=36,lambda=.1,g_floor=.05,grid_points=73L) {
  tt<-pmin(yt,v); dd<-dt*as.integer(yt<=v); st<-pmin(ys,v); sd<-ds*as.integer(ys<=v)
  model<-glmnet::glmnet(xt,survival::Surv(tt,dd),family="cox",alpha=0,lambda=lambda,standardize=TRUE,thresh=1e-8)
  lp<-as.numeric(predict(model,xt,s=lambda,type="link")); pred<-as.numeric(predict(model,xs,s=lambda,type="link"))
  cc<-function(w) as.numeric(survival::concordance(survival::Surv(st,sd)~pred,reverse=TRUE,timewt=w)$concordance)
  et<-sort(unique(tt[dd==1])); shift<-max(lp)
  hh<-cumsum(vapply(et,function(z)sum(tt==z&dd==1)/sum(exp(lp[tt>=z]-shift)),0))
  grid<-seq(0,v,length.out=grid_points); h0<-c(0,hh)[findInterval(grid,et)+1]
  surv<-exp(-outer(exp(pred-shift),h0)); gf<-km_censor(tt,dd); bs<-numeric(length(grid))
  for(i in seq_along(grid)) {
    z<-grid[i]; event<-st<=z&sd==1; alive<-st>z
    if(z==v) alive<-st>=z & sd==0
    ww1<-event/pmax(gf(st,left=TRUE),g_floor)
    ww0<-alive/pmax(gf(rep(z,length(st)),left=(z==v)),g_floor)
    bs[i]<-mean(ww1*surv[,i]^2+ww0*(1-surv[,i])^2)
  }
  c(Uno_C=cc("n/G2"),Harrell_C=cc("n"),IBS=sum(diff(grid)*(head(bs,-1)+tail(bs,-1))/2)/v)
}

guard_realdata <- function(project,prepared,out,cfg,engine) {
  dir.create(out,recursive=TRUE,showWarnings=FALSE)
  code <- c("simulations/cHSIC.R","simulations/screen_fast.cpp",
            "real data/realdata_functions.R","real data/data_io.R")
  packages<-c("survival","glmnet","data.table","digest","Rcpp")
  versions<-setNames(vapply(packages,function(x)if(requireNamespace(x,quietly=TRUE))as.character(packageVersion(x)) else "absent",""),packages)
  signature<-list(config=cfg,engine=engine,R=as.character(getRversion()),packages=versions,
    prepared_sha256=digest::digest(file=prepared,algo="sha256"),
    code=setNames(unname(tools::md5sum(file.path(project,code))),code))
  sf<-file.path(out,"run_signature.rds")
  if(file.exists(sf)) {
    if(!identical(readRDS(sf),signature)) stop("Data/code/settings differ from this output. Use a new output directory.")
  } else {
    if(length(list.files(out,pattern="[.]rds$"))) stop("Untracked checkpoints: use an empty output directory.")
    saveRDS(signature,sf)
  }
  writeLines(capture.output(sessionInfo()),file.path(out,"sessionInfo.txt"))
}

run_realdata <- function(project,prepared,out,cfg,stage=c("primary","sensitivity")) {
  stage<-match.arg(stage)
  require_packages(c("survival","glmnet","digest"))
  if(!file.exists(prepared)) stop("Run GSE31312_preprocessing.R first.")
  # Load estimators into the environment shared by the real-data functions.
  env<-environment(screen_probes)
  source(file.path(project,"simulations/cHSIC.R"),local=env,encoding="UTF-8")
  engine<-setup_engine(project,cfg$engine,envir=env)
  old<-options(chapter4.engine=engine); on.exit(options(old),add=TRUE)
  guard_realdata(project,prepared,out,cfg,engine)
  dat<-prepare_cohort(readRDS(prepared)); X<-dat$X; Y<-dat$Y; delta<-dat$delta
  write.csv(dat$clinical,file.path(out,"analysis_patients.csv"),row.names=FALSE)
  write.csv(dat$excluded,file.path(out,"excluded_patients.csv"),row.names=FALSE)
  write.csv(data.frame(endpoint=c("OS","PFS"),n=nrow(X),events=colSums(delta),
    censored=colSums(1-delta),censor_fraction=colMeans(1-delta)),file.path(out,"cohort_summary.csv"),row.names=FALSE)
  window<-do.call(rbind,lapply(c(24,36,48),function(v) {
    D<-delta==1 | Y>=v
    data.frame(window=v,joint_complete=sum(D[,1]&D[,2]),joint_missing=mean(!(D[,1]&D[,2])))
  }))
  write.csv(window,file.path(out,"window_summary.csv"),row.names=FALSE)
  fullfile<-file.path(out,"full_fit.rds")
  if(!file.exists(fullfile)) {
    px<-prepare_x(X,seq_len(nrow(X)),p=cfg$p)
    fit<-screen_probes(px$train,Y,delta,cfg$window,cfg$h_factor,cfg$g_star,"full cohort")
    saveRDS(list(fit=fit,keep=px$keep),fullfile)
  }
  full<-readRDS(fullfile)$fit
  ranks<-data.frame(probe=rownames(full$scores),full$scores,full$diagnostics,check.names=FALSE)
  ranks<-ranks[order(-ranks[["cHSIC-SIS"]],ranks$probe),]; ranks$rank<-seq_len(nrow(ranks))
  write.csv(ranks,file.path(out,"full_ranking.csv"),row.names=FALSE)
  d_full<-min(nrow(ranks),floor(nrow(X)/log(nrow(X))))
  write.csv(head(ranks,d_full),file.path(out,"top75_probes.csv"),row.names=FALSE)
  w<-full$diagnostics
  write.csv(data.frame(n=nrow(X),complete_count=sum(rowSums(delta==1|Y>=cfg$window)==2),
    max_weight=max(w[,"max_weight"]),ESS_min=min(w[,"ESS"]),ESS_max=max(w[,"ESS"]),
    complete_clip_mean=mean(w[,"complete_clip_fraction"])),file.path(out,"weight_diagnostics.csv"),row.names=FALSE)

  if(stage=="sensitivity") {
    px<-prepare_x(X,seq_len(nrow(X)),p=cfg$p)
    specs<-data.frame(tag=c("h07","h15","window24","window48"),v=c(36,36,24,48),hf=c(.7,1.5,1,1))
    base<-full$scores[,"cHSIC-SIS"]
    base_set<-names(sort(base,decreasing=TRUE))[seq_len(d_full)]
    rows<-list()
    for(i in seq_len(nrow(specs))) {
      sp<-specs[i,]; path<-file.path(out,paste0("sensitivity_",sp$tag,".rds"))
      if(file.exists(path)) fit<-readRDS(path) else {
        fit<-screen_probes(px$train,Y,delta,sp$v,sp$hf,cfg$g_star,sp$tag); saveRDS(fit,path)
      }
      sc<-fit$scores[,"cHSIC-SIS"]; sel<-names(sort(sc,decreasing=TRUE))[seq_len(d_full)]
      w<-fit$diagnostics
      rows[[i]]<-data.frame(sp,Spearman=cor(base,sc,method="spearman"),top_d=d_full,
        overlap=length(intersect(base_set,sel)),Jaccard=length(intersect(base_set,sel))/length(union(base_set,sel)),
        max_weight=max(w[,"max_weight"]),ESS_min=min(w[,"ESS"]),ESS_median=median(w[,"ESS"]),
        complete_clip_mean=mean(w[,"complete_clip_fraction"]))
    }
    write.csv(do.call(rbind,rows),file.path(out,"sensitivity_summary.csv"),row.names=FALSE)
    return(invisible(out))
  }

  for(b in seq_len(cfg$splits)) {
    path<-file.path(out,sprintf("split_%02d.rds",b)); if(file.exists(path)) next
    set.seed(cfg$split_seed+b)
    # Stratify by occurrence of each event within the 36-month prediction window.
    strata<-interaction(delta[,1]*(Y[,1]<=cfg$window),delta[,2]*(Y[,2]<=cfg$window),drop=TRUE)
    train<-sort(unlist(lapply(split(seq_len(nrow(X)),strata),function(ix)sample(ix,floor(cfg$train_fraction*length(ix))))))
    test<-setdiff(seq_len(nrow(X)),train)
    px<-prepare_x(X,train,test,cfg$p)
    fit<-screen_probes(px$train,Y[train,],delta[train,],cfg$window,cfg$h_factor,cfg$g_star,paste("split",b))
    d<-min(cfg$p,floor(length(train)/log(length(train)))); selected<-rows<-list()
    for(method in c("cHSIC-SIS","CSIS","rCSIS")) {
      ix<-order(-fit$scores[,method],rownames(fit$scores))[seq_len(d)]
      selected[[method]]<-rownames(fit$scores)[ix]
      for(s in 1:2) {
        values<-evaluate_model(px$train[,ix,drop=FALSE],px$test[,ix,drop=FALSE],
          Y[train,s],delta[train,s],Y[test,s],delta[test,s],cfg$window,
          cfg$ridge_lambda,cfg$prediction_g_floor,cfg$prediction_grid_points)
        rows[[length(rows)+1L]]<-data.frame(rep=b,method=method,endpoint=c("OS","PFS")[s],
          ntrain=length(train),ntest=length(test),d=d,t(values))
      }
    }
    saveRDS(list(train=train,test=test,fit=fit,selected=selected,metrics=do.call(rbind,rows)),path)
  }
  fits<-lapply(seq_len(cfg$splits),function(b)readRDS(file.path(out,sprintf("split_%02d.rds",b))))
  metrics<-do.call(rbind,lapply(fits,`[[`,"metrics"))
  write.csv(metrics,file.path(out,"test_metrics.csv"),row.names=FALSE)
  summarize_realdata(out)
  invisible(out)
}

summarize_realdata <- function(out) {
  d<-read.csv(file.path(out,"test_metrics.csv"),check.names=FALSE)
  stopifnot(!anyDuplicated(d[c("rep","method","endpoint")]),all(is.finite(d$Uno_C)),all(is.finite(d$IBS)))
  groups<-split(d,interaction(d$method,d$endpoint,drop=TRUE))
  summary<-do.call(rbind,lapply(groups,function(z) {
    data.frame(method=z$method[1],endpoint=z$endpoint[1],splits=nrow(z),
      C_mean=mean(z$Uno_C),C_sd=sd(z$Uno_C),IBS_mean=mean(z$IBS),IBS_sd=sd(z$IBS))
  }))
  write.csv(summary,file.path(out,"test_summary.csv"),row.names=FALSE)
  lines<-c("% Means (standard deviations) across repeated random splits.",
    "\\begin{table}[htbp]\\centering",
    "\\caption{GSE31312数据的预测结果}\\label{tab:h4-realdata-performance}",
    "\\begin{tabular}{lcccc}\\toprule",
    "&\\multicolumn{2}{c}{OS}&\\multicolumn{2}{c}{PFS}\\\\",
    "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}",
    "方法&一致性指数&IBS&一致性指数&IBS\\\\\\midrule")
  for(m in c("cHSIC-SIS","CSIS","rCSIS")) {
    cells<-unlist(lapply(c("OS","PFS"),function(e) {
      z<-summary[summary$method==m & summary$endpoint==e,]; stopifnot(nrow(z)==1)
      c(sprintf("%.3f (%.3f)",z$C_mean,z$C_sd),sprintf("%.3f (%.3f)",z$IBS_mean,z$IBS_sd))
    }))
    lines<-c(lines,paste0(paste(c(m,cells),collapse="&"),"\\\\"))
  }
  lines<-c(lines,"\\bottomrule\\end{tabular}","\\end{table}")
  con<-file(file.path(out,"realdata_table.tex"),open="w",encoding="UTF-8")
  on.exit(close(con),add=TRUE); writeLines(lines,con)
  invisible(summary)
}
