require_packages <- function(x) {
  missing <- x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)]
  if(length(missing)) stop("Missing packages: ",paste(missing,collapse=", "),". Run Rscript install_packages.R")
}
verify_raw <- function(project, rawdir, download=FALSE) {
  require_packages("digest")
  dir.create(rawdir,recursive=TRUE,showWarnings=FALSE)
  manifest <- read.csv(file.path(project,"real data/data/source_manifest.csv"))
  for(i in seq_len(nrow(manifest))) {
    f <- file.path(rawdir,manifest$file[i])
    if(!file.exists(f)) {
      if(!download) stop("Missing ",f,". Run GSE31312_preprocessing.R.")
      good <- FALSE; tmp <- paste0(f,".part")
      old <- options(timeout=max(1200,getOption("timeout"))); on.exit(options(old),add=TRUE)
      for(attempt in 1:3) {
        z <- try(utils::download.file(manifest$url[i],tmp,mode="wb",method="libcurl"),silent=TRUE)
        if(!inherits(z,"try-error") && z==0 &&
           identical(digest::digest(file=tmp,algo="sha256"),manifest$sha256[i])) {good<-TRUE;break}
        if(attempt<3) Sys.sleep(attempt*2)
      }
      if(!good) stop("Download/checksum failed: ",manifest$url[i])
      if(!file.rename(tmp,f)) stop("Could not finalize download: ",f)
    }
    if(!identical(digest::digest(file=f,algo="sha256"),manifest$sha256[i]))
      stop("Raw source changed or corrupt: ",f,". Do not silently reuse results; review the new source.")
    message("Verified: ",basename(f))
  }
  invisible(manifest)
}
gunzip_to <- function(src,dst) {
  input <- gzfile(src,"rb"); output <- file(dst,"wb")
  on.exit({close(input);close(output)})
  repeat {b<-readBin(input,"raw",n=1024L*1024L);if(!length(b))break;writeBin(b,output)}
}
audit_clinical_pdf <- function(project,rawdir) {
  pdf <- file.path(rawdir,"clinical.pdf")
  if(!file.exists(pdf)) gunzip_to(file.path(rawdir,"clinical.pdf.gz"),pdf)
  if(requireNamespace("pdftools",quietly=TRUE)) {
    txt <- paste(pdftools::pdf_text(pdf),collapse="\n")
  } else if(nzchar(Sys.which("pdftotext"))) {
    dest <- tempfile(fileext=".txt"); on.exit(unlink(dest),add=TRUE)
    status<-system2(Sys.which("pdftotext"),c("-layout",shQuote(pdf),shQuote(dest)))
    if(status!=0)stop("pdftotext failed")
    txt<-paste(readLines(dest,warn=FALSE,encoding="UTF-8"),collapse="\n")
  } else stop("PDF audit needs optional R package pdftools OR pdftotext on PATH. Analysis can use the audited clinical CSV without either.")
  txt <- gsub("\f","\n",txt,fixed=TRUE)
  lines <- trimws(strsplit(txt,"\n",fixed=TRUE)[[1]])
  dr <- lines[grepl("^[0-9]+ +[0-9]+ +[MF] +",lines)]
  dem <- do.call(rbind,lapply(strsplit(dr," +"),function(z)
    data.frame(case=as.integer(z[1]),age=as.numeric(z[2]),sex=z[3],stage=suppressWarnings(as.numeric(z[5])))))
  er <- lines[grepl("^[0-9]+ +.*N[0-9]{4} *$",lines)]
  ep <- do.call(rbind,lapply(strsplit(er," +"),function(z) {
    case<-as.integer(z[1]);z<-z[-1];if(grepl("/",z[1],fixed=TRUE))z<-z[-1]
    data.frame(case=case,sample_id=tail(z,1),pfs_censor=as.integer(z[1]),os_censor=as.integer(z[2]),pfs=as.numeric(z[3]),os=as.numeric(z[4]))
  }))
  stopifnot(nrow(dem)==475L,nrow(ep)==475L,!anyDuplicated(dem$case),!anyDuplicated(ep$case))
  actual<-merge(ep,dem,by="case",sort=TRUE)
  ref<-read.csv(file.path(project,"real data/data/clinical_475.csv"),na.strings=c("","NA"))
  actual<-actual[,names(ref)];rownames(actual)<-NULL
  stopifnot(isTRUE(all.equal(actual,ref,check.attributes=FALSE,tolerance=1e-12)))
  write.csv(actual,file.path(rawdir,"clinical_pdf_reextracted.csv"),row.names=FALSE)
  message("PASS: all 475 clinical rows re-extracted from the original PDF match the distributed CSV.")
}
prepare_realdata <- function(project,rawdir,prepared,download=TRUE) {
  require_packages(c("digest","data.table"));verify_raw(project,rawdir,download)
  clinfile<-file.path(project,"real data/data/clinical_475.csv")
  signature<-list(raw=read.csv(file.path(project,"real data/data/source_manifest.csv")),
    clinical_sha256=digest::digest(file=clinfile,algo="sha256"),
    io_sha256=digest::digest(file=file.path(project,"real data/data_io.R"),algo="sha256"))
  if(file.exists(prepared)) {
    z<-readRDS(prepared)
    if(!identical(z$signature,signature))stop("Prepared data fingerprint differs; remove the old prepared-data cache after checking the source.")
    message("Verified prepared-data cache: ",prepared);return(invisible(prepared))
  }
  con<-gzfile(file.path(rawdir,"GSE31312_series_matrix.txt.gz"),"rt")
  on.exit(close(con),add=TRUE); meta<-list(); skip<-0L
  repeat {
    line<-readLines(con,n=1,warn=FALSE);if(!length(line))stop("Matrix start marker missing")
    skip<-skip+1L
    if(grepl("^!Sample_(title|geo_accession)\\t",line)) {
      v<-strsplit(line,"\t",fixed=TRUE)[[1]];meta[[v[1]]]<-gsub('^"|"$',"",v[-1])
    }
    if(line=="!series_matrix_table_begin")break
  }
  # Streaming decompression avoids relying on a shell gzip executable.
  tmp<-tempfile(fileext=".tsv");on.exit(unlink(tmp),add=TRUE)
  gunzip_to(file.path(rawdir,"GSE31312_series_matrix.txt.gz"),tmp)
  ex<-data.table::fread(tmp,skip=skip,nrows=54630L,data.table=FALSE,check.names=FALSE)
  stopifnot(nrow(ex)==54630L,ncol(ex)==499L,!anyDuplicated(ex[[1]]))
  map<-data.frame(gsm=meta[['!Sample_geo_accession']],
    sample_id=sub('.*(N[0-9]{4}).*','\\1',meta[['!Sample_title']]))
  stopifnot(nrow(map)==498L,!anyDuplicated(map$sample_id),!anyDuplicated(map$gsm))
  cl<-read.csv(clinfile,na.strings=c("","NA"))
  j<-match(cl$sample_id,map$sample_id);cl<-cl[!is.na(j),];cl$gsm<-map$gsm[j[!is.na(j)]]
  stopifnot(nrow(cl)==470L,all(cl$gsm%in%names(ex)))
  X<-t(as.matrix(ex[,cl$gsm,drop=FALSE]));colnames(X)<-ex[[1]]
  stopifnot(identical(rownames(X),cl$gsm),all(is.finite(X)))
  dir.create(dirname(prepared),recursive=TRUE,showWarnings=FALSE)
  saveRDS(list(clinical=cl,X=X,signature=signature),prepared,compress=FALSE)
  message("Prepared 470 matched subjects x 54,630 probes; endpoint exclusions occur in analysis.")
  invisible(prepared)
}
