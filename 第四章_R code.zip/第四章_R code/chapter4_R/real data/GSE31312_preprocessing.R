if (.Platform$OS.type == "windows") invisible(Sys.setlocale("LC_CTYPE", ".UTF-8"))
# GSE31312: prepare. Source the whole file.
local({

  files <- Filter(Negate(is.null), lapply(sys.frames(), function(x) x$ofile))
  cli <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  script <- if (length(files)) tail(files, 1)[[1]] else sub("^--file=", "", cli[1])
  directory <- dirname(normalizePath(script, winslash = "/", mustWork = TRUE))
  project <- dirname(directory)

  source(file.path(directory, "data_io.R"), local = TRUE, encoding = "UTF-8")
  source(file.path(directory, "settings.R"), local = TRUE, encoding = "UTF-8")
  source(file.path(directory, "realdata_functions.R"), local = TRUE, encoding = "UTF-8")
  rawdir <- file.path(directory, "data/raw")
  prepared <- file.path(directory, "data/expression_matched.rds")
  out <- file.path(directory, "results")
  prepare_realdata(project, rawdir, prepared, download = TRUE)
})
