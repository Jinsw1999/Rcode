# Manuscript real-data settings.
realdata_settings <- list(
  p = 5000L, splits = 10L, split_seed = 20261103L,
  window = 36, g_star = 0.005, h_factor = 1,
  train_fraction = 0.7, ridge_lambda = 0.1,
  prediction_g_floor = 0.05, prediction_grid_points = 73L,
  engine = "auto"
)
# To check installation only, use p=60 and splits=2 in a new output directory.
# Screening d = floor(n_train/log(n_train)); full-cohort d = floor(n/log(n)).
