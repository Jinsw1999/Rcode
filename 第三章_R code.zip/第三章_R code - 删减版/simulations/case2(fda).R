rm(list = ls())

library(expm)
library(MASS)
library(rmutil)#Laplace
library(evd)#gumble
library(actuar)#RW
library(doParallel)
library(foreach)
library(energy)
library(gcdnet)


source('KCED.R')

startTime<-Sys.time()


n <- 200 #50,100,150,200
p <- 2000 #500,1000,1500,2000
M <- 100 
rho <- 0.6 
d <- round(n/log(n))
nbasis <- 50
p_0 <- 5
tau_0 <- c(0.05,0.25,0.5,0.75,0.95)
goal_1<- c(1:p_0)

# 定义beta(t)
beta_t <- function(t) {
  sqrt(2) * sin(pi * t/2)+3*sqrt(2)*sin(3*pi * t/2)
}

# 定义傅里叶正弦基函数
fourier_sin_basis <- function(t, j) {
  sqrt(2) * sin((j - 0.5) * pi * t)
}

# 生成基函数矩阵（在标准网格上）
create_basis_matrix <- function(t_grid, nbasis) {
  basis_mat <- matrix(NA, nrow = length(t_grid), ncol = nbasis)
  for (j in 1:nbasis) {
    basis_mat[, j] <- fourier_sin_basis(t_grid, j)
  }
  return(basis_mat)
}

# 生成函数型数据
generate_functional_data <- function(n, p, nbasis, basis_mat) {
  
  all_coef <- array(rnorm(n * p * nbasis, sd = rep(1/(((1:nbasis-0.5)*pi)^2), each = n * p)), 
                    dim = c(n, p, nbasis))
  coef_2d <- matrix(all_coef, nrow = n * p, ncol = nbasis)
  functional_2d <- coef_2d %*% t(basis_mat)
  functional_data <- array(functional_2d, dim = c(n, p, nrow(basis_mat)))
  
  return(functional_data)
}

nt=201
t_grid <- seq(0, 1, length.out = nt)
basis_mat <- create_basis_matrix(t_grid, nbasis)


##########################
### Fearture Screening ###
##########################
startTime<-Sys.time()

runfunc <- function(mm){
  set.seed(mm)
  
  library(expm)
  library(MASS)
  library(rmutil)#Laplace
  library(evd)#gumble
  library(actuar)#RW
  library(energy)
  library(gcdnet)
  
  
  source('KCED.R')
  
  data_X <- generate_functional_data(n, p, nbasis, basis_mat)
  beta <- beta_t(t_grid[2:nt])
  X_2d <- matrix(data_X[,1:p_0,2:nt] , nrow = n * p_0, ncol = (nt-1))
  betaX_2d <- X_2d %*% beta/(nt-1)
  betaX <- matrix(betaX_2d, nrow = n , ncol = p_0)
  
  epsilon <- rnorm(n)

  KCED_re <- matrix(0,5,p)
  
  for(idx_tau in 1:5){
    f_e <- function(theta){
      mean(ifelse(epsilon-theta<0,1-tau_0[idx_tau],tau_0[idx_tau])*(epsilon-theta)^2)
    } 
    mu_e <- optimize(f_e, interval = c(-1000, 1000))$minimum
    epsilon_0 <- epsilon - mu_e
    
    Y<- 2*rowSums(betaX)+ epsilon_0
    
    f_Y <- function(theta){
      mean(ifelse(Y-theta<0,1-tau_0[idx_tau],tau_0[idx_tau])*(Y-theta)^2)
    } 
    mu_Y <- optimize(f_Y, interval = c(-1000, 1000))$minimum
    
    ###################
    ### test for KCED #
    ###################
    KCED_re[idx_tau,] <- KCED_fun(data_X,Y,tau_0[idx_tau],mu_Y)
    
  }
  
  fin_result <- c(KCED_re[1,],KCED_re[2,],KCED_re[3,],KCED_re[4,],KCED_re[5,])
  return(fin_result)
}

cl<-makeCluster(15)
registerDoParallel(cl)
kdcovresult <- foreach(m=1:M,.combine='rbind') %dopar% {
  runfunc(m)
}
stopCluster(cl)

endTime<-Sys.time()
print(difftime(endTime,startTime, units ="mins"))

write.csv(kdcovresult,file = "sim_case2_n200_p2000_norm.csv")
                                        #n50,n100,n150,n200,n200_p1000,n200_p1500,n200_p2000

#############################
### compute the criterion ###
#############################

#kdcovresult <- as.matrix(read.csv("sim_case2_n100_bimodal.csv")[,-1])

KCED_re <- list()
for(i in 1:5){
  KCED_re[[i]]=kdcovresult[,((i-1)*p+1):(i*p)]
}

Lg <- length(goal_1)

KCED_X = list()
for (i in 1:5) {
  KCED_X[[i]]  = matrix(0, nrow = M, ncol = Lg)  
}
KCED_size = matrix(0,5,M)


for(m in 1:M){
  
  for(i in 1:5){
    KCED_order =order(KCED_re[[i]][m,], decreasing = TRUE)
    for(j in 1:Lg){
      KCED_X[[i]][m,j] <- as.numeric(goal_1[j] %in% KCED_order[1:d])
    }
    KCED_size[i,m] <- max(match(goal_1, KCED_order))
  }
  
}


for(j in 1:Lg){
  print(j)
  for(i in 1:5){
    print(c(mean(KCED_X[[i]][,j])))
  }
}

for(i in 1:5){
  print(c(median(KCED_size[i,])))
}
