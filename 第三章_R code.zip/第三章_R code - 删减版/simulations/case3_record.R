
n <- 200 #100,200
p <- 1000 
M <- 500 
rho <- 0.6 
d <- round(n/log(n))

tau_H <- seq(1/n,(n-1)/n,1/n)

goal_1<- c(1,2,7)

#############################
### compute the criterion ###
#############################

result_fin_X <- matrix(0,15,8)
result_fin_size <- matrix(0,5,8)
result_table <- matrix(0,40,4)

for(ii in 1:5){
  if(ii == 1){
    kdcovresult <- as.matrix(read.csv("sim_case3_n100_norm.csv")[,-1])#n200
  }else if(ii==2){
    kdcovresult <- as.matrix(read.csv("sim_case3_n100_t.csv")[,-1])#n200
  }else if(ii==3){
    kdcovresult <- as.matrix(read.csv("sim_case3_n100_laplace.csv")[,-1])#n200
  }else if(ii==4){
    kdcovresult <- as.matrix(read.csv("sim_case3_n100_gumbel.csv")[,-1])#n200
  }else if(ii==5){
    kdcovresult <- as.matrix(read.csv("sim_case3_n100_bimodal.csv")[,-1])#n200
  }
  
  n_method <- 8
  Lg <- length(goal_1)
  fin_X <- list()
  fin_size <- matrix(0,n_method,M)
  result_X <- matrix(0,Lg,n_method)
  result_size <- rep(0,n_method)
  
  for(i in 1:n_method){
    
    fin_re = kdcovresult[,(1+(i-1)*p):(i*p)]
    #if(i==4){fin_re=fin_re^2}
    
    fin_X1 <- matrix(0,M,Lg)
    for(m in 1:M){
      fin_order = order(fin_re[m,], decreasing = TRUE)
      for(j in 1:Lg){
        fin_X1[m,j] <- as.numeric(goal_1[j] %in% fin_order[1:d])
        fin_X[[i]] <- fin_X1
      }
      fin_size[i,m] <- max(match(goal_1, fin_order))
    }
    
    for(j in 1:Lg){
      result_X[j,i] <- mean(fin_X[[i]][,j])
    }
    result_size[i] <- median(fin_size[i,])
  }
  
  result_fin_X[(1+Lg*(ii-1)):(Lg*ii),]<- result_X
  result_fin_size[ii,]<- result_size
  result_table[(ii*8-7):(ii*8),1:3] <- t(result_X)
  result_table[(ii*8-7):(ii*8),4] <- result_size
}


write.csv(result_table,file = "case3_result_fin_table_n100.csv")
#write.csv(result_table,file = "case3_result_fin_table_n200.csv")

