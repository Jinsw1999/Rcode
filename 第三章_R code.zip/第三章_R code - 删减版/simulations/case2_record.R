



#############################
### compute the criterion ###
#############################

result_fin_size <- matrix(0,5,8)
p_0=5
M=100

for(ii in 1:8){
  if(ii == 1){
    p=500
    kdcovresult <- as.matrix(read.csv("sim_case2_n50_norm.csv")[,-1])
  }else if(ii==2){
    p=500
    kdcovresult <- as.matrix(read.csv("sim_case2_n100_norm.csv")[,-1])
  }else if(ii==3){
    p=500
    kdcovresult <- as.matrix(read.csv("sim_case2_n150_norm.csv")[,-1])
  }else if(ii==4){
    p=500
    kdcovresult <- as.matrix(read.csv("sim_case2_n200_norm.csv")[,-1])
  }else if(ii==5){
    p=500
    kdcovresult <- as.matrix(read.csv("sim_case2_n200_norm.csv")[,-1])
  }else if(ii==6){
    p=1000
    kdcovresult <- as.matrix(read.csv("sim_case2_n200_p1000_norm.csv")[,-1])
  }else if(ii==7){
    p=1500
    kdcovresult <- as.matrix(read.csv("sim_case2_n200_p1500_norm.csv")[,-1])
  }else if(ii==8){
    p=2000
    kdcovresult <- as.matrix(read.csv("sim_case2_n200_p2000_norm.csv")[,-1])
  }
  
  KCED_re <- list()
  for(i in 1:5){
    KCED_re[[i]]=kdcovresult[,((i-1)*p+1):(i*p)]
  }
  
  goal_1<- c(1:p_0)
  Lg <- length(goal_1)
  
  KCED_size = matrix(0,5,M)
  
  for(m in 1:M){
    
    for(i in 1:5){
      KCED_order =order(KCED_re[[i]][m,], decreasing = TRUE)
      KCED_size[i,m] <- max(match(goal_1, KCED_order))
    }
    
  }

  for(i in 1:5){
    result_fin_size[i,ii] <- median(KCED_size[i,])
  }
}
  
write.csv(result_fin_size,file = "case2_result_fin_table.csv")

