


kdcovresult <- as.matrix(read.csv("case2_result_fin_table.csv")[,-1])
matrix1<-kdcovresult[,1:4]
matrix2<-kdcovresult[,5:8]

col1 <- c(2,3,5,4,"darkorange")

layout(matrix(1:3, 1, 3), widths = c(4, 4, 1.2))

# 第一个图
matplot(c(50, 100, 150, 200), t(matrix1), type = "b", lty = 1:5, lwd = 2,pch = c(16, 15, 17, 18, 19), 
        main = "Change n", xlab = "n", ylab = "minimum model size", col = col1)

# 第二个图
matplot(c(500, 1000, 1500, 2000), t(matrix2), type = "b", lty = 1:5, pch = c(16, 15, 17, 18, 19),lwd = 2,
        main = "Change p", xlab = "p", ylab = "minimum model size", col = col1)

# 图例
plot.new()
legend("center", legend = c("tau=0.05","tau=0.25","tau=0.5","tau=0.75","tau=0.95"), lty = 1:5, lwd = 2, col = col1,pch = c(16, 15, 17, 18, 19),
       bty = "n")

layout(1)










