
rm(list = ls())

library(expm)
library(MASS)
library(rmutil)#Laplace
library(evd)#gumble
library(actuar)#RW
library(doParallel)
library(foreach)
library(energy)
library(gcdnet)


source('KCED.R')
source('prefunction.R')
source('SWL2E.R')
source('EPCS.R')
source('REDC.R')


Beta_type <- c(0.5,1,1.5)  

for(itr in 1:length(Beta_type)){
  
  beta <- Beta_type[itr]
  n <- 100 
  p <- 500 
  M <- 100 
  rho <- 0.6 
  d <- round(n/log(n))
  tau_0 <- c(0.25,0.5,0.75)
  goal_1<- c(1,2,7)
  
  ### Sigma of X
  generate_matrix_with_outer <- function(p, rho) {
    i <- 1:p
    j <- 1:p
    matrix <- outer(i, j, function(x, y) rho^abs(x - y))
    return(matrix)
  }
  Sigma_X <- generate_matrix_with_outer(p,rho = rho)
  
  ##########################
  ### Fearture Screening ###
  ##########################
  
  runfunc <- function(mm){
    set.seed(mm)
    
    library(expm)
    library(MASS)
    library(rmutil)
    library(evd)
    library(actuar)
    library(energy)
    library(gcdnet)
    
    
    source('KCED.R')
    source('prefunction.R')
    source('SWL2E.R')
    source('EPCS.R')
    source('REDC.R')
    
    X <- mvrnorm(n = n, mu = rep(0,p), Sigma = Sigma_X)
    epsilon <- rnorm(n) 
    KCED_re <- REDC_re <- DC_re<- SRoWER_re <- EPCS_re <- matrix(0,3,p)
    SRoWER_kmax <- EPCS_kmax <- rep(0,3)
    
    for(idx_tau in 1:3){
      f_e <- function(theta){
        mean(ifelse(epsilon-theta<0,1-tau_0[idx_tau],tau_0[idx_tau])*(epsilon-theta)^2)
      } 
      mu_e <- optimize(f_e, interval = c(-1000, 1000))$minimum
      epsilon_0 <- epsilon - mu_e
      
      Y <- rep(0,n)
      Y <- 3*X[,1]+1.5*X[,2]+2*beta*(X[,7])^2+X[,20]^2*epsilon_0
      
      f_Y <- function(theta){
        mean(ifelse(Y-theta<0,1-tau_0[idx_tau],tau_0[idx_tau])*(Y-theta)^2)
      } 
      mu_Y <- optimize(f_Y, interval = c(-1000, 1000))$minimum
      
      ###################
      ### test for KCED #
      ###################
      KCED_re[idx_tau,] <- KCED(X,Y,tau_0[idx_tau],mu_Y)
      
      ###################
      ### test for REDC #
      ###################
      REDC_re[idx_tau,] <- REDC(X,Y,tau_0[idx_tau],mu_Y)  
      
      ###################
      ### test for DC #
      ###################
      DC_re[idx_tau,] <- DC(X,Y,tau_0[idx_tau],mu_Y)  
      
      #####################
      ### test for SRoWER #
      #####################
      fit_ii <- SRoWER_fit(Y, X, d, keyset=NULL,
                           max_iter=500, tol=0.001, Pi=1,
                           U_rate=0.5,coef_initial= NULL, tau=tau_0[idx_tau])
      SRoWER_re[idx_tau,fit_ii$ID_retained] <- 1
      
      kk <- 1
      repeat {
        fit_ii <- SRoWER_fit(Y, X, kk, keyset=NULL,
                             max_iter=500, tol=0.001, Pi=1,
                             U_rate=0.5,coef_initial= NULL, tau=tau_0[idx_tau])
        result_kk <- fit_ii$ID_retained
        
        if (length(setdiff(goal_1, result_kk)) == 0 || kk==5*d) {
          SRoWER_kmax[idx_tau] <- kk
          break
        }
        
        kk <- kk + 1
      }
      
      ###################
      ### test for EPCS #
      ###################
      fit_1 <- EPCS(X,Y,tau_0[idx_tau],d)
      EPCS_re[idx_tau,fit_1] <- 1
      
      if(length(setdiff(goal_1, fit_1)) == 0){
        EPCS_kmax[idx_tau] <- max(match(goal_1, fit_1))
      }else{
        fit_2 <- EPCS(X,Y,tau_0[idx_tau],5*d)
        if(length(setdiff(goal_1, fit_2)) == 0){
          EPCS_kmax[idx_tau] <- max(match(goal_1, fit_2))
        }else{
          EPCS_kmax[idx_tau]<- 5*d
        }
      }
      
    }
    
    fin_result <- c(KCED_re[1,],KCED_re[2,],KCED_re[3,],
                    REDC_re[1,],REDC_re[2,],REDC_re[3,],
                    DC_re[1,],DC_re[2,],DC_re[3,],
                    SRoWER_re[1,],SRoWER_re[2,],SRoWER_re[3,],SRoWER_kmax,
                    EPCS_re[1,],EPCS_re[2,],EPCS_re[3,],EPCS_kmax)
    return(fin_result)
  }
  
  startTime<-Sys.time()
  
  cl<-makeCluster(15)
  registerDoParallel(cl)
  kdcovresult <- foreach(m=1:M,.combine='rbind') %dopar% {
    runfunc(m)
  }
  stopCluster(cl)
  
  endTime<-Sys.time()
  print(difftime(endTime,startTime, units ="mins"))
  
  
  if(itr==1){
    write.csv(kdcovresult,file = "sim_case4_beta0.5.csv")
  }else if(itr==2){
    write.csv(kdcovresult,file = "sim_case4_beta1.csv")
  }else if(itr==3){
    write.csv(kdcovresult,file = "sim_case4_beta1.5.csv")
  }
  
}


#Time difference of 123.9054 mins
#Time difference of 117.6311 mins
#Time difference of 118.8582 mins
