
n <- 100 
p <- 500 
M <- 100 
rho <- 0.6 
d <- round(n/log(n))


tau_0 <- c(0.25,0.5,0.75)

goal_1<- c(1,2,7)

#############################
### compute the criterion ###
#############################

result_fin_X <- matrix(0,9,15)
result_fin_size <- matrix(0,9,5)

for(ii in 1:3){
  if(ii == 1){
    kdcovresult <- as.matrix(read.csv("sim_case4_beta0.5.csv")[,-1])
  }else if(ii==2){
    kdcovresult <- as.matrix(read.csv("sim_case4_beta1.csv")[,-1])
  }else if(ii==3){
    kdcovresult <- as.matrix(read.csv("sim_case4_beta1.5.csv")[,-1])
  }
  
  KCED_re<-REDC_re<-DC_re<-SRoWER_re<-EPCS_re<-list()
  for(i in 1:3){
    KCED_re[[i]]=kdcovresult[,((i-1)*p+1):(i*p)]
    REDC_re[[i]]=kdcovresult[,((2+i)*p+1):((3+i)*p)]
    DC_re[[i]]=kdcovresult[,((5+i)*p+1):((6+i)*p)]
    SRoWER_re[[i]]=kdcovresult[,((8+i)*p+1):((9+i)*p)]
    EPCS_re[[i]]=kdcovresult[,((11+i)*p+4):((12+i)*p+3)]
  }
  SRoWER_kmax= kdcovresult[,(12*p+1):(12*p+3)]
  EPCS_kmax= kdcovresult[,(15*p+4):(15*p+6)]
  
  Lg <- length(goal_1)
  
  KCED_X = REDC_X = DC_X = SRoWER_X = EPCS_X = list()
  for (i in 1:3) {
    KCED_X[[i]] = REDC_X[[i]] = DC_X[[i]] = SRoWER_X[[i]] = EPCS_X[[i]] = matrix(0, nrow = M, ncol = Lg)  
  }
  KCED_size = REDC_size = DC_size = SRoWER_size = EPCS_size = matrix(0,3,M)
  
  
  for(m in 1:M){
    
    for(i in 1:3){
      KCED_order =order(KCED_re[[i]][m,], decreasing = TRUE)
      REDC_order =order(REDC_re[[i]][m,], decreasing = TRUE)
      DC_order =order(DC_re[[i]][m,], decreasing = TRUE)
      SRoWER_order =order(SRoWER_re[[i]][m,], decreasing = TRUE)
      EPCS_order =order(EPCS_re[[i]][m,], decreasing = TRUE)
      for(j in 1:Lg){
        KCED_X[[i]][m,j] <- as.numeric(goal_1[j] %in% KCED_order[1:d])
        REDC_X[[i]][m,j] <- as.numeric(goal_1[j] %in% REDC_order[1:d])
        DC_X[[i]][m,j] <- as.numeric(goal_1[j] %in% DC_order[1:d])
        SRoWER_X[[i]][m,j] <- as.numeric(goal_1[j] %in% SRoWER_order[1:d])
        EPCS_X[[i]][m,j] <- as.numeric(goal_1[j] %in% EPCS_order[1:d])
      }
      KCED_size[i,m] <- max(match(goal_1, KCED_order))
      REDC_size[i,m] <- max(match(goal_1, REDC_order))
      DC_size[i,m] <- max(match(goal_1, DC_order))
      SRoWER_size[i,m] <- SRoWER_kmax[m,i]
      EPCS_size[i,m] <- EPCS_kmax[m,i]
    }
    
  }
  
  for(j in 1:Lg){
    for(i in 1:3){
      result_fin_X[(ii-1)*3+i,(1+(j-1)*5):(5+(j-1)*5)] <- c(mean(KCED_X[[i]][,j]),mean(REDC_X[[i]][,j]),mean(DC_X[[i]][,j]),mean(SRoWER_X[[i]][,j]),mean(EPCS_X[[i]][,j]))
    }
  }
  
  for(i in 1:3){
    result_fin_size[(ii-1)*3+i,1:5] <- c(median(KCED_size[i,]),median(REDC_size[i,]),median(DC_size[i,]),median(SRoWER_size[i,]),median(EPCS_size[i,]))
    
  }
  
}
write.csv(result_fin_X,file = "case4_result_fin_X.csv")
write.csv(result_fin_size,file = "case4_result_fin_size.csv")

