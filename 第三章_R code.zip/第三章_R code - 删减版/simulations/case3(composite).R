###################
## case 1: n=100 ##
###################


rm(list = ls())

library(expm)
library(MASS)
library(rmutil)#Laplace
library(evd)#gumble
library(actuar)#RW
library(doParallel)
library(foreach)
library(energy)
library(gcdnet)


source('KCED.R')
source('screening methods.R')


Error_type <- c(1:5)  #1,2,3,4,5,6


for(itr in 1:length(Error_type)){
  
  error_type = Error_type[itr]
  
  
  n <- 100 #100,200
  p <- 1000 #500
  M <- 500 
  rho <- 0.6 
  d <- round(n/log(n))
  
  tau_H <- seq(1/n,(n-1)/n,1/n)
  goal_1<- c(1,2,7)
  
  ### Sigma of X
  generate_matrix_with_outer <- function(p, rho) {
    i <- 1:p
    j <- 1:p
    matrix <- outer(i, j, function(x, y) rho^abs(x - y))
    return(matrix)
  }
  Sigma_X <- generate_matrix_with_outer(p,rho = rho)
  
  
  
  ##########################
  ### Fearture Screening ###
  ##########################
  
  runfunc <- function(mm){
    set.seed(mm)
    
    library(expm)
    library(MASS)
    library(rmutil)
    library(evd)
    library(actuar)
    library(energy)
    library(gcdnet)
    
    
    source('KCED.R')
    source('screening methods.R')
    
    X <- mvrnorm(n = n, mu = rep(0,p), Sigma = Sigma_X)
    
    if(error_type==1){
      epsilon <- rnorm(n) 
    }else if(error_type==2){
      epsilon <- rt(n,3) 
    }else if(error_type==3){
      epsilon <- rlaplace(n,0,1)
    }else if(error_type==4){
      epsilon <- rgumbel(n,0,1.5)
    }else if(error_type==5){
      eta<-rbinom(n, size = 1, prob = 0.2)  
      epsilon <- eta*rnorm(n,-3,1)+(1-eta)*rnorm(n,3,sqrt(5))
    }else if(error_type==6){
      epsilon <- rinvweibull(n, shape = 1.35, scale = 3)
    }
  
    Y <- rep(0,n)
    Y <- 3*X[,1]+1.5*X[,2]+2*(X[,7])^2+epsilon
      
    CKCED_re <- SIS_re <- SIRS_re <- DCSIS_re <- rep(0,p)
    RRCS_re <- RQCSIS_re <- DC_RoSIS_re <- CRQDCS_re <- rep(0,p)
      
    ####################
    ### test for CKCED #
    ####################
    CKCED_re <- CKCED(X,Y,tau_H)
      
    ##################
    ### test for SIS #
    ##################
    SIS_re <- SIS(X,Y)  
      
    ###################
    ### test for SIRS #
    ###################
    SIRS_re <- SIRS(X,Y)  
      
    ####################
    ### test for DCSIS #
    ####################
    DCSIS_re <- DCSIS(X,Y)  
      
    ###################
    ### test for RRCS #
    ###################
    RRCS_re <- RRCS(X,Y)  
      
    #####################
    ### test for RQCSIS #
    #####################
    RQCSIS_re <- RQCSIS(X,Y,tau_H)  
      
    #######################
    ### test for DC_RoSIS #
    #######################
    DC_RoSIS_re <- DC_RoSIS(X,Y)  
      
    #####################
    ### test for CRQDCS #
    #####################
    CRQDCS_re <- CRQDCS(X,Y,tau_H)  
      
    fin_result <- c(CKCED_re,SIS_re,SIRS_re,DCSIS_re,
                    RRCS_re,RQCSIS_re,DC_RoSIS_re,CRQDCS_re)
    return(fin_result)
  }
  
  startTime<-Sys.time()
  
  cl<-makeCluster(15)
  registerDoParallel(cl)
  kdcovresult <- foreach(m=1:M,.combine='rbind') %dopar% {
    runfunc(m)
  }
  stopCluster(cl)
  
  endTime<-Sys.time()
  print(difftime(endTime,startTime, units ="mins"))
  
  
  if(error_type==1){
    write.csv(kdcovresult,file = "sim_case4_n100_norm.csv")
  }else if(error_type==2){
    write.csv(kdcovresult,file = "sim_case4_n100_t.csv")
  }else if(error_type==3){
    write.csv(kdcovresult,file = "sim_case4_n100_laplace.csv")
  }else if(error_type==4){
    write.csv(kdcovresult,file = "sim_case4_n100_gumbel.csv")
  }else if(error_type==5){
    write.csv(kdcovresult,file = "sim_case4_n100_bimodal.csv")
  }else if(error_type==6){
    write.csv(kdcovresult,file = "sim_case4_n100_reweibull.csv")
  }
  
}

#Time difference of 12.56221 mins
#Time difference of 12.60097 mins
#Time difference of 12.48498 mins
#Time difference of 12.64972 mins
#Time difference of 12.54469 mins

###################
## case 2: n=200 ##
###################


rm(list = ls())

library(expm)
library(MASS)
library(rmutil)#Laplace
library(evd)#gumble
library(actuar)#RW
library(doParallel)
library(foreach)
library(energy)
library(gcdnet)


source('KCED.R')
source('screening methods.R')


Error_type <- c(1:5)  #1,2,3,4,5,6


for(itr in 1:length(Error_type)){
  
  error_type = Error_type[itr]
  
  
  n <- 200 #100,200
  p <- 1000 #500
  M <- 500 
  rho <- 0.6 
  d <- round(n/log(n))
  
  tau_H <- seq(1/n,(n-1)/n,1/n)
  goal_1<- c(1,2,7)
  
  ### Sigma of X
  generate_matrix_with_outer <- function(p, rho) {
    i <- 1:p
    j <- 1:p
    matrix <- outer(i, j, function(x, y) rho^abs(x - y))
    return(matrix)
  }
  Sigma_X <- generate_matrix_with_outer(p,rho = rho)
  
  
  
  ##########################
  ### Fearture Screening ###
  ##########################
  
  runfunc <- function(mm){
    set.seed(mm)
    
    library(expm)
    library(MASS)
    library(rmutil)
    library(evd)
    library(actuar)
    library(energy)
    library(gcdnet)
    
    
    source('KCED.R')
    source('screening methods.R')
    
    X <- mvrnorm(n = n, mu = rep(0,p), Sigma = Sigma_X)
    
    if(error_type==1){
      epsilon <- rnorm(n) 
    }else if(error_type==2){
      epsilon <- rt(n,3) 
    }else if(error_type==3){
      epsilon <- rlaplace(n,0,1)
    }else if(error_type==4){
      epsilon <- rgumbel(n,0,1.5)
    }else if(error_type==5){
      eta<-rbinom(n, size = 1, prob = 0.2)  
      epsilon <- eta*rnorm(n,-3,1)+(1-eta)*rnorm(n,3,sqrt(5))
    }else if(error_type==6){
      epsilon <- rinvweibull(n, shape = 1.35, scale = 3)
    }
    
    Y <- rep(0,n)
    Y <- 3*X[,1]+1.5*X[,2]+2*(X[,7])^2+epsilon
    
    CKCED_re <- SIS_re <- SIRS_re <- DCSIS_re <- rep(0,p)
    RRCS_re <- RQCSIS_re <- DC_RoSIS_re <- CRQDCS_re <- rep(0,p)
    
    ####################
    ### test for CKCED #
    ####################
    CKCED_re <- CKCED(X,Y,tau_H)
    
    ##################
    ### test for SIS #
    ##################
    SIS_re <- SIS(X,Y)  
    
    ###################
    ### test for SIRS #
    ###################
    SIRS_re <- SIRS(X,Y)  
    
    ####################
    ### test for DCSIS #
    ####################
    DCSIS_re <- DCSIS(X,Y)  
    
    ###################
    ### test for RRCS #
    ###################
    RRCS_re <- RRCS(X,Y)  
    
    #####################
    ### test for RQCSIS #
    #####################
    RQCSIS_re <- RQCSIS(X,Y,tau_H)  
    
    #######################
    ### test for DC_RoSIS #
    #######################
    DC_RoSIS_re <- DC_RoSIS(X,Y)  
    
    #####################
    ### test for CRQDCS #
    #####################
    CRQDCS_re <- CRQDCS(X,Y,tau_H)  
    
    fin_result <- c(CKCED_re,SIS_re,SIRS_re,DCSIS_re,
                    RRCS_re,RQCSIS_re,DC_RoSIS_re,CRQDCS_re)
    return(fin_result)
  }
  
  startTime<-Sys.time()
  
  cl<-makeCluster(15)
  registerDoParallel(cl)
  kdcovresult <- foreach(m=1:M,.combine='rbind') %dopar% {
    runfunc(m)
  }
  stopCluster(cl)
  
  endTime<-Sys.time()
  print(difftime(endTime,startTime, units ="mins"))
  
  
  if(error_type==1){
    write.csv(kdcovresult,file = "sim_case4_n200_norm.csv")
  }else if(error_type==2){
    write.csv(kdcovresult,file = "sim_case4_n200_t.csv")
  }else if(error_type==3){
    write.csv(kdcovresult,file = "sim_case4_n200_laplace.csv")
  }else if(error_type==4){
    write.csv(kdcovresult,file = "sim_case4_n200_gumbel.csv")
  }else if(error_type==5){
    write.csv(kdcovresult,file = "sim_case4_n200_bimodal.csv")
  }else if(error_type==6){
    write.csv(kdcovresult,file = "sim_case4_n200_reweibull.csv")
  }
  
}


#Time difference of 29.4522 mins
#Time difference of 29.7095 mins
#Time difference of 29.72997 mins
#Time difference of 30.468 mins
#Time difference of 29.58169 mins