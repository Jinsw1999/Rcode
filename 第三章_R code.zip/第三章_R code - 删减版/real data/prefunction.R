weightfunction <- function(x, y, tau = 0.5){
  ernet.object <- cv.gcdnet(x=x, y=y, method = "er", omega = tau)  # gcdnet package
  betaen <-  as.numeric(gcdnet(x=x, y=y, method = "er", lambda=ernet.object$lambda.min, omega = tau)$beta )  
  er <- y - x%*%betaen
  wt <- c(er < 0)*(1-tau) + c(er >= 0)*tau
  aa <- exp(-wt*(er^2))
  bb <-sum(aa)
  Pi <- aa/bb
  Pi <- as.matrix(Pi) 
  return(Pi)
}


##compare second derivative function of obj func with regularization term
Uh0 <- function(A, uh, b0, b1){
  bb <- b1 - b0 ### 
  in_b <- (1:length(bb))[bb != 0] 
  if(length(in_b) != 0){
    bt <- bb[in_b]
    bt <- as.matrix(bt, ncol=1) 
  tm1 <-  crossprod(bt) / uh 
  tm2 <-  crossprod(A[,in_b]%*%bt)      
  Bt <- exp(tm1 - tm2)   
  }
  else Bt=2
  return(Bt)
 }
 
##objective function
####likelihood function
wl2e <- function(y, x, beta, Pi, tau){
  n <- nrow(x)
  p <- ncol(x) 
  ind_0 <- which(beta != 0) 
  bc_0 <- as.matrix(beta[ind_0], ncol = 1)
  xs_0 <- x[, ind_0, drop=FALSE]
  R_0 <- xs_0 %*% bc_0
  err <- y - R_0
  wt <- c(err < 0)*(1-tau) + c(err >= 0)*tau
  sig <- sum(Pi*wt*(y - R_0)^2)
  return(sig) 
}


##hard thresholding
Hard <- function(t, k, lam = 1){
  #----------------------------------------------------------------------------#
  # Hard threshold function                                                    #
  #----------------------------------------------------------------------------#
  # This function keep the k elements with the larges absolute value and       #
  # truncated the rest to zero.                                                #
  #----------------------------------------------------------------------------#
  # Parameters:                                                                #
  # t : A list of values.                                                      #
  # k:  number of values retained.                                             #
  #----------------------------------------------------------------------------#
  ht <- t
  t <- abs(t)
  if(k > 0){ lam <- sort(t, decreasing = TRUE)[k] }
  ht[t < lam] <- 0
  return(ht)
} 

sub_off <- function(all, sub){
  S <- all[!(all %in% sub)]
  return(S)
}
#statistics to evaluate the estimator
stat_validation <- function(hb, beta0){
  m0 <- which(beta0!=0)
  hm <- which(hb!=0)
  RC <- as.numeric(all(m0 %in% hm))
  PSR <- length(intersect(hm, m0)) / length(m0) 
  FDR <- length(setdiff(hm, m0))/ length(hm) 
  MSE <- norm(hb - beta0, "2")
  return(list(RC = RC, PSR = PSR, FDR = FDR, MSE = MSE))
}