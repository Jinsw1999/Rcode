SRoWER_fit <- function(y, x, k, keyset = NULL,
                       max_iter = 500, tol = 0.01, Pi = 1,
                      U_rate = 0.5, coef_initial = NULL, tau = tau){
  
  Wl2e <- rep(0, max_iter)
  FD <- NULL # Number of differences in retained features between adjacent steps
  number_of_Ucheck <- rep(0, max_iter)    # Vector of number of Ucheck steps per iteration
  n <- nrow(x)
  p <- ncol(x) 
  ernet.object <- cv.gcdnet(x=x, y=y, method = "er", omega = tau, eps = 1e-6)  # gcdnet package ###Jin Shiwen add ",lambda = exp(seq(-6, 2, length = 50)), eps = 1e-4"
  beta_l <- as.numeric(gcdnet(x=x, y=y, method = "er", lambda=ernet.object$lambda.min, omega = tau)$beta )  
  if( is.null( coef_initial ) ){            ######if initial value is null, then define beta in fit_pre as initial value
    beta0 <- beta_l
  }else beta0 <- coef_initial 
  if(is.null(keyset)){
    number_of_ID_retained <- k
  }else number_of_ID_retained <- k - (length(keyset))  #keyset is a covariate that must be preserved for a preset
  
  x_iter <- x
  ID_None0 <- (1:p)[beta0!=0] 
  Screening_index <- sub_off(1:p, keyset) 
  # function sub_off(all,sub)is that removes all elements from one list (all) that match elements in another list (sub).
  beta_path <- as.matrix(beta0, nrow = p, ncol = 1)
  I <- list(CM = x, y = y, IM = x_iter, beta0 = beta0)
  coef_None0 <- as.matrix(beta0[ID_None0], ncol=1)
  xs_0 <- x_iter[, ID_None0]
  xs_0 <- as.matrix(xs_0)
  if(!is.null(coef_initial) & sum(coef_initial!=0)==0){ 
    R_0 <- matrix(0, ncol = 1, nrow = n) 
  }else R_0 <- xs_0 %*% coef_None0
  er <- y - R_0
  wt <- c(er < 0)*(1-tau) + c(er >= 0)*tau 
  V_0 <- t(x_iter)%*%(2*Pi*wt*er)
  #When starts from zero with uu is 1/||X||\infit = 1/sqrt(n) 
  uu <- 1/max(colSums(xs_0^2))
  U_s <- uu
   #iteration start form 1
   i <- 1
   beta_s <- beta0
   # iteration start---------------------------
   repeat{
     count<-0
     repeat{
       beta_t<- beta_s + uu * V_0
       beta_t[Screening_index]<- Hard(t = beta_t[Screening_index], k = number_of_ID_retained)
       ucheck <- Uh0(A = x_iter, uh = uu, b0 = beta_s, b1 = beta_t)  
       
       if ( ucheck >= 1 ) break
       else{
         uu <- U_rate * uu             
         count <- count + 1
       }
     }
     sindex <- (1:p)[beta_s!= 0]
     tindex <- (1:p)[beta_t!= 0]
     fs <- sum(!(tindex %in% sindex))
     FD <- c(FD, fs)       
     beta_path <- cbind(beta_path, as.matrix(beta_t, ncol=1, nrow = p))
     Wl2e[i] <- wl2e(y, x_iter, beta_t, Pi, tau)
     valid_Wl2e_diff <- 0.01 *(Wl2e[2] - Wl2e[1])       
     number_of_Ucheck[i] <- count
     ######## convergence check ###################
     MSE <- norm(beta_s-beta_t, "2")
     if((MSE < tol) | (i >= max_iter)) break
     ######################update###############
     beta_s <- beta_t
     ID_None0 <- (1:p)[beta_s!= 0]
     coef_None0 <- as.matrix(beta_s[ID_None0], ncol = 1)
     xs_0 <- x_iter[, ID_None0]
     xs_0 <- as.matrix(xs_0)
     R_0  <- xs_0 %*% coef_None0
     er <- y - R_0
     wt <- c(er < 0)*(1-tau) + c(er >= 0)*tau
     V_0 <- t(x_iter)%*%(2*Pi*wt*er)
     uu <- U_s
     i <- i + 1
   }
   
   fit <- list(X = x, Y = y,  keyset = keyset, k = k, steps = i,
             WL2E_iter = Wl2e[1:i], usearch = number_of_Ucheck[1:i], path_retained  = beta_path, num_retained   = length(ID_None0),
             ID_retained = ID_None0, coef_retained  = coef_None0, FD = FD, MSE = MSE)
   
   fit
}


HBIC <- function(x, y, k = NULL, Pi = 1, tau = 0.5){
  n <- nrow(x)
  p <- ncol(x)  
  ks <- round(log(n)*n^(1/3))
  if(is.null(k)) k <- ks 
  hbic_val <- numeric(k-1)
  Beta_hbic <- ID_retained_hbic <- list() 
  for(ii in 1:(k-1)){
    fit_ii <- SRoWER_fit(y, x, k = ii+1, keyset=NULL,
                       max_iter=500, tol=0.001, Pi=Pi,
                       U_rate=0.5,coef_initial= NULL, tau=tau)
    Beta_hbic[[ii]] <- fit_ii$coef_retained
    ID_retained_hbic[[ii]] <- fit_ii$ID_retained
    x_retained <- x[, fit_ii$ID_retained, drop=FALSE]
    Wl2e_ii <- wl2e(y, x_retained, Beta_hbic[[ii]], Pi, tau)
    hbic_val[ii] <- log(Wl2e_ii/n) + log(n)* ii*log(p)/(2*n)
  }
  k_min <- which.min(hbic_val)
  beta <- Beta_hbic[[k_min]]
  ID_retained <- ID_retained_hbic[[k_min]]
  return(list(k = k_min, beta = beta, ID_retained = ID_retained))
}


if(0){
  n <- 100
  p <- 500 
  DATA <- datagen(n, p, tau = 0.5, correlation = "AR", error = "normal")
  
  k = round(log(n)*n^(1/3))
  Pi <- weightfunction(Y=Y, X=X, tau = tau) 
  
  HBIC(x=DATA$X, y=DATA$Y, Pi = Pi, tau = 0.5)
}
