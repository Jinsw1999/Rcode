rm(list = ls())

library(BiocManager)
library(GEOquery)
library(doParallel)
library(foreach)
library(energy)
library(gcdnet)

#######################
# data pre-processing #
#######################
gse <- getGEO(filename = "GSE5680_series_matrix.txt.gz")
expr_data <- exprs(gse)
sample_info <- pData(gse)
feature_info <- fData(gse)
id_noncontrol <- which(feature_info[,6]=="Consensus sequence") #gain 31042 probes
id_TRIM32 <- which(row.names(expr_data)=="1389163_at") 
expr_TRIM32 <- expr_data[id_TRIM32,] #response Y
X0 <- as.matrix(expr_data[id_noncontrol,])
n <- ncol(X0)

### gain 18986 probes
global_25th <- quantile(X0, probs = 0.25, na.rm = TRUE)
probe_max <- apply(X0, 1, max, na.rm = TRUE)
expressed <- (probe_max >= global_25th)  
probe_range <- apply(X0, 1, function(x) {
  diff(range(x, na.rm = TRUE))  # log2(最大值) - log2(最小值)
})
variable <- (probe_range >= 1)  # log2范围≥1 对应2倍变化
keep_probes <- expressed & variable
expr_matrix <- X0[keep_probes, ] 
p_0 <- nrow(expr_matrix)
expr_matrix <- expr_matrix[rownames(expr_matrix) != "1389163_at", ]

write.csv(expr_matrix,file = "GSE5680_probes_18986.csv")
write.csv(expr_TRIM32,file = "GSE5680_probes_TRIM32.csv")


