
epcor <- function(X,Y,tau,S){
  
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  XX <- cbind(rep(1,n),X)
  
  ### S：a list
  
  fin_epcor <- rep(0,p)
  for(j in 1:p){
    
    S_j <- c(1,(S[[j]]+1))
    Xm_j <- length(S_j)
    
    func_mu <- function(mu) {
      return(mean((X[,j]-XX[,S_j] %*% mu)^2))
    }
    hat_mu <- optim(par = rep(0,Xm_j),  
                    fn = func_mu, 
                    method = "BFGS")$par
    #print(hat_mu)
    
    func_pi <- function(pi_0) {
      return(mean((Y-XX[,S_j] %*% pi_0)^2*ifelse(Y-XX[,S_j] %*% pi_0 < 0,1-tau,tau)))  
    }
    hat_pi <- optim(par = rep(0,Xm_j),  
                       fn = func_pi, 
                       method = "BFGS")$par
    #print(hat_pi)
    
    hat_sigma0 <- mean(((Y-XX[,S_j] %*% hat_pi)*ifelse(Y-XX[,S_j] %*% hat_pi < 0,1-tau,tau))^2)
    hat_sigmaj <- mean((X[,j]-XX[,S_j] %*% hat_mu)^2)
    hat_phij <- mean(((Y-XX[,S_j] %*% hat_pi)*ifelse(Y-XX[,S_j] %*% hat_pi < 0,1-tau,tau))*(X[,j]-XX[,S_j] %*% hat_mu))
    
    fin_epcor[j] <- hat_phij/sqrt(hat_sigma0*hat_sigmaj)
  }
  return(fin_epcor)
}


epcor_Sj <- function(X,alpha=0.05){
  
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  XX <- cbind(rep(1,n),X)
  
  rho_cor <- cor(X, method = "pearson")
  diag(rho_cor) <- 0
  
  S_results <- list() 
  mj_star <- rep(0,p)
  
  ######## find m_j and S_j

  for(j in 1:p){
    
    order_rho <- order(abs(rho_cor[j,]), decreasing = TRUE)
    
    for(m_j in 1:(p-1)){
      S_j <- sort(order_rho[1:m_j])
      
      if( j %in% S_j ){
        S_j <- sort(order_rho[1:(m_j+1)])
        S_j <- S_j[S_j != j]
      }
      
      S_j1 <- c(1,(S_j+1))
      Q <- diag(1,n)-XX[,S_j1]%*%solve(t(XX[,S_j1])%*%XX[,S_j1])%*%t(XX[,S_j1])
      QX <- Q%*%X
      QXX_norm <- sqrt(diag(t(QX) %*% QX))
      c_jk <- QXX_norm[j] * QXX_norm /n
      I_jk <- 1/c_jk *t(X[,j])%*%Q%*%X/n
      target_goal <- setdiff(1:p, c(S_j,j))
      F_jk <- 0.5*log((1+I_jk[target_goal])/(1-I_jk[target_goal]))
      Z_jk <- sqrt(n-m_j-3)*max(F_jk)
      if(Z_jk <= qnorm(1 - alpha/2)){
        mj_star[j]<- m_j
        S_results[[j]] = S_j 
        break
      }else if(m_j >= floor(sqrt(n/log(n)))){
        mj_star[j]<- floor(sqrt(n/log(n)))
        S_j1 <- sort(order_rho[1:mj_star[j]])
        if( j %in% S_j1 ){
          S_j1 <- sort(order_rho[1:(mj_star[j]+1)])
          S_j1 <- S_j1[S_j1 != j]
        }
        S_results[[j]] = S_j1
        break
      }

    }
  }
  return(S_results)
  
}


EPCS <- function(X,Y,tau,d){ 
  #d <- floor(n/log(n))
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  d_star <- floor(2*sqrt(n/log(n)))
  
  S_vj <- epcor_Sj(X,alpha=0.05)
  Alpha_k <- c()
  
  for(k in 1:d_star){
    if(k > d){
      return(Alpha_k)
    }
    S_j <- lapply(S_vj, function(x) union(Alpha_k,x))
    fin_epcor <- abs(epcor(X,Y,tau,S_j))
    valid_indices <- setdiff(1:p, Alpha_k)
    max_index_in_valid <- which.max(fin_epcor[valid_indices])[1]
    j_star <- valid_indices[max_index_in_valid]
    Alpha_k <- c(Alpha_k,j_star)
  }
  
  Alpha_dstar <-  Alpha_k
  if(d_star==d){
    return(Alpha_k)
  }else{
    S_j <- lapply(S_vj, function(x) union(Alpha_dstar,x))
    fin_epcor <- abs(epcor(X,Y,tau,S_j))
    valid_indices <- setdiff(1:p, Alpha_dstar)
    max_index_in_valid <- order(fin_epcor[valid_indices], decreasing = TRUE)
    Alpha_k <- c(Alpha_k,valid_indices[max_index_in_valid])
    return(Alpha_k[1:d])
  }
  
}





