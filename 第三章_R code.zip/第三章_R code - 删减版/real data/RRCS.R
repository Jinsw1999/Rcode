
RRCS <- function(X,Y){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  ### 对协变量 X 的每个分量计算对应的RRCS统计量
  RRCS<- rep(0,p)
  
  for(idx in 1:p){
    x <- X[,idx]
    IX  <- matrix(as.numeric(outer(x, x, "<")), nrow = n)
    IY  <- matrix(as.numeric(outer(Y, Y, "<")), nrow = n)
    ### 计算统计量KCED
    RRCS[idx] <- sum(IX*IY)/(n*(n-1))-1/4 ##KCED is the statistic
    
  }
  return(RRCS)
}