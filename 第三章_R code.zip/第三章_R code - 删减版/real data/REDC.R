# REDC 估计
# X: 协变量矩阵（n×p）
# Y: 响应变量（n×1）
# tau: tau-th expectile 
# tau_H: composite tau-ths （H×1）
# 输出：作用于X的各个分量所得到的统计量REDC值（p×1）


REDC <- function(X,Y,tau,mu_Y= NULL){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  
  ### 计算Y对应的tau-expectile的估计值: mu_Y
  if( is.null( mu_Y ) ){           
    f <- function(theta){
      mean(ifelse(Y-theta<0,1-tau,tau)*(Y-theta)^2)
    } 
    mu_Y <- optimize(f, interval = c(-1000, 1000))$minimum
    
  }else mu_Y <- mu_Y
  
  
  ### 计算Y对应的 D_Y=(D_ij)
  W <- ifelse(Y-mu_Y<0,1-tau,tau)*(Y-mu_Y)
  
  ### 对协变量 X 的每个分量计算对应的REDC统计量
  REDC_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    # 计算经验分布函数
    ecdf_func <- ecdf(x)
    # 获取在原始样本点处的取值
    Fx <- ecdf_func(x)
    ### 计算统计量KCED
    REDC_finresult[idx] <- dcor(Fx, W)^2
    
  }
  return(REDC_finresult)
}

CREDC <- function(X,Y,tau_H){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  H <- length(tau_H)
  
  
  ### 计算Y对应的expectile的估计值mu_Y,及矩阵W
  mu_Y <- rep(0,H)
  W <- matrix(0,n,H)
  for(idx in 1:H){
    f <- function(theta){
      mean(ifelse(Y-theta < 0,1-tau_H[idx],tau_H[idx])*(Y-theta)^2)
    } 
    mu_Y[idx] <- optimize(f, interval = c(-1000, 1000))$minimum
    W[,idx] <- ifelse(Y-mu_Y[idx] < 0,1-tau_H[idx],tau_H[idx])*(Y-mu_Y[idx])
  }
  
  ### 对协变量 X 的每个分量计算对应的KCED统计量
  CREDC_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    # 计算经验分布函数
    ecdf_func <- ecdf(x)
    # 获取在原始样本点处的取值
    Fx <- matrix(ecdf_func(x),n,1)
    
    ### 计算统计量KCED
    CREDC_finresult[idx] <- dcor(Fx, W)^2
    
  }
  return(CREDC_finresult)
}

DC <- function(X,Y,tau,mu_Y= NULL){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  
  ### 计算Y对应的tau-expectile的估计值: mu_Y
  if( is.null( mu_Y ) ){           
    f <- function(theta){
      mean(ifelse(Y-theta<0,1-tau,tau)*(Y-theta)^2)
    } 
    mu_Y <- optimize(f, interval = c(-1000, 1000))$minimum
    
  }else mu_Y <- mu_Y
  
  
  ### 计算Y对应的 D_Y=(D_ij)
  W <- ifelse(Y-mu_Y<0,1-tau,tau)*(Y-mu_Y)
  
  ### 对协变量 X 的每个分量计算对应的REDC统计量
  DC_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    ### 计算统计量KCED
    DC_finresult[idx] <- dcor(x, W)^2
    
  }
  return(DC_finresult)
}

CDC <- function(X,Y,tau_H){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  H <- length(tau_H)
  
  
  ### 计算Y对应的expectile的估计值mu_Y,及矩阵W
  mu_Y <- rep(0,H)
  W <- matrix(0,n,H)
  for(idx in 1:H){
    f <- function(theta){
      mean(ifelse(Y-theta < 0,1-tau_H[idx],tau_H[idx])*(Y-theta)^2)
    } 
    mu_Y[idx] <- optimize(f, interval = c(-1000, 1000))$minimum
    W[,idx] <- ifelse(Y-mu_Y[idx] < 0,1-tau_H[idx],tau_H[idx])*(Y-mu_Y[idx])
  }
  
  ### 对协变量 X 的每个分量计算对应的KCED统计量
  CDC_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])

    ### 计算统计量KCED
    CDC_finresult[idx] <- dcor(x, W)^2
    
  }
  return(CDC_finresult)
}





