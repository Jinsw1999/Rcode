SIS <- function(X,Y){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)

  SIS_finresult<- rep(0,p)
  
  ### 标准化协变量
  x <- scale(X)
  ### 计算统计量
  omega_1 <- t(x)%*%Y
  SIS_finresult <- abs(omega_1)
    
  return(SIS_finresult)
}


SIRS <- function(X,Y){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  IY  <- matrix(as.numeric(outer(Y, Y, "<")), nrow = n)

  SIRS_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    
    ### 计算统计量
    omega_1 <- mean((t(IY)%*%x/n)^2)
    SIRS_finresult[idx] <- omega_1*n^3/((n-1)*(n-2)*(n-3))
    
  }
  return(SIRS_finresult)
}



DCSIS <- function(X,Y){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)

  DCSIS_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    ### 计算统计量
    DCSIS_finresult[idx] <- dcor(x, Y)^2
    
  }
  return(DCSIS_finresult)
}


RRCS <- function(X,Y){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  RRCS<- rep(0,p)
  
  for(idx in 1:p){
    x <- scale(X[,idx])
    IX  <- matrix(as.numeric(outer(x, x, "<")), nrow = n)
    IY  <- matrix(as.numeric(outer(Y, Y, "<")), nrow = n)
    ### 计算统计量
    RRCS[idx] <- abs(sum(IX*IY)/(n*(n-1))-1/4) 
    
  }
  return(RRCS)
}

RQCSIS <- function(X,Y,tau_H){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  H <- length(tau_H)
  
  
  ### 计算Y对应的quantile的估计值mu_Y,及矩阵W
  W <- matrix(0,n,H)
  mu_Y <- quantile(Y, probs = tau_H)
  for(idx in 1:H){
    W[,idx] <- ifelse(Y-mu_Y[idx] < 0,tau_H[idx]-1,tau_H[idx])
  }
  
  RQCSIS_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    
    ### 计算统计量
    omega_1 <- mean((t(W)%*%x)^2/(tau_H-tau_H^2))
    RQCSIS_finresult[idx] <- omega_1*n^3/((n-1)*(n-2)*(n-3))
    
  }
  return(RQCSIS_finresult)
}

DC_RoSIS <- function(X,Y){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  DC_RoSIS_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    # 计算经验分布函数
    ecdf_func <- ecdf(Y)
    # 获取在原始样本点处的取值
    FY <- ecdf_func(Y)
    ### 计算统计量
    DC_RoSIS_finresult[idx] <- dcor(x, FY)
    
  }
  return(DC_RoSIS_finresult)
}

CRQDCS <- function(X,Y,tau_H){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  H <- length(tau_H)
  
  
  ### 计算Y对应的quantile的估计值mu_Y,及矩阵W
  W <- matrix(0,n,H)
  mu_Y <- quantile(Y, probs = tau_H)
  for(idx in 1:H){
    W[,idx] <- ifelse(Y-mu_Y[idx] <= 0,tau_H[idx]-1,tau_H[idx])
  }
  
  CRQDCS_finresult<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    x <- scale(X[,idx])
    # 计算经验分布函数
    ecdf_func <- ecdf(x)
    # 获取在原始样本点处的取值
    Fx <- matrix(ecdf_func(x),n,1)
    
    ### 计算统计量
    CRQDCS_finresult[idx] <- dcor(Fx, W)^2
    
  }
  return(CRQDCS_finresult)
}



