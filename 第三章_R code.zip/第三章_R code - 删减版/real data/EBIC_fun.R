

EBIC_screening <- function(X_training,Y_training,X_testing,Y_testing,tau,X_order,d){
  n_training <- nrow(X_training)
  n_testing <- nrow(X_testing)
  EBIC_Method <- rep(0,d)
  for(k in 1:d){
    id_X <- X_order[1:k]
    X_training_k <- as.matrix(X_training[,id_X],n_training,k)
    f_beta <- function(beta){
      mean(ifelse(Y_training-X_training_k%*%beta<0,1-tau,tau)*(Y_training-X_training_k%*%beta)^2)
    }
    start_point <- c(1,rep(0,k-1))
    mu_beta <- nlm(f_beta, start_point)$estimate
    EBIC_Method[k] <- log(mean(ifelse(Y_training-X_training_k%*%mu_beta<0,1-tau,tau)*(Y_training-X_training_k%*%mu_beta)^2))+k*log(n_training)*log(d)/(2*n_training)
  }
  k_hat<- which.min(EBIC_Method)
  Method_size <- k_hat
  
  id_X_hat <- X_order[1:k_hat]
  X_testing_k <- as.matrix(X_testing[,id_X_hat],n_testing,k_hat)
  f_beta_testing <- function(beta){
    mean(ifelse(Y_testing-X_testing_k%*%beta<0,1-tau,tau)*(Y_testing-X_testing_k%*%beta)^2)
  }
  start_point <- c(1,rep(0,k_hat-1))
  mu_beta_testing <- nlm(f_beta_testing, start_point)$estimate
  #f_Y <- function(theta){
  #  mean(ifelse(Y_testing-theta<0,1-tau,tau)*(Y_testing-theta)^2)
  #} 
  #mu_Y <- optimize(f_Y, interval = c(-1000, 1000))$minimum
  rho_beta_x<- ifelse(Y_testing-X_testing_k%*%mu_beta_testing<0,1-tau,tau)*(Y_testing-X_testing_k%*%mu_beta_testing)^2
  #rho_y<- ifelse(Y_testing-mu_Y<0,1-tau,tau)*(Y_testing-mu_Y)^2
  Method_pe <- mean(rho_beta_x)
  #Method_pR2 <- 1-sum(rho_beta_x)/sum(rho_y)
  #return(c(Method_size,Method_pe,Method_pR2))
  return(c(Method_size,Method_pe))
}

EBIC_nonpar <- function(X_training,Y_training,X_testing,Y_testing,tau,X_order,d){
  n_training <- nrow(X_training)
  n_testing <- nrow(X_testing)
  EBIC_Method <- rep(0,d)
  for(k in 1:d){
    id_X <- X_order[1:k]
    X_df <- as.data.frame(X_training[,id_X])
    colnames(X_df) <- paste0("x", 1:k)
    data <- data.frame(y = Y_training, X_df)
    formula_parts <- paste0("bbs(", colnames(X_df), ")", collapse = " + ")
    model_formula <- as.formula(paste("y ~", formula_parts))
    model1<-mboost(
      formula =  model_formula, 
      data = data,
      family = ExpectReg(tau = tau),  
      control = boost_control(mstop = 500, nu = 0.1)
    )
    Y_predict <- predict.mboost(model1)
    EBIC_Method[k] <- log(mean(ifelse(Y_training-Y_predict<0,1-tau,tau)*(Y_training-Y_predict)^2))+k*log(n_training)*log(d)/(2*n_training)
  }
  k_hat<- which.min(EBIC_Method)
  Method_size <- k_hat
  id_X_hat <- X_order[1:k_hat]
  X_df_hat <- as.data.frame(X_testing[,id_X_hat])
  colnames(X_df_hat) <- paste0("x", 1:k_hat)
  data_hat <- data.frame(y = Y_testing, X_df_hat)
  formula_parts <- paste0("bbs(", colnames(X_df_hat), ")", collapse = " + ")
  model_formula <- as.formula(paste("y ~", formula_parts))
  model1_hat<-mboost(
    formula =  model_formula, 
    data = data_hat,
    family = ExpectReg(tau = tau),  
    control = boost_control(mstop = 500, nu = 0.1)
  )
  Y_predict_hat <- predict.mboost(model1_hat)
  #f_Y <- function(theta){
  #  mean(ifelse(Y_testing-theta<0,1-tau,tau)*(Y_testing-theta)^2)
  #} 
  #mu_Y <- optimize(f_Y, interval = c(-1000, 1000))$minimum
  rho_beta_x<- ifelse(Y_testing-Y_predict_hat<0,1-tau,tau)*(Y_testing-Y_predict_hat)^2
  #rho_y<- ifelse(Y_testing-mu_Y<0,1-tau,tau)*(Y_testing-mu_Y)^2
  Method_pe <- mean(rho_beta_x)
  #Method_pR2 <- 1-sum(rho_beta_x)/sum(rho_y)
  #return(c(Method_size,Method_pe,Method_pR2))
  return(c(Method_size,Method_pe))
}


EBIC_SRoWER <- function(X_training,Y_training,X_testing,Y_testing,tau,d,tol=0.001){
  n_training <- nrow(X_training)
  n_testing <- nrow(X_testing)
  EBIC_Method <- rep(0,d)
  for(k in 1:d){
    fit_ii <- SRoWER_fit(Y_training, X_training, k, keyset=NULL,
                         max_iter=500, tol=0.001, Pi=1,
                         U_rate=0.5,coef_initial= NULL, tau=tau)
    id_X <- fit_ii$ID_retained
    X_training_k <- as.matrix(X_training[,id_X],nrow = n_training, ncol = k)
    f_beta <- function(beta){
      mean(ifelse(Y_training-X_training_k%*%beta<0,1-tau,tau)*(Y_training-X_training_k%*%beta)^2)
    }
    start_point <- c(1,rep(0,k-1))
    mu_beta <- nlm(f_beta, start_point)$estimate
    EBIC_Method[k] <- log(mean(ifelse(Y_training-X_training_k%*%mu_beta<0,1-tau,tau)*(Y_training-X_training_k%*%mu_beta)^2))+k*log(n_training)*log(d)/(2*n_training)
  }
  k_hat<- which.min(EBIC_Method)
  Method_size <- k_hat
  
  fit_ii_hat <- SRoWER_fit(Y_training, X_training, k_hat, keyset=NULL,
                       max_iter=500, tol=0.001, Pi=1,
                       U_rate=0.5,coef_initial= NULL, tau=tau)
  id_X_hat <- fit_ii_hat$ID_retained
  X_testing_k <- as.matrix(X_testing[,id_X_hat],nrow = n_testing,ncol = k_hat)
  f_beta_testing <- function(beta){
    mean(ifelse(Y_testing-X_testing_k%*%beta<0,1-tau,tau)*(Y_testing-X_testing_k%*%beta)^2)
  }
  start_point <- c(1,rep(0,k_hat-1))
  mu_beta_testing <- nlm(f_beta_testing, start_point)$estimate
  #f_Y <- function(theta){
  #  mean(ifelse(Y_testing-theta<0,1-tau,tau)*(Y_testing-theta)^2)
  #} 
  #mu_Y <- optimize(f_Y, interval = c(-1000, 1000))$minimum
  rho_beta_x<- ifelse(Y_testing-X_testing_k%*%mu_beta_testing<0,1-tau,tau)*(Y_testing-X_testing_k%*%mu_beta_testing)^2
  #rho_y<- ifelse(Y_testing-mu_Y<0,1-tau,tau)*(Y_testing-mu_Y)^2
  Method_pe <- mean(rho_beta_x)
  #Method_pR2 <- 1-sum(rho_beta_x)/sum(rho_y)
  #return(c(Method_size,Method_pe,Method_pR2))
  return(c(Method_size,Method_pe))

}