rm(list = ls())

library(doParallel)
library(foreach)
library(energy)

X_expr <- as.matrix(read.csv("GSE5680_probes_18986.csv")[,-1])
expr_TRIM32 <- as.matrix(read.csv("GSE5680_probes_TRIM32.csv")[,-1])

############################
# screening and prediction #
############################

tau_0 <- c(0.05,0.25,0.5,0.75,0.95)
n <- ncol(X_expr)
p <- nrow(X_expr)
n_training <- 100
n_testing <- n-n_training
M <- 100

startTime<-Sys.time()

runfunc <- function(mm){
  
  seed_noNA <- setdiff(1:103,c(31,80,96))
  set.seed(seed_noNA[mm])
  
  library(expm)
  library(MASS)
  library(energy)
  library(gcdnet)
  
  source('KCED.R')
  source('prefunction.R')
  source('SWL2E.R')
  source('EPCS.R')
  source('REDC.R')
  source('EBIC_fun.R')
  
  X <- t(X_expr)
  Y <- expr_TRIM32
  
  id_training <- sample(1:n,size = n_training,replace = FALSE)
  id_testing <- setdiff(c(1:n),id_training)
  Y_training <- Y[id_training]
  X_training <- X[id_training,]
  Y_testing <- Y[id_testing]
  X_testing <- X[id_testing,]
  d <- round(n_training/log(n_training))
  
  KCED_pe <- REDC_pe <- DC_pe <- SRoWER_pe <- rep(0,5)
  KCED_size <- REDC_size <- DC_size <- SRoWER_size <- rep(0,5)
  
  for(idx_tau in 1:5){
    
    f_Y <- function(theta){
      mean(ifelse(Y_training-theta<0,1-tau_0[idx_tau],tau_0[idx_tau])*(Y_training-theta)^2)
    } 
    mu_Y <- optimize(f_Y, interval = c(-1000, 1000))$minimum
    
    ###################
    ### test for KCED #
    ###################
    KCED_re <- KCED(X_training,Y_training,tau_0[idx_tau],mu_Y)
    KCED_order = order(KCED_re, decreasing = TRUE)
    KCED_predict <- EBIC_screening(X_training,Y_training,X_testing,Y_testing,tau_0[idx_tau],KCED_order,d)
    KCED_size[idx_tau] <- KCED_predict[1]
    KCED_pe[idx_tau] <- KCED_predict[2]
    
    ###################
    ### test for REDC #
    ###################
    REDC_re <- REDC(X_training,Y_training,tau_0[idx_tau],mu_Y)
    REDC_order =order(REDC_re, decreasing = TRUE)
    REDC_predict <- EBIC_screening(X_training,Y_training,X_testing,Y_testing,tau_0[idx_tau],REDC_order,d)
    REDC_size[idx_tau] <- REDC_predict[1]
    REDC_pe[idx_tau] <- REDC_predict[2]
    
    ###################
    ### test for DC #
    ###################
    DC_re <- DC(X_training,Y_training,tau_0[idx_tau],mu_Y)
    DC_order =order(DC_re, decreasing = TRUE)
    DC_predict <- EBIC_screening(X_training,Y_training,X_testing,Y_testing,tau_0[idx_tau],DC_order,d)
    DC_size[idx_tau] <- DC_predict[1]
    DC_pe[idx_tau] <- DC_predict[2]
    
    #####################
    ### test for SRoWER #
    #####################
    SRoWER_predict <- EBIC_SRoWER(X_training,Y_training,X_testing,Y_testing,tau_0[idx_tau],d)
    SRoWER_size[idx_tau] <- SRoWER_predict[1]
    SRoWER_pe[idx_tau] <- SRoWER_predict[2]
    
  }
  
  fin_result <- c(KCED_size,REDC_size,DC_size,SRoWER_size,KCED_pe,REDC_pe,DC_pe,SRoWER_pe)
  
  return(fin_result)
}

cl<-makeCluster(15)
registerDoParallel(cl)
kdcovresult <- foreach(m=1:M,.combine='rbind') %dopar% {
  runfunc(m)
}
stopCluster(cl)

endTime<-Sys.time()
print(difftime(endTime,startTime, units ="mins"))

write.csv(kdcovresult,file = "GSE5680_screening_result.csv")
#Time difference of 188.4873 mins(M=100,fix lambda)
#kdcovresult <- as.matrix(read.csv("GSE5680_full_4methodM100.csv")[,-1])

KCED_size <- REDC_size <- DC_size <- SRoWER_size <- matrix(0,M,5)
KCED_pe <- REDC_pe <- DC_pe <- SRoWER_pe <- matrix(0,M,5)

for(i in 1:5){
  KCED_size[,1:5]=kdcovresult[,1:5]
  REDC_size[,1:5]=kdcovresult[,6:10]
  DC_size[,1:5]=kdcovresult[,11:15]
  SRoWER_size[,1:5]=kdcovresult[,16:20]
  KCED_pe[,1:5]=kdcovresult[,21:25]
  REDC_pe[,1:5]=kdcovresult[,26:30]
  DC_pe[,1:5]=kdcovresult[,31:35]
  SRoWER_pe[,1:5]=kdcovresult[,36:40]
}

fin_result<- matrix(0,4,10)
for(i in 1:5){
  fin_result[,2*i-1]=c(mean(KCED_size[,i]),mean(REDC_size[,i]),mean(DC_size[,i]),mean(SRoWER_size[,i]))
  fin_result[,2*i]=c(mean(KCED_pe[,i]*n_testing),mean(REDC_pe[,i]*n_testing),mean(DC_pe[,i]*n_testing),mean(SRoWER_pe[,i]*n_testing))
}
print(fin_result)

#write.csv(fin_result,file="result_0105.csv")

