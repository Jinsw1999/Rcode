# KCED 估计
# X: 协变量矩阵（n×p）
# Y: 响应变量（n×1）
# tau: tau-th expectile 
# tau_H: composite tau-ths （H×1）
# 输出：作用于X的各个分量所得到的统计量KCED值（p×1）


KCED <- function(X,Y,tau,mu_Y= NULL){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  
  
  ### 计算Y对应的tau-expectile的估计值: mu_Y
  if( is.null( mu_Y ) ){           
    f <- function(theta){
      mean(ifelse(Y-theta<0,1-tau,tau)*(Y-theta)^2)
    } 
    mu_Y <- optimize(f, interval = c(-1000, 1000))$minimum
    
  }else mu_Y <- mu_Y
  
  
  ### 计算Y对应的 D_Y=(D_ij)
  W <- ifelse(Y-mu_Y<0,1-tau,tau)*(Y-mu_Y)
  dY <- W%*%t(W)
  diag(dY) <- 0
  RowMeandY <- matrix(apply(dY, 1, mean),nrow = n)*n/(n-2)
  ColMeandY <- matrix(apply(dY, 2, mean),nrow = n)*n/(n-2)
  RowMeanMat2 <- RowMeandY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat2 <- t(ColMeandY%*%matrix(rep(1,n),nrow = 1))
  D_Y <- dY-RowMeanMat2-ColMeanMat2+mean(dY)*n^2/((n-1)*(n-2))
  diag(D_Y) <- 0
  
  ### 对协变量 X 的每个分量计算对应的KCED统计量
  KCED<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    X[,idx] <- scale(X[,idx])
    
    ### 计算X的第idx个分量对应的带宽h_X 和 K_X=(K_ij) 
    distX <- as.matrix(dist(X[,idx],diag = TRUE,upper = TRUE))
    h_X <- median(distX[upper.tri(distX)]^2)
    kX <- dnorm(distX,sd = sqrt(h_X/2))
    diag(kX) <- 0
    RowMeanKX <- matrix(apply(kX, 1, mean),nrow = n)*n/(n-2)
    ColMeanKX <- matrix(apply(kX, 2, mean),nrow = n)*n/(n-2)
    RowMeanMat1 <- RowMeanKX%*%matrix(rep(1,n),nrow = 1)
    ColMeanMat1 <- t(ColMeanKX%*%matrix(rep(1,n),nrow = 1))
    K_X <- kX-RowMeanMat1-ColMeanMat1+mean(kX)*n^2/((n-1)*(n-2))
    diag(K_X) <- 0
    
    ### 计算统计量KCED
    KCED[idx] <- sum(K_X*D_Y)/(n*(n-3)) ##KCED is the statistic
    
  }
  return(KCED)
}

CKCED <- function(X,Y,tau_H){
  
  ### 样本量n,协变量X的维数p
  X <- as.matrix(X)
  n <- nrow(X)
  p <- ncol(X)
  Y <- as.vector(Y)
  H <- length(tau_H)
  
  
  ### 计算Y对应的expectile的估计值mu_Y,及矩阵W
  mu_Y <- rep(0,H)
  W <- matrix(0,n,H)
  for(idx in 1:H){
    f <- function(theta){
      mean(ifelse(Y-theta < 0,1-tau_H[idx],tau_H[idx])*(Y-theta)^2)
    } 
    mu_Y[idx] <- optimize(f, interval = c(-1000, 1000))$minimum
    W[,idx] <- ifelse(Y-mu_Y[idx] < 0,1-tau_H[idx],tau_H[idx])*(Y-mu_Y[idx])
  }
  
  ### 计算Y对应的 D_Y=(D_ij)
  dY <- W%*%t(W)
  diag(dY) <- 0
  RowMeandY <- matrix(apply(dY, 1, mean),nrow = n)*n/(n-2)
  ColMeandY <- matrix(apply(dY, 2, mean),nrow = n)*n/(n-2)
  RowMeanMat2 <- RowMeandY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat2 <- t(ColMeandY%*%matrix(rep(1,n),nrow = 1))
  D_Y <- dY-RowMeanMat2-ColMeanMat2+mean(dY)*n^2/((n-1)*(n-2))
  diag(D_Y) <- 0
  
  ### 对协变量 X 的每个分量计算对应的KCED统计量
  CKCED<- rep(0,p)
  
  for(idx in 1:p){
    
    ### 标准化协变量
    X[,idx] <- scale(X[,idx])
    
    ### 计算X的第idx个分量对应的带宽h_X 和 K_X=(K_ij) 
    distX <- as.matrix(dist(X[,idx],diag = TRUE,upper = TRUE))
    h_X <- median(distX[upper.tri(distX)]^2)
    kX <- dnorm(distX,sd = sqrt(h_X/2))
    diag(kX) <- 0
    RowMeanKX <- matrix(apply(kX, 1, mean),nrow = n)*n/(n-2)
    ColMeanKX <- matrix(apply(kX, 2, mean),nrow = n)*n/(n-2)
    RowMeanMat1 <- RowMeanKX%*%matrix(rep(1,n),nrow = 1)
    ColMeanMat1 <- t(ColMeanKX%*%matrix(rep(1,n),nrow = 1))
    K_X <- kX-RowMeanMat1-ColMeanMat1+mean(kX)*n^2/((n-1)*(n-2))
    diag(K_X) <- 0
    
    ### 计算统计量KCED
    CKCED[idx] <- sum(K_X*D_Y)/(n*(n-3)) ##KCED is the statistic
    
  }
  return(CKCED)
}



KCED_fun <- function(data_X,Y,tau,mu_Y= NULL){
  
  ### 样本量n,协变量X的维数p
  n <- dim(data_X)[1]
  p <- dim(data_X)[2]
  ntime <- dim(data_X)[3]
  Y <- as.vector(Y)
  
  ### 计算Y对应的tau-expectile的估计值: mu_Y
  if( is.null( mu_Y ) ){           
    f <- function(theta){
      mean(ifelse(Y-theta<0,1-tau,tau)*(Y-theta)^2)
    } 
    mu_Y <- optimize(f, interval = c(-1000, 1000))$minimum
    
  }else mu_Y <- mu_Y
  
  
  ### 计算Y对应的 D_Y=(D_ij)
  W <- ifelse(Y-mu_Y<0,1-tau,tau)*(Y-mu_Y)
  dY <- W%*%t(W)
  diag(dY) <- 0
  RowMeandY <- matrix(apply(dY, 1, mean),nrow = n)*n/(n-2)
  ColMeandY <- matrix(apply(dY, 2, mean),nrow = n)*n/(n-2)
  RowMeanMat2 <- RowMeandY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat2 <- t(ColMeandY%*%matrix(rep(1,n),nrow = 1))
  D_Y <- dY-RowMeanMat2-ColMeanMat2+mean(dY)*n^2/((n-1)*(n-2))
  diag(D_Y) <- 0
  
  ### 对协变量 X 的每个分量计算对应的KCED统计量
  KCED<- rep(0,p)
  
  for(idx in 1:p){
    
    X_k <- matrix(data_X[,idx,],nrow=n,ncol=ntime)
    
    #标准化协变量
    mean_function <- colMeans(X_k, na.rm = TRUE)
    X_k <- sweep(X_k, 2, mean_function, "-")
    sd_function <- apply(X_k, 2, sd, na.rm = TRUE)
    sd_function[sd_function == 0] <- 1
    X_k <- sweep(X_k, 2, sd_function, "/")
    
    ### 计算X的第idx个分量对应的带宽h_X 和 K_X=(K_ij) 
    dt <- 1/(ntime-1)
    distX <- as.matrix(dist(X_k[,2:ntime],diag = TRUE,upper = TRUE)^2*dt)
    h_X <- median(distX[upper.tri(distX)])
    kX <- dnorm(sqrt(distX),sd = sqrt(h_X/2))
    diag(kX) <- 0
    RowMeanKX <- matrix(apply(kX, 1, mean),nrow = n)*n/(n-2)
    ColMeanKX <- matrix(apply(kX, 2, mean),nrow = n)*n/(n-2)
    RowMeanMat1 <- RowMeanKX%*%matrix(rep(1,n),nrow = 1)
    ColMeanMat1 <- t(ColMeanKX%*%matrix(rep(1,n),nrow = 1))
    K_X <- kX-RowMeanMat1-ColMeanMat1+mean(kX)*n^2/((n-1)*(n-2))
    diag(K_X) <- 0
    
    ### 计算统计量KCED
    KCED[idx] <- sum(K_X*D_Y)/(n*(n-3)) ##KCED is the statistic
    
  }
  return(KCED)
}

CKCED_fun <- function(X,Y,tau_H){
  
  ### 样本量n,协变量X的维数p
  n <- dim(data_X)[1]
  p <- dim(data_X)[2]
  ntime <- dim(data_X)[3]
  Y <- as.vector(Y)
  H <- length(tau_H)
  
  ### 计算Y对应的expectile的估计值mu_Y,及矩阵W
  mu_Y <- rep(0,H)
  W <- matrix(0,n,H)
  for(idx in 1:H){
    f <- function(theta){
      mean(ifelse(Y-theta < 0,1-tau_H[idx],tau_H[idx])*(Y-theta)^2)
    } 
    mu_Y[idx] <- optimize(f, interval = c(-1000, 1000))$minimum
    W[,idx] <- ifelse(Y-mu_Y[idx] < 0,1-tau_H[idx],tau_H[idx])*(Y-mu_Y[idx])
  }
  
  ### 计算Y对应的 D_Y=(D_ij)
  dY <- W%*%t(W)
  diag(dY) <- 0
  RowMeandY <- matrix(apply(dY, 1, mean),nrow = n)*n/(n-2)
  ColMeandY <- matrix(apply(dY, 2, mean),nrow = n)*n/(n-2)
  RowMeanMat2 <- RowMeandY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat2 <- t(ColMeandY%*%matrix(rep(1,n),nrow = 1))
  D_Y <- dY-RowMeanMat2-ColMeanMat2+mean(dY)*n^2/((n-1)*(n-2))
  diag(D_Y) <- 0
  
  ### 对协变量 X 的每个分量计算对应的KCED统计量
  CKCED<- rep(0,p)
  
  for(idx in 1:p){
    
    X_k <- matrix(data_X[,idx,],nrow=n,ncol=ntime)
    
    #标准化协变量
    mean_function <- colMeans(X_k, na.rm = TRUE)
    X_k <- sweep(X_k, 2, mean_function, "-")
    sd_function <- apply(X_k, 2, sd, na.rm = TRUE)
    sd_function[sd_function == 0] <- 1
    X_k <- sweep(X_k, 2, sd_function, "/")
    
    ### 计算X的第idx个分量对应的带宽h_X 和 K_X=(K_ij) 
    dt <- 1/(ntime-1)
    distX <- as.matrix(dist(X_k[,2:ntime],diag = TRUE,upper = TRUE)^2*dt)
    h_X <- median(distX[upper.tri(distX)])
    kX <- dnorm(sqrt(distX),sd = sqrt(h_X/2))
    diag(kX) <- 0
    RowMeanKX <- matrix(apply(kX, 1, mean),nrow = n)*n/(n-2)
    ColMeanKX <- matrix(apply(kX, 2, mean),nrow = n)*n/(n-2)
    RowMeanMat1 <- RowMeanKX%*%matrix(rep(1,n),nrow = 1)
    ColMeanMat1 <- t(ColMeanKX%*%matrix(rep(1,n),nrow = 1))
    K_X <- kX-RowMeanMat1-ColMeanMat1+mean(kX)*n^2/((n-1)*(n-2))
    diag(K_X) <- 0
    
    ### 计算统计量KCED
    CKCED[idx] <- sum(K_X*D_Y)/(n*(n-3)) ##KCED is the statistic
    
  }
  return(CKCED)
}





