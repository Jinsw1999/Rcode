rm(list = ls())
startTime<-Sys.time()
library(foreach)
library(doParallel)
library(expm)

p_range <- c(2:5)
n <- 50
M <- 1000
alpha <- c(0.05,0.01)

for(idx_example in c(1,2,3,4)){
  example_2 <- idx_example 
  omega_vec <- c(0,0.2,0.4,0.6,0.8,1)
  power_mat_final <- matrix(0,6*length(p_range),2*length(omega_vec)) 
  
  for(i in 1:length(p_range)){
    p = q = p_range[i]
    DW_ECCFIC_power = HSIC_LY_power = DC_power = HSIC_power = HHG_power = IPC_power  = rep(0,length(omega_vec))
    DW_ECCFIC_power1 = HSIC_LY_power1 = DC_power1 = HSIC_power1 = HHG_power1 = IPC_power1  = rep(0,length(omega_vec))
    
    for (j in c(1:length(omega_vec))) {
      omega <- omega_vec[j]
      runfunc <- function(k){
        set.seed((k))
        library(energy)
        library(dHSIC)
        library(HHG)
        library(IndepTest)
        source('IPC.R')
        source('DW-ECCFIC and LY test.R')
        
        if(example_2 == 1){#### square-unif-case
          Z1 <- matrix(runif(n*(p+q),-1,1),nrow = n)
          Z2_1 <- matrix(runif(n*p,-1,1),nrow = n)
          Z2_2 <- Z2_1^2+0.5*matrix(rnorm(n*p),nrow = n)
          Z2 <- cbind(Z2_1,Z2_2)
        }else if(example_2 == 2){#### square-norm-case
          Z1 <- matrix(rnorm(n*(p+q)),nrow = n)
          Z2_1 <- matrix(rnorm(n*p,0,1),nrow = n)
          Z2_2 <- Z2_1^2+0.5*matrix(rnorm(n*p),nrow = n)
          Z2 <- cbind(Z2_1,Z2_2)
        }else if(example_2 == 3){#### square-t-case
          Z1 <- matrix(rt(n*(p+q),3),nrow = n)
          Z2_1 <- matrix(rt(n*p,3),nrow = n)
          Z2_2 <- Z2_1^2+0.5*matrix(rnorm(n*p),nrow = n)
          Z2 <- cbind(Z2_1,Z2_2)
        }else if(example_2 == 4){#### square-beta-case
          Z1 <- 2*matrix(rbeta(n*(p+q),1.5,1),nrow = n)-1
          Z2_1 <- 2*matrix(rbeta(n*p,1.5,1),nrow = n)-1
          Z2_2 <- Z2_1^2+0.5*matrix(rnorm(n*p),nrow = n)
          Z2 <- cbind(Z2_1,Z2_2)
        }
        
        B <- rbinom(1,1,prob = omega)
        Z <- (1-B)*Z1+(B)*Z2
        Y <- as.matrix(Z[,c(1:p)])
        X <- as.matrix(Z[,c((p+1):(p+q))])
        
        ##----------------------------------
        ## DW-ECCFIC test
        result_1 <- DW_ECCFIC(X,Y,kernel_family = 'gaussian',bw_Y_method = 'b_opt')
        DW_ECCFIC1 <- result_1$pval
        ##-----------------------------------
        ## HSIC_LY test
        v_n <- 1*(4/n/(q+2))^(1/(q+4))*mean(apply(Y,2,sd))
        h_n <- 1*(4/n/(p+2))^(1/(p+4))*mean(apply(X,2,sd)) 
        result2 <- HSIC_LY(X,Y,h_n,v_n)
        HSIC_LY1 <- result2$pval.b
        ##-----------------------------------
        ## DC test
        DC <- dcov.test(X,Y,R=199) 
        ##-----------------------------------
        ## HSIC test
        HSIC <- dhsic.test(X,Y,method="bootstrap",B=199) 
        #--------------------------------------
        # HHG test
        distX <- as.matrix(dist(X,diag = TRUE,upper = TRUE))
        distY <- as.matrix(dist(Y,diag = TRUE,upper = TRUE))
        hhg <- HHG::hhg.test(distX,distY,nr.perm = 199)
        #---------------------------------------
        ## IPC test
        IPC <- IPC.test(X,Y,B=199) 
        
        return(c(DC$p.value,HSIC$p.value,hhg$perm.pval.hhg.sc,IPC,DW_ECCFIC1,HSIC_LY1))
      }
      
      cl<-makeCluster(16)
      registerDoParallel(cl)
      kdcovresult <- foreach(k=1:M,.combine='rbind') %dopar% {
        runfunc(k)
      }
      stopCluster(cl)
      
      DC_p <- kdcovresult[,1]
      HSIC_p <- kdcovresult[,2]
      HHG_p <- kdcovresult[,3]
      IPC_p <- kdcovresult[,4]
      DW_ECCFIC_p <- kdcovresult[,5] 
      HSIC_LY_p <- kdcovresult[,6] 
      
      DC_power[j] <- length(which(DC_p<alpha[1]))/M 
      HSIC_power[j] <- length(which(HSIC_p<alpha[1]))/M 
      HHG_power[j] <- length(which(HHG_p<alpha[1]))/M 
      IPC_power[j] <- length(which(IPC_p<alpha[1]))/M 
      DW_ECCFIC_power[j] <- length(which(DW_ECCFIC_p<alpha[1]))/M 
      HSIC_LY_power[j] <- length(which(HSIC_LY_p<alpha[1]))/M 
      
      DC_power1[j] <- length(which(DC_p<alpha[2]))/M 
      HSIC_power1[j] <- length(which(HSIC_p<alpha[2]))/M 
      HHG_power1[j] <- length(which(HHG_p<alpha[2]))/M 
      IPC_power1[j] <- length(which(IPC_p<alpha[2]))/M 
      DW_ECCFIC_power1[j] <- length(which(DW_ECCFIC_p<alpha[2]))/M 
      HSIC_LY_power1[j] <- length(which(HSIC_LY_p<alpha[2]))/M 
      
    }
    
    power_mat <- rbind(DW_ECCFIC_power,HSIC_LY_power,HSIC_power,DC_power,HHG_power,IPC_power)
    power_mat1 <- rbind(DW_ECCFIC_power1,HSIC_LY_power1,HSIC_power1,DC_power1,HHG_power1,IPC_power1)
    
    power_mat <- cbind(power_mat1,power_mat)
    power_mat_final[(6*(i-1)+1):(6*i),] = power_mat
  }
  
  endTime<-Sys.time()
  print(power_mat_final)
  print(difftime(endTime,startTime, units ="mins"))

  if(idx_example==1){
    write.csv(power_mat_final,'ExampleS1(unif).csv')    
  }else if(idx_example==2){
    write.csv(power_mat_final,'ExampleS1(norm).csv')    
  }else if(idx_example==3){
    write.csv(power_mat_final,'ExampleS1(t).csv')    
  }else if(idx_example==4){
    write.csv(power_mat_final,'ExampleS1(beta).csv')    
  }
  
}




