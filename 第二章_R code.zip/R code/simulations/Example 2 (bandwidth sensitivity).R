

##---------------------------------------
## lambda change 

rm(list = ls())
startTime<-Sys.time()

library(energy)
library(doParallel)
library(foreach)
library(IndepTest)
p <- 6 ## dimension of X
q <- 2 ## dimension of Y
n <- 50
v <- 2

M <- 1000 ## consider M repetition
alpha <- c(0.05,0.01)

data_type=c(1:8)  ##refer to (a)-(f)

for(idx_type in data_type){
  
  DW_ECCFIC_power = DW_ECCFIC_power2 = DW_ECCFIC_power3  = rep(0,11)
  
  for (l in 1:11) {
    runfunc <- function(k){
      set.seed(k)
      library(energy)
      library(dHSIC)
      library(HHG)
      library(IndepTest)
      source('IPC.R')
      source('DW-ECCFIC and LY test.R')
      
      Y <- matrix(runif(q*n,-1,1),nrow = n) 
      X <- matrix(0,nrow = n, ncol = p)
      lambda <- (l-1)*0.1
      
      if(idx_type==1){  #(a)
        a=0.15
        b=1
        for(j in 1:3){
          X[,j] <- a*Y[,1]+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- a*Y[,2]+b*lambda*rnorm(n) 
        }
      }else if(idx_type==2){  #(b)
        a=0.1
        b=0.5
        for(j in 1:3){
          X[,j] <- a*log(abs(Y[,1])+0.01)+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- a*log(abs(Y[,2])+0.01)+b*lambda*rnorm(n) 
        }
      }else if(idx_type==3){  #(c)
        b=8 
        Z1 <- Y[,1]
        Z2 <- Y[,2]
        Z1[which(Y[,1] < -0.5)] <- (-3)
        Z1[which(Y[,1] >= -0.5 & Y[,1] < 0)] <- 2
        Z1[which(Y[,1] >= 0 & Y[,1] < 0.5)] <- (-4)
        Z1[which(Y[,1] >= 0.5)] <- (-3)
        Z2[which(Y[,2] < -0.5)] <- (-3)
        Z2[which(Y[,2] >= -0.5 & Y[,2] < 0)] <- 2
        Z2[which(Y[,2] >= 0 & Y[,2] < 0.5)] <- (-4)
        Z2[which(Y[,2] >= 0.5)] <- (-3)
        for(j in 1:3){
          X[,j] <- Z1 + b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- Z2 + b*lambda*rnorm(n) 
        }
      }else if(idx_type==4){  #(d)
        a=2
        b=0.75
        for(j in 1:3){
          X[,j] <- a*(Y[,1]^2-0.5^2)^2 + b*lambda*rnorm(n)
        }
        for(j in 4:6){
          X[,j] <- a*(Y[,2]^2-0.5^2)^2 + b*lambda*rnorm(n)
        }
      }else if(idx_type==5){  #(e)
        #a=1
        #b=3
        a=1
        b=3
        for(j in 1:3){
          X[,j] <- a*sin(2*pi*Y[,1])+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- a*sin(2*pi*Y[,2])+b*lambda*rnorm(n) 
        }
      }else if(idx_type==6){  #(f)
        b=0.5
        Z1 <- rep(0,n)
        Z2 <- rep(0,n)
        Z1[which(abs(Y[,1]) <= 0.5)] <- 1
        Z2[which(abs(Y[,2]) <= 0.5)] <- 1
        for(j in 1:3){
          X[,j] <- b*(Z1*(1-lambda)+lambda)*rnorm(n)
        }
        for(j in 4:6){
          X[,j] <- b*(Z2*(1-lambda)+lambda)*rnorm(n) 
        }
      }else if(idx_type==7){  #(g)
        a=0.2
        b=1
        for(j in 1:3){
          X[,j] <- sqrt(Y[,1]^2*(1-Y[,1]^2))*sin((1+a)*pi/(Y[,1]^2+a))+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- sqrt(Y[,2]^2*(1-Y[,2]^2))*sin((1+a)*pi/(Y[,2]^2+a))+b*lambda*rnorm(n) 
        }
      }else if(idx_type==8){  #(h)
        b=25
        for(j in 1:3){
          X[,j] <- 4*sin(4*pi*Y[,1]^2)-sign(Y[,1]^2-0.3)-sign(0.72-Y[,1]^2)+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- 4*sin(4*pi*Y[,2]^2)-sign(Y[,2]^2-0.3)-sign(0.72-Y[,2]^2)+b*lambda*rnorm(n) 
        }
      }
      
      ##----------------------------------
      ## DW-ECCFIC test with guassian kernal
      result_1 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "b_opt", bw_scale = TRUE,
                          bw_coe = 0.5)
      DW_ECCFIC1 <- result_1$pval
      
      result_2 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "b_opt", bw_scale = TRUE,
                          bw_coe = 1)
      DW_ECCFIC2 <- result_2$pval
      
      result_3 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "b_opt", bw_scale = TRUE,
                          bw_coe = 1.5)
      DW_ECCFIC3 <- result_3$pval
      
  
      
      return(c(DW_ECCFIC1,DW_ECCFIC2,DW_ECCFIC3))
    }
    
    cl<-makeCluster(16)
    registerDoParallel(cl)
    kdcovresult <- foreach(k=1:M,.combine='rbind') %dopar% {
      runfunc(k)
    }
    stopCluster(cl)
    
    DW_ECCFIC_p <- kdcovresult[,1] 
    DW_ECCFIC_p2 <- kdcovresult[,2]
    DW_ECCFIC_p3 <- kdcovresult[,3]
    
    DW_ECCFIC_power[l] <- length(which(DW_ECCFIC_p<alpha[1]))/M 
    DW_ECCFIC_power2[l] <- length(which(DW_ECCFIC_p2<alpha[1]))/M 
    DW_ECCFIC_power3[l] <- length(which(DW_ECCFIC_p3<alpha[1]))/M 
  }
  
  power_mat <- rbind(DW_ECCFIC_power,DW_ECCFIC_power2,DW_ECCFIC_power3)
  colnames(power_mat) <- c("lamdba = 0","0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1")
  
  endTime<-Sys.time()
  print(power_mat)
  print(difftime(endTime,startTime, units ="mins"))
  
  ###### Save the data
  if(idx_type==1){
    write.csv(power_mat, "(a)linear_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==2){
    write.csv(power_mat, "(b)log_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==3){
    write.csv(power_mat, "(c)step_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==4){
    write.csv(power_mat, "(d)W-shape_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==5){
    write.csv(power_mat, "(e)Sinusoid_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==6){
    write.csv(power_mat, "(f)Heteroscedastic_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==7){
    write.csv(power_mat, "(g)Doppler_h_0.1_cchange.csv", row.names=TRUE)
  }else if(idx_type==8){
    write.csv(power_mat, "(h)Heaviside_h_0.1_cchange.csv", row.names=TRUE)
  }
  
}

##---------------------------------------
## n change 

rm(list = ls())
startTime<-Sys.time()

library(energy)
library(doParallel)
library(foreach)
library(IndepTest)
p <- 6 ## dimension of X
q <- 2 ## dimension of Y
#n <- 50
v <- 2

M <- 1000 ## consider M repetition
alpha <- c(0.05,0.01)

data_type=c(1:8)  ##refer to (a)-(f)

for(idx_type in data_type){
  
  DW_ECCFIC_power = DW_ECCFIC_power2 = DW_ECCFIC_power3 = rep(0,8)
  
  for (l in 1:8) {
    runfunc <- function(k){
      set.seed(k)
      library(energy)
      library(dHSIC)
      library(HHG)
      library(IndepTest)
      source('IPC.R')
      source('DW-ECCFIC and LY test.R')
      
      n <- (l+2)*10
      Y <- matrix(runif(q*n,-1,1),nrow = n) 
      X <- matrix(0,nrow = n, ncol = p)
      lambda <- 0.3
      
      if(idx_type==1){  #(a)
        a=0.15
        b=1
        for(j in 1:3){
          X[,j] <- a*Y[,1]+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- a*Y[,2]+b*lambda*rnorm(n) 
        }
      }else if(idx_type==2){  #(b)
        a=0.1
        b=0.5
        for(j in 1:3){
          X[,j] <- a*log(abs(Y[,1])+0.01)+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- a*log(abs(Y[,2])+0.01)+b*lambda*rnorm(n) 
        }
      }else if(idx_type==3){  #(c)
        b=8 
        Z1 <- Y[,1]
        Z2 <- Y[,2]
        Z1[which(Y[,1] < -0.5)] <- (-3)
        Z1[which(Y[,1] >= -0.5 & Y[,1] < 0)] <- 2
        Z1[which(Y[,1] >= 0 & Y[,1] < 0.5)] <- (-4)
        Z1[which(Y[,1] >= 0.5)] <- (-3)
        Z2[which(Y[,2] < -0.5)] <- (-3)
        Z2[which(Y[,2] >= -0.5 & Y[,2] < 0)] <- 2
        Z2[which(Y[,2] >= 0 & Y[,2] < 0.5)] <- (-4)
        Z2[which(Y[,2] >= 0.5)] <- (-3)
        for(j in 1:3){
          X[,j] <- Z1 + b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- Z2 + b*lambda*rnorm(n) 
        }
      }else if(idx_type==4){  #(d)
        a=2
        b=0.75
        for(j in 1:3){
          X[,j] <- a*(Y[,1]^2-0.5^2)^2 + b*lambda*rnorm(n)
        }
        for(j in 4:6){
          X[,j] <- a*(Y[,2]^2-0.5^2)^2 + b*lambda*rnorm(n)
        }
      }else if(idx_type==5){  #(e)
        a=1
        b=3
        for(j in 1:3){
          X[,j] <- a*sin(2*pi*Y[,1])+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- a*sin(2*pi*Y[,2])+b*lambda*rnorm(n) 
        }
      }else if(idx_type==6){  #(f)
        b=0.5
        Z1 <- rep(0,n)
        Z2 <- rep(0,n)
        Z1[which(abs(Y[,1]) <= 0.5)] <- 1
        Z2[which(abs(Y[,2]) <= 0.5)] <- 1
        for(j in 1:3){
          X[,j] <- b*(Z1*(1-lambda)+lambda)*rnorm(n)
        }
        for(j in 4:6){
          X[,j] <- b*(Z2*(1-lambda)+lambda)*rnorm(n) 
        }
      }else if(idx_type==7){  #(g)
        a=0.2
        b=1
        for(j in 1:3){
          X[,j] <- sqrt(Y[,1]^2*(1-Y[,1]^2))*sin((1+a)*pi/(Y[,1]^2+a))+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- sqrt(Y[,2]^2*(1-Y[,2]^2))*sin((1+a)*pi/(Y[,2]^2+a))+b*lambda*rnorm(n) 
        }
      }else if(idx_type==8){  #(h)
        b=25
        for(j in 1:3){
          X[,j] <- 4*sin(4*pi*Y[,1]^2)-sign(Y[,1]^2-0.3)-sign(0.72-Y[,1]^2)+b*lambda*rnorm(n) 
        }
        for(j in 4:6){
          X[,j] <- 4*sin(4*pi*Y[,2]^2)-sign(Y[,2]^2-0.3)-sign(0.72-Y[,2]^2)+b*lambda*rnorm(n) 
        }
      }
      
      ##----------------------------------
      ## DW-ECCFIC test with guassian kernal
      result_1 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "b_opt", bw_scale = TRUE,
                          bw_coe = 0.5)
      DW_ECCFIC1 <- result_1$pval
      
      result_2 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "b_opt", bw_scale = TRUE,
                          bw_coe = 1)
      DW_ECCFIC2 <- result_2$pval
      
      result_3 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "b_opt", bw_scale = TRUE,
                          bw_coe = 1.5)
      DW_ECCFIC3 <- result_3$pval
      
      
      
      return(c(DW_ECCFIC1,DW_ECCFIC2,DW_ECCFIC3))
    }
    
    cl<-makeCluster(16)
    registerDoParallel(cl)
    kdcovresult <- foreach(k=1:M,.combine='rbind') %dopar% {
      runfunc(k)
    }
    stopCluster(cl)
    
    DW_ECCFIC_p <- kdcovresult[,1] 
    DW_ECCFIC_p2 <- kdcovresult[,2]
    DW_ECCFIC_p3 <- kdcovresult[,3]
    
    DW_ECCFIC_power[l] <- length(which(DW_ECCFIC_p<alpha[1]))/M 
    DW_ECCFIC_power2[l] <- length(which(DW_ECCFIC_p2<alpha[1]))/M 
    DW_ECCFIC_power3[l] <- length(which(DW_ECCFIC_p3<alpha[1]))/M 
  }
  
  power_mat <- rbind(DW_ECCFIC_power,DW_ECCFIC_power2,DW_ECCFIC_power3)
  colnames(power_mat) <- c("n = 30","40","50","60","70","80","90","100")
  
  endTime<-Sys.time()
  print(power_mat)
  print(difftime(endTime,startTime, units ="mins"))
  
  ###### Save the data
  if(idx_type==1){
    write.csv(power_mat, "(a)linear_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==2){
    write.csv(power_mat, "(b)log_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==3){
    write.csv(power_mat, "(c)step_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==4){
    write.csv(power_mat, "(d)W-shape_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==5){
    write.csv(power_mat, "(e)Sinusoid_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==6){
    write.csv(power_mat, "(f)Heteroscedastic_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==7){
    write.csv(power_mat, "(g)Doppler_n_0.3_cchange.csv", row.names=TRUE)
  }else if(idx_type==8){
    write.csv(power_mat, "(h)Heaviside_n_0.3_cchange.csv", row.names=TRUE)
  }
  
}

