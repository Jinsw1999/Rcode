rm(list = ls())
startTime<-Sys.time()

source('DW-ECCFIC and LY test.R')
library(doParallel)
library(foreach)
p <- 10
q <- 2
n_range <- seq(50,400,50)
XY_type <- c(1,2) ### XY_type=1: unif ; XY_type=2: norm
m <- 1000
alpha <- 0.05

for(idx_XY in XY_type){
  
  DW_ECCFIC_power = DW_ECCFIC_power2 = DW_ECCFIC_power3 = DW_ECCFIC_power4 = rep(0,length(n_range))
  
  for(idx_n in 1:length(n_range)){
    
    n<- n_range[idx_n]
    runfunc <- function(k){
      set.seed(k)
      if(idx_XY==1){
        X <- matrix(runif(n*p,-1,1),nrow = n)
        Y <- matrix(runif(n*q,-1,1),nrow = n)
      }else if(idx_XY==2){
        X <- matrix(rnorm(n*p),nrow = n)
        Y <- matrix(rnorm(n*q),nrow = n)
      }
      result_1 <- DW_ECCFIC(X,Y,kernel_family = 'gaussian',bw_Y_method = 'b_opt')
      DW_ECCFIC1 <- result_1$pval
      result_2 <- DW_ECCFIC(X,Y,kernel_family = 'gaussian',bw_Y_method = 'silverman')
      DW_ECCFIC2 <- result_2$pval
      result_3 <- DW_ECCFIC(X,Y,kernel_family = 'laplace',bw_Y_method = 'b_opt')
      DW_ECCFIC3 <- result_3$pval
      result_4 <- DW_ECCFIC(X,Y,kernel_family = 'laplace',bw_Y_method = 'silverman')
      DW_ECCFIC4 <- result_4$pval
      
      return(c(DW_ECCFIC1,DW_ECCFIC2,DW_ECCFIC3,DW_ECCFIC4))
    }
    
    cl<-makeCluster(16)
    registerDoParallel(cl)
    fin_result <- foreach(k=1:m,.combine='rbind') %dopar% {
      runfunc(k)
    }
    stopCluster(cl)
    
    DW_ECCFIC_p <- fin_result[,1] 
    DW_ECCFIC_p2 <- fin_result[,2]
    DW_ECCFIC_p3 <- fin_result[,3] 
    DW_ECCFIC_p4 <- fin_result[,4]
    
    DW_ECCFIC_power[idx_n] <- length(which(DW_ECCFIC_p<alpha))/m 
    DW_ECCFIC_power2[idx_n] <- length(which(DW_ECCFIC_p2<alpha))/m 
    DW_ECCFIC_power3[idx_n] <- length(which(DW_ECCFIC_p3<alpha))/m 
    DW_ECCFIC_power4[idx_n] <- length(which(DW_ECCFIC_p4<alpha))/m 
    
  }
  
  power_mat <- rbind(DW_ECCFIC_power,DW_ECCFIC_power2,DW_ECCFIC_power3,DW_ECCFIC_power4)
  colnames(power_mat) <- c("n = 50","100","150","200","250","300","350","400")
  
  
  endTime<-Sys.time()
  print(difftime(endTime,startTime, units ="mins"))
  print(power_mat)
  
  if(idx_XY==1){
    write.csv(power_mat, "H0_unif_Ierror.csv", row.names=TRUE)
  }else if(idx_XY==2){
    write.csv(power_mat, "H0_norm_Ierror.csv", row.names=TRUE)
  }
  
}





##---------------------------------------
## Plot the Figure

library(ggplot2)
library(tidyr)
library(dplyr)
library(purrr)
library(patchwork)

# -----------------------------
# 1) settings
# -----------------------------
notMINT <- c(1,2,3,4)
NL <- seq(50, 400, 50)

method_names <- c('DW-ECCFIC(G1)','DW-ECCFIC(G2)','DW-ECCFIC(L1)','DW-ECCFIC(L2)')

cols <- c("black","red","darkgreen","darkorange")

# 3 种不同点型（和 base R 的 1:3 类似）
shapes <- c(17, 
            16, 
            15,
            18
)

# -----------------------------
# 2) read & reshape helper
# -----------------------------
read_one <- function(file, panel_title){
  dat <- read.csv(file, header = TRUE)[notMINT, -1, drop = FALSE]  # 3 x 11
  colnames(dat) <- paste0("NL_", NL)
  dat$Method <- method_names
  
  dat %>%
    pivot_longer(starts_with("NL_"), names_to = "NL", values_to = "Power") %>%
    mutate(
      NoiseLevel = as.numeric(sub("^NL_", "", NL)),
      Panel = panel_title,
      Method = factor(Method, levels = method_names)
    ) %>%
    select(Panel, NoiseLevel, Power, Method)
}

# -----------------------------
# 3) files & panel titles
# -----------------------------
files <- c(
  "H0_unif_Ierror.csv",
  "H0_norm_Ierror.csv"
)

panels <- c(
  "(a) unif","(b) norm"
)

df <- map2_dfr(files, panels, read_one)

# -----------------------------
# 4) one-panel plot (so each has its own axis titles)
# -----------------------------
one_panel_plot <- function(dsub, title_text){
  ggplot(dsub, aes(x = NoiseLevel, y = Power,
                   color = Method, shape = Method, group = Method)) +
    geom_line(linewidth = 0.75, linetype = "dashed") +
    geom_point(size = 1.5, stroke = 0.7, fill = "white") +  # 点更小
    scale_color_manual(values = cols, breaks = method_names) +
    scale_shape_manual(values = shapes, breaks = method_names) +
    scale_x_continuous(
      breaks = seq(50, 400, 50),
      #labels = function(x) sprintf("%.2f", x),
      limits = c(50, 400)
    ) +
    scale_y_continuous(
      breaks = seq(0, 0.1, 0.025),
      #labels = function(y) sprintf("%.2f", y),
      limits = c(0, 0.1)
    ) +
    labs(x = "Sample size", y = "Type I error") +
    ggtitle(title_text) +
    theme_gray(base_size = 12) +
    theme(
      plot.title.position = "panel",
      plot.title = element_text(face = "bold", hjust = 0.5, size = 12,
                                margin = margin(t = 0, b = 6)),
      plot.background  = element_rect(fill = "white", color = NA),
      panel.background = element_rect(fill = "grey90", color = NA),
      legend.position = "none"
    )
}

# -----------------------------
# 5) build 8 plots and combine + legend outside right
# -----------------------------
plot_list <- map(panels, function(pn){
  dsub <- df %>% filter(Panel == pn)
  one_panel_plot(dsub, pn)
})

final_plot <-
  wrap_plots(plotlist = plot_list, ncol = 2) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    legend.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(6, 24, 6, 6)
  )

final_plot
