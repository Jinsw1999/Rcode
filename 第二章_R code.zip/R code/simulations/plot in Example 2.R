##################################
# Plot code of Example 2 (power) #
##################################
library(ggplot2)
library(tidyr)
library(dplyr)
library(purrr)
library(patchwork)

###-----------------------------
### lambda change

# =============================
# 8 panels (2x4) + 9 methods
# - Colors: match the example style for LY/HSIC/DC/HHG/IPC
#           and 4 HSICskb variants use 4 orange shades
# - 9 distinct colors + 9 distinct shapes
# - Each small plot has its own x/y axis titles (like the example)
# - Legend collected outside right
# - Smaller points
# =============================

# -----------------------------
# 1) Data settings
# -----------------------------
notMINT <- 1:9
NL <- seq(0, 1, 0.1)

method_names <- c(
  'HSICskb_g','HSICskb_g2','HSICskb_l','HSICskb_l2',
  'HSIC_LY','HSIC','DC','HHG','IPC'
)

# -----------------------------
# 2) Read & reshape helper
# -----------------------------
read_one <- function(file, panel_title){
  dat <- read.csv(file, header = TRUE)[notMINT, -1, drop = FALSE]
  colnames(dat) <- paste0("NL_", NL)
  dat$Method <- method_names
  
  dat %>%
    pivot_longer(starts_with("NL_"), names_to = "NL", values_to = "Power") %>%
    mutate(
      NoiseLevel = as.numeric(sub("^NL_", "", NL)),
      Panel = panel_title,
      Method = factor(Method, levels = method_names)
    ) %>%
    select(Panel, NoiseLevel, Power, Method)
}

# -----------------------------
# 3) Files & panel titles
# -----------------------------
files <- c(
  "(a)linear_h_0.1_kernal.csv",
  "(b)log_h_0.1_kernal.csv",
  "(c)step_h_0.1_kernal.csv",
  "(d)W-shape_h_0.1_kernal.csv",
  "(e)Sinusoid_h_0.1_kernal.csv",
  "(f)Heteroscedastic_h_0.1_kernal.csv",
  "(g)Doppler_h_0.1_kernal.csv",
  "(h)Heaviside_h_0.1_kernal.csv"
)

panels <- c(
  "(a) Linear","(b) Log","(c) Step","(d) W-Shape",
  "(e) Sinusoid","(f) Heteroscedastic","(g) Doppler","(h) Heavisine"
)

df <- map2_dfr(files, panels, read_one)

# -----------------------------
# 4) Colors: match the example figure style
#    Example-like palette:
#    HSICskb -> orange, LY -> purple, HSIC -> yellow, DC -> green, HHG -> magenta, IPC -> light blue
#    For 4 HSICskb variants: use 4 different orange shades (still "HSICskb orange-family")
# -----------------------------
cols <- c(
  HSICskb_g  = "#D55E00",  # orange (main HSICskb)
  HSICskb_g2 = "#E69F00",  # orange-yellow
  HSICskb_l  = "#F4A261",  # light orange
  HSICskb_l2 = "#B45309",  # deep orange/brownish
  
  HSIC_LY    = "#7570B3",  # purple (LY)
  HSIC       = "#0072B2",  # dark blue (HSIC)
  DC         = "#66A61E",  # green (DC)
  HHG        = "#E7298A",  # magenta (HHG)
  IPC        = "#56B4E9"   # light blue (IPC)
)

# 9 distinct shapes (clear separation)
shapes <- c(
  HSICskb_g  = 17,  # triangle
  HSICskb_g2 = 16,  # circle
  HSICskb_l  = 15,  # square
  HSICskb_l2 = 18,  # diamond
  HSIC_LY    = 1,   # hollow circle
  HSIC       = 2,   # hollow triangle
  DC         = 0,   # hollow square
  HHG        = 6,
  IPC        = 5    # hollow diamond
)

# -----------------------------
# 5) Plot function (ONE panel each -> each panel has x/y titles)
# -----------------------------
one_panel_plot <- function(dsub, title_text){
  ggplot(dsub, aes(x = NoiseLevel, y = Power,
                   color = Method, shape = Method, group = Method)) +
    geom_line(linewidth = 0.75, linetype = "dashed") +
    geom_point(size = 1.4, stroke = 0.6, fill = "white") +  # smaller points
    scale_color_manual(values = cols, breaks = method_names) +
    scale_shape_manual(values = shapes, breaks = method_names) +
    scale_x_continuous(
      breaks = seq(0, 1, 0.25),
      labels = function(x) sprintf("%.2f", x),
      limits = c(0, 1)
    ) +
    scale_y_continuous(
      breaks = seq(0, 1, 0.25),
      labels = function(y) sprintf("%.2f", y),
      limits = c(0, 1)
    ) +
    labs(x = expression(lambda), y = "Power") +
    ggtitle(title_text) +
    theme_gray(base_size = 12) +
    theme(
      # centered title at the top of each small plot
      plot.title.position = "panel",
      plot.title = element_text(face = "bold", hjust = 0.5, size = 12,
                                margin = margin(t = 0, b = 6)),
      
      # white outer + grey panel (like the example)
      plot.background  = element_rect(fill = "white", color = NA),
      panel.background = element_rect(fill = "grey90", color = NA),
      
      # legend collected later
      legend.position = "none"
    )
}

# -----------------------------
# 6) Build 8 plots and combine + legend outside right
# -----------------------------
plot_list <- map(panels, function(pn){
  dsub <- df %>% filter(Panel == pn)
  one_panel_plot(dsub, pn)
})

final_plot <-
  wrap_plots(plotlist = plot_list, nrow = 2) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    legend.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(6, 24, 6, 6)
  )

final_plot


###-----------------------------
### n change

# =============================
# 8 panels (2x4) + 9 methods
# - Colors: match the example style for LY/HSIC/DC/HHG/IPC
#           and 4 HSICskb variants use 4 orange shades
# - 9 distinct colors + 9 distinct shapes
# - Each small plot has its own x/y axis titles (like the example)
# - Legend collected outside right
# - Smaller points
# =============================

# -----------------------------
# 1) Data settings
# -----------------------------
notMINT <- 1:9
NL <- seq(30, 100, 10)

method_names <- c(
  'HSICskb_g','HSICskb_g2','HSICskb_l','HSICskb_l2',
  'HSIC_LY','HSIC','DC','HHG','IPC'
)

# -----------------------------
# 2) Read & reshape helper
# -----------------------------
read_one <- function(file, panel_title){
  dat <- read.csv(file, header = TRUE)[notMINT, -1, drop = FALSE]
  colnames(dat) <- paste0("NL_", NL)
  dat$Method <- method_names
  
  dat %>%
    pivot_longer(starts_with("NL_"), names_to = "NL", values_to = "Power") %>%
    mutate(
      NoiseLevel = as.numeric(sub("^NL_", "", NL)),
      Panel = panel_title,
      Method = factor(Method, levels = method_names)
    ) %>%
    select(Panel, NoiseLevel, Power, Method)
}

# -----------------------------
# 3) Files & panel titles
# -----------------------------
files <- c(
  "(a)linear_n_0.3_kernal.csv",
  "(b)log_n_0.3_kernal.csv",
  "(c)step_n_0.3_kernal.csv",
  "(d)W-shape_n_0.3_kernal.csv",
  "(e)Sinusoid_n_0.3_kernal.csv",
  "(f)Heteroscedastic_n_0.3_kernal.csv",
  "(g)Doppler_n_0.3_kernal.csv",
  "(h)Heaviside_n_0.3_kernal.csv"
)

panels <- c(
  "(a) Linear","(b) Log","(c) Step","(d) W-Shape",
  "(e) Sinusoid","(f) Heteroscedastic","(g) Doppler","(h) Heavisine"
)

df <- map2_dfr(files, panels, read_one)

# -----------------------------
# 4) Colors: match the example figure style
#    Example-like palette:
#    HSICskb -> orange, LY -> purple, HSIC -> yellow, DC -> green, HHG -> magenta, IPC -> light blue
#    For 4 HSICskb variants: use 4 different orange shades (still "HSICskb orange-family")
# -----------------------------
cols <- c(
  HSICskb_g  = "#D55E00",  # orange (main HSICskb)
  HSICskb_g2 = "#E69F00",  # orange-yellow
  HSICskb_l  = "#F4A261",  # light orange
  HSICskb_l2 = "#B45309",  # deep orange/brownish
  
  HSIC_LY    = "#7570B3",  # purple (LY)
  HSIC       = "#0072B2",  # dark blue (HSIC)
  DC         = "#66A61E",  # green (DC)
  HHG        = "#E7298A",  # magenta (HHG)
  IPC        = "#56B4E9"   # light blue (IPC)
)

# 9 distinct shapes (clear separation)
shapes <- c(
  HSICskb_g  = 17,  # triangle
  HSICskb_g2 = 16,  # circle
  HSICskb_l  = 15,  # square
  HSICskb_l2 = 18,  # diamond
  HSIC_LY    = 1,   # hollow circle
  HSIC       = 2,   # hollow triangle
  DC         = 0,   # hollow square
  HHG        = 6,   
  IPC        = 5    # hollow diamond
)

# -----------------------------
# 5) Plot function (ONE panel each -> each panel has x/y titles)
# -----------------------------
one_panel_plot <- function(dsub, title_text){
  ggplot(dsub, aes(x = NoiseLevel, y = Power,
                   color = Method, shape = Method, group = Method)) +
    geom_line(linewidth = 0.75, linetype = "dashed") +
    geom_point(size = 1.4, stroke = 0.6, fill = "white") +  # smaller points
    scale_color_manual(values = cols, breaks = method_names) +
    scale_shape_manual(values = shapes, breaks = method_names) +
    scale_x_continuous(
      breaks = seq(40, 100, 20),
      #labels = function(x) sprintf("%.2f", x),
      limits = c(30, 100)
    ) +
    scale_y_continuous(
      breaks = seq(0, 1, 0.25),
      labels = function(y) sprintf("%.2f", y),
      limits = c(0, 1)
    ) +
    labs(x = expression(n), y = "Power") +
    ggtitle(title_text) +
    theme_gray(base_size = 12) +
    theme(
      # centered title at the top of each small plot
      plot.title.position = "panel",
      plot.title = element_text(face = "bold", hjust = 0.5, size = 12,
                                margin = margin(t = 0, b = 6)),
      
      # white outer + grey panel (like the example)
      plot.background  = element_rect(fill = "white", color = NA),
      panel.background = element_rect(fill = "grey90", color = NA),
      
      # legend collected later
      legend.position = "none"
    )
}

# -----------------------------
# 6) Build 8 plots and combine + legend outside right
# -----------------------------
plot_list <- map(panels, function(pn){
  dsub <- df %>% filter(Panel == pn)
  one_panel_plot(dsub, pn)
})

final_plot <-
  wrap_plots(plotlist = plot_list, nrow = 2) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    legend.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(6, 24, 6, 6)
  )

final_plot



##################################################
# Plot code of Example 2 (constant in bandwidth) #
##################################################
library(ggplot2)
library(tidyr)
library(dplyr)
library(purrr)
library(patchwork)

###-----------------------------
### lambda change

# -----------------------------
# 1) settings
# -----------------------------
notMINT <- c(1,2,3)
NL <- seq(0, 1, 0.1)

method_names <- c('HSICskb_0.5','HSICskb_1','HSICskb_1.5')

# 颜色按你原来的：black / red / darkgreen
cols <- c(
  HSICskb_0.5 = "black",
  HSICskb_1   = "red",
  HSICskb_1.5 = "darkgreen"
)

# 3 种不同点型（和 base R 的 1:3 类似）
shapes <- c(
  HSICskb_0.5 = 1,  # hollow circle
  HSICskb_1   = 2,  # hollow triangle
  HSICskb_1.5 = 0   # hollow square
)

# -----------------------------
# 2) read & reshape helper
# -----------------------------
read_one <- function(file, panel_title){
  dat <- read.csv(file, header = TRUE)[notMINT, -1, drop = FALSE]  # 3 x 11
  colnames(dat) <- paste0("NL_", NL)
  dat$Method <- method_names
  
  dat %>%
    pivot_longer(starts_with("NL_"), names_to = "NL", values_to = "Power") %>%
    mutate(
      NoiseLevel = as.numeric(sub("^NL_", "", NL)),
      Panel = panel_title,
      Method = factor(Method, levels = method_names)
    ) %>%
    select(Panel, NoiseLevel, Power, Method)
}

# -----------------------------
# 3) files & panel titles
# -----------------------------
files <- c(
  "(a)linear_h_0.1_cchange.csv",
  "(b)log_h_0.1_cchange.csv",
  "(c)step_h_0.1_cchange.csv",
  "(d)W-shape_h_0.1_cchange.csv",
  "(e)Sinusoid_h_0.1_cchange.csv",
  "(f)Heteroscedastic_h_0.1_cchange.csv",
  "(g)Doppler_h_0.1_cchange.csv",
  "(h)Heaviside_h_0.1_cchange.csv"
)

panels <- c(
  "(a) Linear","(b) Log","(c) Step","(d) W-Shape",
  "(e) Sinusoid","(f) Heteroscedastic","(g) Doppler","(h) Heavisine"
)

df <- map2_dfr(files, panels, read_one)

# -----------------------------
# 4) one-panel plot (so each has its own axis titles)
# -----------------------------
one_panel_plot <- function(dsub, title_text){
  ggplot(dsub, aes(x = NoiseLevel, y = Power,
                   color = Method, shape = Method, group = Method)) +
    geom_line(linewidth = 0.75, linetype = "dashed") +
    geom_point(size = 1.5, stroke = 0.7, fill = "white") +  # 点更小
    scale_color_manual(values = cols, breaks = method_names) +
    scale_shape_manual(values = shapes, breaks = method_names) +
    scale_x_continuous(
      breaks = seq(0, 1, 0.25),
      labels = function(x) sprintf("%.2f", x),
      limits = c(0, 1)
    ) +
    scale_y_continuous(
      breaks = seq(0, 1, 0.25),
      labels = function(y) sprintf("%.2f", y),
      limits = c(0, 1)
    ) +
    labs(x = expression(lambda), y = "Power") +
    ggtitle(title_text) +
    theme_gray(base_size = 12) +
    theme(
      plot.title.position = "panel",
      plot.title = element_text(face = "bold", hjust = 0.5, size = 12,
                                margin = margin(t = 0, b = 6)),
      plot.background  = element_rect(fill = "white", color = NA),
      panel.background = element_rect(fill = "grey90", color = NA),
      legend.position = "none"
    )
}

# -----------------------------
# 5) build 8 plots and combine + legend outside right
# -----------------------------
plot_list <- map(panels, function(pn){
  dsub <- df %>% filter(Panel == pn)
  one_panel_plot(dsub, pn)
})

final_plot <-
  wrap_plots(plotlist = plot_list, nrow = 2) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    legend.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(6, 24, 6, 6)
  )

final_plot



###-----------------------------
### n change

# -----------------------------
# 1) settings
# -----------------------------
notMINT <- c(1,2,3)
NL <- seq(30, 100, 10)

method_names <- c('HSICskb_0.5','HSICskb_1','HSICskb_1.5')

# 颜色按你原来的：black / red / darkgreen
cols <- c(
  HSICskb_0.5 = "black",
  HSICskb_1   = "red",
  HSICskb_1.5 = "darkgreen"
)

# 3 种不同点型（和 base R 的 1:3 类似）
shapes <- c(
  HSICskb_0.5 = 1,  # hollow circle
  HSICskb_1   = 2,  # hollow triangle
  HSICskb_1.5 = 0   # hollow square
)

# -----------------------------
# 2) read & reshape helper
# -----------------------------
read_one <- function(file, panel_title){
  dat <- read.csv(file, header = TRUE)[notMINT, -1, drop = FALSE]  # 3 x 11
  colnames(dat) <- paste0("NL_", NL)
  dat$Method <- method_names
  
  dat %>%
    pivot_longer(starts_with("NL_"), names_to = "NL", values_to = "Power") %>%
    mutate(
      NoiseLevel = as.numeric(sub("^NL_", "", NL)),
      Panel = panel_title,
      Method = factor(Method, levels = method_names)
    ) %>%
    select(Panel, NoiseLevel, Power, Method)
}

# -----------------------------
# 3) files & panel titles
# -----------------------------
files <- c(
  "(a)linear_n_0.3_cchange.csv",
  "(b)log_n_0.3_cchange.csv",
  "(c)step_n_0.3_cchange.csv",
  "(d)W-shape_n_0.3_cchange.csv",
  "(e)Sinusoid_n_0.3_cchange.csv",
  "(f)Heteroscedastic_n_0.3_cchange.csv",
  "(g)Doppler_n_0.3_cchange.csv",
  "(h)Heaviside_n_0.3_cchange.csv"
)

panels <- c(
  "(a) Linear","(b) Log","(c) Step","(d) W-Shape",
  "(e) Sinusoid","(f) Heteroscedastic","(g) Doppler","(h) Heavisine"
)

df <- map2_dfr(files, panels, read_one)

# -----------------------------
# 4) one-panel plot (so each has its own axis titles)
# -----------------------------
one_panel_plot <- function(dsub, title_text){
  ggplot(dsub, aes(x = NoiseLevel, y = Power,
                   color = Method, shape = Method, group = Method)) +
    geom_line(linewidth = 0.75, linetype = "dashed") +
    geom_point(size = 1.5, stroke = 0.7, fill = "white") +  # 点更小
    scale_color_manual(values = cols, breaks = method_names) +
    scale_shape_manual(values = shapes, breaks = method_names) +
    scale_x_continuous(
      breaks = seq(40, 100, 20),
      #labels = function(x) sprintf("%.2f", x),
      limits = c(30, 100)
    ) +
    scale_y_continuous(
      breaks = seq(0, 1, 0.25),
      labels = function(y) sprintf("%.2f", y),
      limits = c(0, 1)
    ) +
    labs(x = expression(n), y = "Power") +
    ggtitle(title_text) +
    theme_gray(base_size = 12) +
    theme(
      plot.title.position = "panel",
      plot.title = element_text(face = "bold", hjust = 0.5, size = 12,
                                margin = margin(t = 0, b = 6)),
      plot.background  = element_rect(fill = "white", color = NA),
      panel.background = element_rect(fill = "grey90", color = NA),
      legend.position = "none"
    )
}

# -----------------------------
# 5) build 8 plots and combine + legend outside right
# -----------------------------
plot_list <- map(panels, function(pn){
  dsub <- df %>% filter(Panel == pn)
  one_panel_plot(dsub, pn)
})

final_plot <-
  wrap_plots(plotlist = plot_list, nrow = 2) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    legend.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(6, 24, 6, 6)
  )

final_plot


