rm(list = ls())
startTime<-Sys.time()

source('DW-ECCFIC and LY test.R')
library(doParallel)
library(foreach)
p <- 10
q <- 2
n_range <- c(100,500,1000)
XY_type <- c(1,2) ### XY_type=1: unif ; XY_type=2: norm
m <- 10000
alpha <- 0.05

for(idx_XY in XY_type){
  
  HSIC_power = matrix(0,(m*length(n_range)),4)
  
  for(idx_n in 1:length(n_range)){
    
    n <- n_range[idx_n]
    runfunc <- function(k){
      set.seed(k)
      if(idx_XY==1){
        X <- matrix(runif(n*p,-1,1),nrow = n)
        Y <- matrix(runif(n*q,-1,1),nrow = n)
      }else if(idx_XY==2){
        X <- matrix(rnorm(n*p),nrow = n)
        Y <- matrix(rnorm(n*q),nrow = n)
      }
      result_1 <- DW_ECCFIC(X,Y,kernel_family = 'gaussian',bw_Y_method = 'b_opt')
      DW_ECCFIC1 <- result_1$test_stat
      result_2 <- DW_ECCFIC(X,Y,kernel_family = 'gaussian',bw_Y_method = 'silverman')
      DW_ECCFIC2 <- result_2$test_stat
      result_3 <- DW_ECCFIC(X,Y,kernel_family = 'laplace',bw_Y_method = 'b_opt')
      DW_ECCFIC3 <- result_3$test_stat
      result_4 <- DW_ECCFIC(X,Y,kernel_family = 'laplace',bw_Y_method = 'silverman')
      DW_ECCFIC4 <- result_4$test_stat
      
      return(c(DW_ECCFIC1,DW_ECCFIC2,DW_ECCFIC3,DW_ECCFIC4))
    }
    
    cl<-makeCluster(16)
    registerDoParallel(cl)
    fin_result <- foreach(k=1:m,.combine='rbind') %dopar% {
      runfunc(k)
    }
    stopCluster(cl)
    
    HSIC_power[((idx_n-1)*m+1):(idx_n*m),] <- fin_result

  }
  
  endTime<-Sys.time()
  print(difftime(endTime,startTime, units ="mins"))
  
  if(idx_XY==1){
    write.csv(HSIC_power, "H0_unif_hist_large.csv", row.names=TRUE)
  }else if(idx_XY==2){
    write.csv(HSIC_power, "H0_norm_hist_large.csv", row.names=TRUE)
  }
  
}



##---------------------------------------
## Plot the Figure

library(ggplot2)
library(dplyr)
library(tidyr)
library(purrr)

# -----------------------------
# helper: build long data
# -----------------------------
build_long_df <- function(HSIC_power, m,
                          row_names = c('DW_ECCFIC(G1)','DW_ECCFIC(G2)','DW_ECCFIC(L1)','DW_ECCFIC(L2)'),
                          col_names = c("n = 500","n = 1000","n = 1500")) {
  
  stopifnot(ncol(HSIC_power) >= 4)
  stopifnot(nrow(HSIC_power) >= 3*m)
  
  mat <- as.matrix(HSIC_power[1:(3*m), 1:4])
  df <- as.data.frame(mat)
  colnames(df) <- row_names
  df$rep_id <- 1:nrow(df)
  
  df_long <- df %>%
    pivot_longer(cols = all_of(row_names), names_to = "Method", values_to = "Tstat") %>%
    mutate(
      N = case_when(
        rep_id <= m      ~ col_names[1],
        rep_id <= 2*m    ~ col_names[2],
        TRUE             ~ col_names[3]
      ),
      Method = factor(Method, levels = row_names),
      N = factor(N, levels = col_names)
    ) %>%
    select(Method, N, Tstat)
  
  df_long
}

# -----------------------------
# main
# -----------------------------
# 你已有 XY_type 和 m，例如：
# XY_type <- c(1,2)
# m <- 5000

row_names <- c('DW_ECCFIC(G1)','DW_ECCFIC(G2)','DW_ECCFIC(L1)','DW_ECCFIC(L2)')
col_names <- c("n = 100","n = 500","n = 1000")

for(idx_XY in XY_type){
  
  if(idx_XY == 1){
    HSIC_power <- read.csv("H0_unif_hist_large.csv", header = TRUE)[,-1]
    fig_title <- "Unif"
  } else if(idx_XY == 2){
    HSIC_power <- read.csv("H0_norm_hist_large.csv", header = TRUE)[,-1]
    fig_title <- "Norm"
  } else next
  
  df <- build_long_df(HSIC_power, m, row_names = row_names, col_names = col_names)
  
  # red normal curve
  xgrid <- seq(-4, 4, length.out = 600)
  norm_df <- data.frame(x = xgrid, y = dnorm(xgrid))
  
  p <- ggplot(df, aes(x = Tstat)) +
    geom_histogram(aes(y = after_stat(density)),
                   bins = 35, fill = "white", color = "grey55", linewidth = 0.4) +
    geom_density(color = "#1F77B4", linewidth = 0.9, adjust = 1) +
    geom_line(data = norm_df, aes(x = x, y = y),
              inherit.aes = FALSE, color = "#B22222", linewidth = 0.9) +
    
    # 行标题默认在右侧（不要 switch="y"）
    facet_grid(Method ~ N) +
    
    coord_cartesian(xlim = c(-4, 4), ylim = c(0, 0.5), expand = FALSE) +
    labs(x = NULL, y = "density", title = fig_title) +
    
    theme_gray(base_size = 12) +
    theme(
      strip.background = element_rect(fill = "grey85", color = NA),
      strip.placement = "outside",
      
      # 行标题在右侧竖排（和示例一致）
      strip.text.y.right = element_text(angle = 90),
      
      panel.spacing = unit(0.7, "lines"),
      plot.title = element_text(face = "bold", hjust = 0.5)
    )
  
  print(p)

}
