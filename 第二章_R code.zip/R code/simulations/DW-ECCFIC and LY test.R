
##----------------------------------
## DW-ECCFIC test 

## ===== helpers=====
pairwise_L1 <- function(Z) {
  Z <- as.matrix(Z)
  n <- nrow(Z); d <- ncol(Z)
  D1 <- matrix(0, n, n)
  for (j in 1:d) D1 <- D1 + abs(outer(Z[, j], Z[, j], "-"))
  D1
}

u_center <- function(K) {
  n <- nrow(K)
  diag(K) <- 0
  RowMean <- matrix(apply(K, 1, mean), nrow = n) * n/(n - 2)
  ColMean <- matrix(apply(K, 2, mean), nrow = n) * n/(n - 2)
  RowMat <- RowMean %*% matrix(rep(1, n), nrow = 1)
  ColMat <- t(ColMean %*% matrix(rep(1, n), nrow = 1))
  Kc <- K - RowMat - ColMat + mean(K) * n^2 / ((n - 1) * (n - 2))
  diag(Kc) <- 0
  Kc
}

## ===== b_opt =====
bopt_from_Y <- function(
    Y,
    remove_na = TRUE,
    L_family = c("gaussian", "laplace"),
    kde_family = c("gaussian", "laplace"),
    laplace_normalized = TRUE
) {
  Y <- as.matrix(Y)
  if (!is.numeric(Y)) stop("Y must be numeric.")
  if (remove_na) Y <- Y[stats::complete.cases(Y), , drop = FALSE]
  
  n <- nrow(Y); q <- ncol(Y)
  if (n <= 5) stop("Need n > 5.")
  if (q < 1) stop("q must be >= 1.")
  
  L_family  <- match.arg(L_family)
  kde_family <- match.arg(kde_family)
  
  ## Silverman rule-of-thumb h_n
  s <- apply(Y, 2, stats::sd)
  h_n <- (4 / (n * (q + 2)))^(1 / (q + 4)) * (sum(s) / q)
  if (!is.finite(h_n) || h_n <= 0) stop("Computed h_n is not positive/finite.")
  
  ## LOO KDE
  if (kde_family == "gaussian") {
    G <- tcrossprod(Y)
    r2 <- rowSums(Y^2)
    D2 <- outer(r2, r2, "+") - 2 * G
    D2[D2 < 0] <- 0
    const_phi <- (2 * pi)^(-q / 2)
    K <- const_phi * exp(- D2 / (2 * h_n^2))
    f_loo <- (rowSums(K) - diag(K)) / ((n - 1) * h_n^q)
  } else {
    D1 <- pairwise_L1(Y)
    const0 <- if (laplace_normalized) (1/2)^q else 1
    K <- const0 * exp(- D1 / h_n)
    f_loo <- (rowSums(K) - diag(K)) / ((n - 1) * h_n^q)
  }
  
  I2_hat <- mean(f_loo)
  I4_hat <- mean(f_loo^3)
  if (!is.finite(I2_hat) || I2_hat <= 0) stop("I2_hat not positive/finite.")
  if (!is.finite(I4_hat) || I4_hat <= 0) stop("I4_hat not positive/finite.")
  
  ## constants A1, A2
  if (L_family == "gaussian") {
    A1 <- 2^(-5 * q / 2) * pi^(-3 * q / 2)
    A2 <- 2^(-3 * q / 2) * pi^(-q / 2)
  } else {
    A1 <- (1/32)^q
    A2 <- (5/32)^q
    if (!laplace_normalized) {
      A1 <- A1 * 2^(4 * q)
      A2 <- A2 * 2^(4 * q)
    }
  }
  
  b_opt <- ((1 / n ^ 2) * (A1 * I2_hat) / (A2 * I4_hat))^(1 / (2 * q))
  
  list(b_opt = b_opt, h_n = h_n, I2_hat = I2_hat, I4_hat = I4_hat,
       A1 = A1, A2 = A2, n = n, q = q,
       L_family = L_family, kde_family = kde_family)
}

## ===== DW_ECCFIC with SAME kernel for X and Y (modified) =====
DW_ECCFIC <- function(
    X, Y,
    kernel_family = c("gaussian", "laplace"),
    laplace_normalized = TRUE,
    kde_family_for_bopt = NULL,  # default: same as kernel_family
    bw_Y_method = c("b_opt", "silverman", "manual"),
    bw_Y_manual = NULL,
    remove_na = TRUE,
    bw_scale = FALSE,
    bw_coe = 1,
    hX_scale = FALSE,
    hX_coe  = 1
){
  kernel_family <- match.arg(kernel_family)
  bw_Y_method <- match.arg(bw_Y_method)
  if (is.null(kde_family_for_bopt)) kde_family_for_bopt <- kernel_family
  
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  if (!is.numeric(X) || !is.numeric(Y)) stop("X and Y must be numeric.")
  if (nrow(X) != nrow(Y)) stop("X and Y must have the same n.")
  
  ## optional NA removal (drops rows jointly)
  if (remove_na) {
    ok <- stats::complete.cases(X) & stats::complete.cases(Y)
    X <- X[ok, , drop = FALSE]
    Y <- Y[ok, , drop = FALSE]
  }
  
  n <- nrow(X)
  if (n <= 5) stop("Need n > 5 after NA removal.")
  p <- ncol(X)
  q <- ncol(Y)
  if (q < 1) stop("q must be >= 1.")
  
  ## bandwidth for Y
  if (bw_Y_method == "b_opt") {
    tmp <- bopt_from_Y(
      Y,
      remove_na = FALSE,  # already handled
      L_family = kernel_family,
      kde_family = kde_family_for_bopt,
      laplace_normalized = laplace_normalized
    )
    bY <- ifelse(bw_scale,bw_coe*tmp$b_opt,tmp$b_opt)
    bY_info <- tmp
  } else if (bw_Y_method == "silverman") {
    sj <- apply(Y, 2, stats::sd)
    bY <- (4 / (n * (q + 2)))^(1 / (q + 4)) * (sum(sj) / q)
    bY <- ifelse(bw_scale,bw_coe*bY,bY)
    if (!is.finite(bY) || bY <= 0) stop("Silverman bandwidth for Y not positive/finite.")
    bY_info <- list(b_opt = NA_real_, h_n = bY, n = n, q = q,
                    L_family = kernel_family, kde_family = NA_character_)
  } else { # manual
    if (is.null(bw_Y_manual) || length(bw_Y_manual) != 1) stop("Provide scalar bw_Y_manual for bw_Y_method='manual'.")
    bY <- as.numeric(bw_Y_manual)
    if (!is.finite(bY) || bY <= 0) stop("Manual bandwidth for Y not positive/finite.")
    bY_info <- list(b_opt = NA_real_, h_n = NA_real_, n = n, q = q,
                    L_family = kernel_family, kde_family = NA_character_)
  }
  
  ## X bandwidth: median distance (as you did)
  if (kernel_family == "gaussian") {
    distX <- as.matrix(dist(X, diag = TRUE, upper = TRUE))
    hX <- median(distX[upper.tri(distX)])
    if (!is.finite(hX) || hX <= 0) stop("Median distance for X not positive/finite.")
    hX <- ifelse(hX_scale,hX*hX_coe,hX)
    KX <- dnorm(distX, sd = hX)
    A <- u_center(KX)
    
    distY <- as.matrix(dist(Y, diag = TRUE, upper = TRUE))
    KY <- dnorm(distY, sd = bY)
    B <- u_center(KY)
    
  } else { # laplace
    D1X <- pairwise_L1(X)
    hX <- median(D1X[upper.tri(D1X)])
    if (!is.finite(hX) || hX <= 0) stop("Median L1 distance for X not positive/finite.")
    constX <- if (laplace_normalized) (1/(2 * hX))^p else hX^(-p)
    KX <- constX * exp(- D1X / hX)
    A <- u_center(KX)
    
    D1Y <- pairwise_L1(Y)
    constY <- if (laplace_normalized) (1/(2 * bY))^q else bY^(-q)
    KY <- constY * exp(- D1Y / bY)
    B <- u_center(KY)
  }
  
  ## statistic + variance + z
  HSIC_val <- sum(A * B) / (n * (n - 3))
  sdsq <- (sum(A^2) * sum(B^2)) / (n * (n - 3))^2
  test_stat <- (sqrt(n * (n - 1) / 2) * HSIC_val) / sqrt(sdsq)
  pval <- 1 - pnorm(test_stat)
  
  list(
    DW_ECCFIC = HSIC_val,
    sd_sq = sdsq,
    test_stat = test_stat,
    pval = pval,
    kernel_family = kernel_family,
    h_X = hX,
    bw_Y_method = bw_Y_method,
    b_Y = bY,
    bY_detail = bY_info
  )
}

##----------------------------------
## LY test

HSIC_LY <- function(X,Y,h,v){## h,v are bandwidths
  n <- nrow(X)
  p <- ncol(X)
  q <- ncol(Y)
  
  distX <- as.matrix(dist(X,diag = TRUE,upper = TRUE))
  KX <- dnorm(distX,sd = h)
  diag(KX) <- 0
  RowMeanKX <- matrix(apply(KX, 1, mean),nrow = n)*n/(n-2)
  ColMeanKX <- matrix(apply(KX, 2, mean),nrow = n)*n/(n-2)
  
  RowMeanMat1 <- RowMeanKX%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat1 <- t(ColMeanKX%*%matrix(rep(1,n),nrow = 1))
  A <- KX-RowMeanMat1-ColMeanMat1+mean(KX)*n^2/((n-1)*(n-2))
  
  
  distY <- as.matrix(dist(Y,diag = TRUE,upper = TRUE))
  KY <- dnorm(distY,sd = v)
  diag(KY) <- 0
  RowMeanKY <- matrix(apply(KY, 1, mean),nrow = n)*n/(n-2)
  ColMeanKY <- matrix(apply(KY, 2, mean),nrow = n)*n/(n-2)
  
  RowMeanMat2 <- RowMeanKY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat2 <- t(ColMeanKY%*%matrix(rep(1,n),nrow = 1))
  B <- KY-RowMeanMat2-ColMeanMat2+mean(KY)*n^2/((n-1)*(n-2))
  
  diag(A) <- 0
  diag(B) <- 0
  
  SIC <- sum(A*B)/(n*(n-3))##SIC is the statistic
  sdsq <- sum(A^2)*sum(B^2)/(n*(n-3))^2 ## the variance
  test_stat <- (sqrt(n*(n-1)/2)*SIC)/sqrt(sdsq)
  pval.b <- 1-pnorm(test_stat)
  
  return(list(SIC = SIC, sd_sq = sdsq, pval.b = pval.b, test_stat = test_stat))
}
