rm(list = ls())
gc(full = TRUE)

startTime <- Sys.time()

k_now <- 4 # 1,2,3,4,5,6

library(energy)
library(IndepTest)
library(dHSIC)

source("IPC.R")
source("DW-ECCFIC and LY test.R")

big5_raw <- read.csv("data.csv", header = TRUE, sep = "\t")

#######################
## data pre-processing
#######################
age_error <- which(big5_raw$age > 90)
missing_error <- which(big5_raw == 0, arr.ind = TRUE)
total_error <- union(age_error, missing_error[, 1])
big5_data <- big5_raw[-total_error, ]

rm(big5_raw, age_error, missing_error, total_error)
gc(full = TRUE)

p1 <- 50
p2 <- 10
q  <- 1
n  <- nrow(big5_data)

h <- 0.3
v <- 0.4

## 只保存当前 k 的结果
res <- rep(NA_real_, 8)

## 构造 X, Y
if (k_now < 6) {
  nX <- (8 + 10 * (k_now - 1)):(17 + 10 * (k_now - 1))
  X <- as.matrix(big5_data[, nX, drop = FALSE], nrow = n, ncol = p2)
  Y <- as.matrix(big5_data[, 2, drop = FALSE], nrow = n, ncol = q)
} else {
  nX <- 8:57
  X <- as.matrix(big5_data[, nX, drop = FALSE], nrow = n, ncol = p1)
  Y <- as.matrix(big5_data[, 2, drop = FALSE], nrow = n, ncol = q)
}

rm(big5_data, nX)
gc(full = TRUE)

storage.mode(X) <- "double"
storage.mode(Y) <- "double"

## 1) DW-ECCFIC
tmp <- tryCatch({
  tt <- system.time({
    fit <- DW_ECCFIC_memopt(
      X, Y,
      kernel_family = "gaussian",
      bw_Y_method = "silverman",
      bw_scale = TRUE,
      bw_coe = v,
      hX_scale = TRUE,
      hX_coe = h
    )
  })["elapsed"]
  out <- c(fit$pval, as.numeric(tt))
  rm(fit, tt)
  gc(full = TRUE)
  out
}, error = function(e) {
  message("DW_ECCFIC failed: ", conditionMessage(e))
  c(NA_real_, NA_real_)
})
res[1] <- tmp[1]
res[5] <- tmp[2]
rm(tmp)
gc(full = TRUE)

## 2) LY
tmp <- tryCatch({
  tt <- system.time({
    v_n <- v * 1.06 * n^(-1/5) * sd(Y)
    h_n <- 3 * (4 / n / (ncol(X) + 2))^(1 / (ncol(X) + 4)) * mean(apply(X, 2, sd))
    fit <- LY(X, Y, h_n, v_n)
  })["elapsed"]
  out <- c(fit$pval.b, as.numeric(tt))
  rm(fit, v_n, h_n, tt)
  gc(full = TRUE)
  out
}, error = function(e) {
  message("LY failed: ", conditionMessage(e))
  c(NA_real_, NA_real_)
})
res[2] <- tmp[1]
res[6] <- tmp[2]
rm(tmp)
gc(full = TRUE)

## 3) DC
tmp <- tryCatch({
  tt <- system.time({
    fit <- dcov.test(X, Y, R = 199)
  })["elapsed"]
  out <- c(fit$p.value, as.numeric(tt))
  rm(fit, tt)
  gc(full = TRUE)
  out
}, error = function(e) {
  message("DC failed: ", conditionMessage(e))
  c(NA_real_, NA_real_)
})
res[3] <- tmp[1]
res[7] <- tmp[2]
rm(tmp)
gc(full = TRUE)

## 4) HSIC
tmp <- tryCatch({
  tt <- system.time({
    fit <- dhsic.test(X, Y, method = "bootstrap", B = 199)
  })["elapsed"]
  out <- c(fit$p.value, as.numeric(tt))
  rm(fit, tt)
  gc(full = TRUE)
  out
}, error = function(e) {
  message("dHSIC failed: ", conditionMessage(e))
  c(NA_real_, NA_real_)
})
res[4] <- tmp[1]
res[8] <- tmp[2]
rm(tmp)
gc(full = TRUE)

outmat <- matrix(res, nrow = 1)
colnames(outmat) <- c(
  "DW-ECCFIC", "LY", "DC", "HSIC",
  "DW-ECCFIC", "LY", "DC", "HSIC"
)
rownames(outmat) <- paste0("k", k_now)

print(outmat)

write.csv(outmat, paste0("case1_runtime_k", k_now, ".csv"), row.names = TRUE)

rm(X, Y, outmat, res)
gc(full = TRUE)

endTime <- Sys.time()
print(difftime(endTime, startTime, units = "mins"))