rm(list = ls())
startTime<-Sys.time()

library(energy)
library(doParallel)
library(foreach)
library(IndepTest)

big5_raw <- read.csv("data.csv",header=TRUE, sep="\t")

#######################
##data pre-processing##
#######################
age_error <- which(big5_raw$age > 90)

missing_error <- which(big5_raw==0,arr.ind = TRUE)

total_error <- union(age_error,c(missing_error[,1]))
big5_data <- big5_raw[-total_error,]

p1 <- 50 ## dimension of X
p2 <- 10 
q <- 1 ## dimension of Y
N <- nrow(big5_data) 
R <- 1000
age_range <- c(55:25)####
K <- length(age_range)*6


###########################
## Find independent age  ##
###########################
startTime<-Sys.time()

h <- 0.3
v <- 0.4

p_value<- rep(0,K)

for(k in 1:K){
  set.seed(k)
  library(energy)
  library(IndepTest)
  source("DW-ECCFIC and LY test.R")
  
  kk <- (k-1) %/% 6 + 1
  l <- k - (kk-1)*6
  age_over <- which(big5_data$age >= age_range[kk])
  big5_over <- big5_data[age_over,]
  n <- length(age_over)
  
  if(l<6){
    nX <- c((8+10*(l-1)):(17+10*(l-1)))
    X <- as.matrix(big5_over[,nX],nrow=n,ncol=p2)
    Y <- as.matrix(big5_over[,2],nrow=n,ncol=q)
  }else{
    nX <- c(8:57)
    X <- as.matrix(big5_over[,nX],nrow=n,ncol=p1)
    Y <- as.matrix(big5_over[,2],nrow=n,ncol=q)
  }
  
  ##----------------------------------
  ## DW_ECCFIC test
  result_1 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "silverman", bw_scale = TRUE, bw_coe = v,hX_scale = TRUE, hX_coe = h)
  p_value[k] <- result_1$pval
}

endTime<-Sys.time()
print(difftime(endTime,startTime, units ="mins"))
print(p_value)

write.csv(p_value, "age25_55_pvalue.csv")

