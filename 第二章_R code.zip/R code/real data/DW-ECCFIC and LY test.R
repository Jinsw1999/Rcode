
##----------------------------------
## DW-ECCFIC test (Normal Version)

## ===== helper =====
pairwise_L1 <- function(Z) {
  Z <- as.matrix(Z)
  n <- nrow(Z); d <- ncol(Z)
  D1 <- matrix(0, n, n)
  for (j in 1:d) D1 <- D1 + abs(outer(Z[, j], Z[, j], "-"))
  D1
}

u_center <- function(K) {
  n <- nrow(K)
  diag(K) <- 0
  RowMean <- matrix(apply(K, 1, mean), nrow = n) * n/(n - 2)
  ColMean <- matrix(apply(K, 2, mean), nrow = n) * n/(n - 2)
  RowMat <- RowMean %*% matrix(rep(1, n), nrow = 1)
  ColMat <- t(ColMean %*% matrix(rep(1, n), nrow = 1))
  Kc <- K - RowMat - ColMat + mean(K) * n^2 / ((n - 1) * (n - 2))
  diag(Kc) <- 0
  Kc
}

## ===== b_opt =====
bopt_from_Y <- function(
    Y,
    remove_na = TRUE,
    L_family = c("gaussian", "laplace"),
    kde_family = c("gaussian", "laplace"),
    laplace_normalized = TRUE
) {
  Y <- as.matrix(Y)
  if (!is.numeric(Y)) stop("Y must be numeric.")
  if (remove_na) Y <- Y[stats::complete.cases(Y), , drop = FALSE]
  
  n <- nrow(Y); q <- ncol(Y)
  if (n <= 5) stop("Need n > 5.")
  if (q < 1) stop("q must be >= 1.")
  
  L_family  <- match.arg(L_family)
  kde_family <- match.arg(kde_family)
  
  ## Silverman rule-of-thumb h_n  
  s <- apply(Y, 2, stats::sd)
  h_n <- (4 / (n * (q + 2)))^(1 / (q + 4)) * (sum(s) / q)
  if (!is.finite(h_n) || h_n <= 0) stop("Computed h_n is not positive/finite.")
  
  ## LOO KDE
  if (kde_family == "gaussian") {
    G <- tcrossprod(Y)
    r2 <- rowSums(Y^2)
    D2 <- outer(r2, r2, "+") - 2 * G
    D2[D2 < 0] <- 0
    const_phi <- (2 * pi)^(-q / 2)
    K <- const_phi * exp(- D2 / (2 * h_n^2))
    f_loo <- (rowSums(K) - diag(K)) / ((n - 1) * h_n^q)
  } else {
    D1 <- pairwise_L1(Y)
    const0 <- if (laplace_normalized) (1/2)^q else 1
    K <- const0 * exp(- D1 / h_n)
    f_loo <- (rowSums(K) - diag(K)) / ((n - 1) * h_n^q)
  }
  
  I2_hat <- mean(f_loo)
  I4_hat <- mean(f_loo^3)
  if (!is.finite(I2_hat) || I2_hat <= 0) stop("I2_hat not positive/finite.")
  if (!is.finite(I4_hat) || I4_hat <= 0) stop("I4_hat not positive/finite.")
  
  ## constants A1, A2
  if (L_family == "gaussian") {
    A1 <- 2^(-5 * q / 2) * pi^(-3 * q / 2)
    A2 <- 2^(-3 * q / 2) * pi^(-q / 2)
  } else {
    A1 <- (1/32)^q
    A2 <- (5/32)^q
    if (!laplace_normalized) {
      A1 <- A1 * 2^(4 * q)
      A2 <- A2 * 2^(4 * q)
    }
  }
  
  b_opt <- ((1 / n ^ 2) * (A1 * I2_hat) / (A2 * I4_hat))^(1 / (2 * q))
  
  list(b_opt = b_opt, h_n = h_n, I2_hat = I2_hat, I4_hat = I4_hat,
       A1 = A1, A2 = A2, n = n, q = q,
       L_family = L_family, kde_family = kde_family)
}

## ===== DW_ECCFIC Function =====
DW_ECCFIC <- function(
    X, Y,
    kernel_family = c("gaussian", "laplace"),
    laplace_normalized = TRUE,
    kde_family_for_bopt = NULL,  
    bw_Y_method = c("b_opt", "silverman", "manual"),
    bw_Y_manual = NULL,
    remove_na = TRUE,
    bw_scale = FALSE,
    bw_coe = 1,
    hX_scale = FALSE,
    hX_coe  = 1
){
  kernel_family <- match.arg(kernel_family)
  bw_Y_method <- match.arg(bw_Y_method)
  if (is.null(kde_family_for_bopt)) kde_family_for_bopt <- kernel_family
  
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  if (!is.numeric(X) || !is.numeric(Y)) stop("X and Y must be numeric.")
  if (nrow(X) != nrow(Y)) stop("X and Y must have the same n.")
  
  ## optional NA removal (drops rows jointly)
  if (remove_na) {
    ok <- stats::complete.cases(X) & stats::complete.cases(Y)
    X <- X[ok, , drop = FALSE]
    Y <- Y[ok, , drop = FALSE]
  }
  
  n <- nrow(X)
  if (n <= 5) stop("Need n > 5 after NA removal.")
  p <- ncol(X)
  q <- ncol(Y)
  if (q < 1) stop("q must be >= 1.")
  
  ## bandwidth for Y
  if (bw_Y_method == "b_opt") {
    tmp <- bopt_from_Y(
      Y,
      remove_na = FALSE,  # already handled
      L_family = kernel_family,
      kde_family = kde_family_for_bopt,
      laplace_normalized = laplace_normalized
    )
    bY <- ifelse(bw_scale,bw_coe*tmp$b_opt,tmp$b_opt)
    bY_info <- tmp
  } else if (bw_Y_method == "silverman") {
    sj <- apply(Y, 2, stats::sd)
    bY <- (4 / (n * (q + 2)))^(1 / (q + 4)) * (sum(sj) / q)
    bY <- ifelse(bw_scale,bw_coe*bY,bY)
    if (!is.finite(bY) || bY <= 0) stop("Silverman bandwidth for Y not positive/finite.")
    bY_info <- list(b_opt = NA_real_, h_n = bY, n = n, q = q,
                    L_family = kernel_family, kde_family = NA_character_)
  } else { # manual
    if (is.null(bw_Y_manual) || length(bw_Y_manual) != 1) stop("Provide scalar bw_Y_manual for bw_Y_method='manual'.")
    bY <- as.numeric(bw_Y_manual)
    if (!is.finite(bY) || bY <= 0) stop("Manual bandwidth for Y not positive/finite.")
    bY_info <- list(b_opt = NA_real_, h_n = NA_real_, n = n, q = q,
                    L_family = kernel_family, kde_family = NA_character_)
  }
  
  ## X bandwidth: median distance (as you did)
  if (kernel_family == "gaussian") {
    distX <- as.matrix(dist(X, diag = TRUE, upper = TRUE))
    hX <- median(distX[upper.tri(distX)])
    if (!is.finite(hX) || hX <= 0) stop("Median distance for X not positive/finite.")
    hX <- ifelse(hX_scale,hX*hX_coe,hX)
    KX <- dnorm(distX, sd = hX)
    A <- u_center(KX)
    
    distY <- as.matrix(dist(Y, diag = TRUE, upper = TRUE))
    KY <- dnorm(distY, sd = bY)
    B <- u_center(KY)
    
  } else { # laplace
    D1X <- pairwise_L1(X)
    hX <- median(D1X[upper.tri(D1X)])
    if (!is.finite(hX) || hX <= 0) stop("Median L1 distance for X not positive/finite.")
    constX <- if (laplace_normalized) (1/(2 * hX))^p else hX^(-p)
    KX <- constX * exp(- D1X / hX)
    A <- u_center(KX)
    
    D1Y <- pairwise_L1(Y)
    constY <- if (laplace_normalized) (1/(2 * bY))^q else bY^(-q)
    KY <- constY * exp(- D1Y / bY)
    B <- u_center(KY)
  }
  
  ## statistic + variance + z
  HSIC_val <- sum(A * B) / (n * (n - 3))
  sdsq <- (sum(A^2) * sum(B^2)) / (n * (n - 3))^2
  test_stat <- (sqrt(n * (n - 1) / 2) * HSIC_val) / sqrt(sdsq)
  pval <- 1 - pnorm(test_stat)
  
  list(
    DW_ECCFIC = HSIC_val,
    sd_sq = sdsq,
    test_stat = test_stat,
    pval = pval,
    kernel_family = kernel_family,
    h_X = hX,
    bw_Y_method = bw_Y_method,
    b_Y = bY,
    bY_detail = bY_info
  )
}


##----------------------------------
## DW-ECCFIC test (Memory-efficient version)

## ===== low-memory U-centering =====
u_center_fast <- function(K) {
  n <- nrow(K)
  diag(K) <- 0
  
  ## For a symmetric kernel matrix, row and column means are identical
  m <- rowMeans(K) * n / (n - 2)
  grand_mean <- mean(K) * n^2 / ((n - 1) * (n - 2))
  
  ## Avoid explicitly creating two extra n x n matrices
  K <- sweep(K, 1, m, "-")
  K <- sweep(K, 2, m, "-")
  K <- K + grand_mean
  
  diag(K) <- 0
  K
}

## ===== memory-optimized DW-ECCFIC function =====
DW_ECCFIC_memopt <- function(
    X, Y,
    kernel_family = c("gaussian", "laplace"),
    laplace_normalized = TRUE,
    kde_family_for_bopt = NULL,
    bw_Y_method = c("b_opt", "silverman", "manual"),
    bw_Y_manual = NULL,
    remove_na = TRUE,
    bw_scale = FALSE,
    bw_coe = 1,
    hX_scale = FALSE,
    hX_coe = 1
) {
  kernel_family <- match.arg(kernel_family)
  bw_Y_method <- match.arg(bw_Y_method)
  if (is.null(kde_family_for_bopt)) kde_family_for_bopt <- kernel_family
  
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  if (!is.numeric(X) || !is.numeric(Y)) stop("X and Y must be numeric.")
  if (nrow(X) != nrow(Y)) stop("X and Y must have the same sample size.")
  
  ## Joint NA removal
  if (remove_na) {
    ok <- stats::complete.cases(X) & stats::complete.cases(Y)
    X <- X[ok, , drop = FALSE]
    Y <- Y[ok, , drop = FALSE]
  }
  
  n <- nrow(X)
  p <- ncol(X)
  q <- ncol(Y)
  
  if (n <= 5) stop("Need n > 5 after NA removal.")
  if (q < 1) stop("q must be >= 1.")
  
  ## Bandwidth for Y
  if (bw_Y_method == "b_opt") {
    tmp <- bopt_from_Y(
      Y,
      remove_na = FALSE,
      L_family = kernel_family,
      kde_family = kde_family_for_bopt,
      laplace_normalized = laplace_normalized
    )
    bY <- if (bw_scale) bw_coe * tmp$b_opt else tmp$b_opt
    bY_info <- tmp
    
  } else if (bw_Y_method == "silverman") {
    sj <- apply(Y, 2, stats::sd)
    bY <- (4 / (n * (q + 2)))^(1 / (q + 4)) * (sum(sj) / q)
    bY <- if (bw_scale) bw_coe * bY else bY
    if (!is.finite(bY) || bY <= 0) stop("Silverman bandwidth for Y not positive/finite.")
    bY_info <- list(
      b_opt = NA_real_,
      h_n = bY,
      n = n,
      q = q,
      L_family = kernel_family,
      kde_family = NA_character_
    )
    
  } else {
    if (is.null(bw_Y_manual) || length(bw_Y_manual) != 1) {
      stop("Provide scalar bw_Y_manual when bw_Y_method = 'manual'.")
    }
    bY <- as.numeric(bw_Y_manual)
    if (!is.finite(bY) || bY <= 0) stop("Manual bandwidth for Y not positive/finite.")
    bY_info <- list(
      b_opt = NA_real_,
      h_n = NA_real_,
      n = n,
      q = q,
      L_family = kernel_family,
      kde_family = NA_character_
    )
  }
  
  if (kernel_family == "gaussian") {
    
    ## Compute compact Euclidean distances for X first
    distX_obj <- stats::dist(X, method = "euclidean")
    hX <- stats::median(distX_obj)
    if (!is.finite(hX) || hX <= 0) stop("Median distance for X not positive/finite.")
    hX <- if (hX_scale) hX * hX_coe else hX
    
    ## Convert to full matrix only when needed
    distX <- as.matrix(distX_obj)
    rm(distX_obj)
    gc(verbose = FALSE)
    
    ## Build kernel matrix for X
    KX <- dnorm(distX, sd = hX)
    rm(distX)
    gc(verbose = FALSE)
    
    ## Center X-kernel and immediately remove the uncentered matrix
    A <- u_center_fast(KX)
    rm(KX)
    gc(verbose = FALSE)
    
    ## Compute compact Euclidean distances for Y
    distY_obj <- stats::dist(Y, method = "euclidean")
    distY <- as.matrix(distY_obj)
    rm(distY_obj)
    gc(verbose = FALSE)
    
    ## Build kernel matrix for Y
    KY <- dnorm(distY, sd = bY)
    rm(distY)
    gc(verbose = FALSE)
    
    ## Center Y-kernel and immediately remove the uncentered matrix
    B <- u_center_fast(KY)
    rm(KY)
    gc(verbose = FALSE)
    
  } else {
    ## Laplace branch
    D1X <- pairwise_L1(X)
    hX <- stats::median(D1X[upper.tri(D1X)])
    if (!is.finite(hX) || hX <= 0) stop("Median L1 distance for X not positive/finite.")
    hX <- if (hX_scale) hX * hX_coe else hX
    constX <- if (laplace_normalized) (1 / (2 * hX))^p else hX^(-p)
    KX <- constX * exp(-D1X / hX)
    rm(D1X)
    gc(verbose = FALSE)
    
    A <- u_center_fast(KX)
    rm(KX)
    gc(verbose = FALSE)
    
    D1Y <- pairwise_L1(Y)
    constY <- if (laplace_normalized) (1 / (2 * bY))^q else bY^(-q)
    KY <- constY * exp(-D1Y / bY)
    rm(D1Y)
    gc(verbose = FALSE)
    
    B <- u_center_fast(KY)
    rm(KY)
    gc(verbose = FALSE)
  }
  
  ## Compute the statistic
  HSIC_val <- sum(A * B) / (n * (n - 3))
  sdsq <- (sum(A^2) * sum(B^2)) / (n * (n - 3))^2
  test_stat <- (sqrt(n * (n - 1) / 2) * HSIC_val) / sqrt(sdsq)
  pval <- 1 - pnorm(test_stat)
  
  ## Remove large matrices before returning
  rm(A, B)
  gc(verbose = FALSE)
  
  list(
    HSICskb = HSIC_val,
    sd_sq = sdsq,
    test_stat = test_stat,
    pval = pval,
    kernel_family = kernel_family,
    h_X = hX,
    bw_Y_method = bw_Y_method,
    b_Y = bY,
    bY_detail = bY_info
  )
}



##----------------------------------
## LY test (Normal version)

HSIC_LY <- function(X,Y,h,v){## h,v are bandwidths
  n <- nrow(X)
  p <- ncol(X)
  q <- ncol(Y)
  
  distX <- as.matrix(dist(X,diag = TRUE,upper = TRUE))
  KX <- dnorm(distX,sd = h)
  diag(KX) <- 0
  RowMeanKX <- matrix(apply(KX, 1, mean),nrow = n)*n/(n-2)
  ColMeanKX <- matrix(apply(KX, 2, mean),nrow = n)*n/(n-2)
  
  RowMeanMat1 <- RowMeanKX%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat1 <- t(ColMeanKX%*%matrix(rep(1,n),nrow = 1))
  A <- KX-RowMeanMat1-ColMeanMat1+mean(KX)*n^2/((n-1)*(n-2))
  
  
  distY <- as.matrix(dist(Y,diag = TRUE,upper = TRUE))
  KY <- dnorm(distY,sd = v)
  diag(KY) <- 0
  RowMeanKY <- matrix(apply(KY, 1, mean),nrow = n)*n/(n-2)
  ColMeanKY <- matrix(apply(KY, 2, mean),nrow = n)*n/(n-2)
  
  RowMeanMat2 <- RowMeanKY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat2 <- t(ColMeanKY%*%matrix(rep(1,n),nrow = 1))
  B <- KY-RowMeanMat2-ColMeanMat2+mean(KY)*n^2/((n-1)*(n-2))
  
  diag(A) <- 0
  diag(B) <- 0
  
  SIC <- sum(A*B)/(n*(n-3))##SIC is the statistic
  sdsq <- sum(A^2)*sum(B^2)/(n*(n-3))^2 ## the variance
  test_stat <- (sqrt(n*(n-1)/2)*SIC)/sqrt(sdsq)
  pval.b <- 1-pnorm(test_stat)
  
  return(list(SIC = SIC, sd_sq = sdsq, pval.b = pval.b, test_stat = test_stat))
}
##----------------------------------




##----------------------------------
## LY test (Memory-efficient version)

LY <- function(X, Y, h, v, block_size = 300, verbose = FALSE) {
  ## Memory-efficient block implementation of HSIC_LY

  stopifnot(is.matrix(X), is.matrix(Y))
  n <- nrow(X)
  p <- ncol(X)
  q <- ncol(Y)
  if (n != nrow(Y)) stop("X and Y must have the same number of rows.")
  if (n < 4) stop("Need n >= 4 for n*(n-3) in denominator.")
  if (!is.numeric(h) || h <= 0) stop("h must be positive.")
  if (!is.numeric(v) || v <= 0) stop("v must be positive.")
  
  ## precompute squared norms
  X_norm <- rowSums(X^2)
  Y_norm <- rowSums(Y^2)
  
  ## -------- Pass 1: compute row sums and total sums of KX and KY (diag set to 0) --------
  rowSumX <- numeric(n)
  rowSumY <- numeric(n)
  totalSumX <- 0
  totalSumY <- 0
  
  idx_list <- split(seq_len(n), ceiling(seq_len(n) / block_size))
  
  for (b in seq_along(idx_list)) {
    idx <- idx_list[[b]]
    nb <- length(idx)
    if (verbose) message(sprintf("Pass 1 block %d / %d (rows %d-%d)", b, length(idx_list), idx[1], idx[nb]))
    
    ## X block distances via ||xi||^2 + ||xj||^2 - 2 xi^T xj
    GX <- X[idx, , drop = FALSE] %*% t(X)                  # nb x n
    D2X <- matrix(X_norm[idx], nrow = nb, ncol = n) +
      matrix(X_norm,      nrow = nb, ncol = n, byrow = TRUE) -
      2 * GX
    D2X[D2X < 0] <- 0
    KXb <- dnorm(sqrt(D2X), sd = h)                        # nb x n
    
    ## set diagonal entries to 0 for rows in idx
    KXb[cbind(seq_len(nb), idx)] <- 0
    
    rowSumX[idx] <- rowSums(KXb)
    totalSumX <- totalSumX + sum(KXb)
    
    ## Y block
    GY <- Y[idx, , drop = FALSE] %*% t(Y)
    D2Y <- matrix(Y_norm[idx], nrow = nb, ncol = n) +
      matrix(Y_norm,      nrow = nb, ncol = n, byrow = TRUE) -
      2 * GY
    D2Y[D2Y < 0] <- 0
    KYb <- dnorm(sqrt(D2Y), sd = v)
    
    KYb[cbind(seq_len(nb), idx)] <- 0
    
    rowSumY[idx] <- rowSums(KYb)
    totalSumY <- totalSumY + sum(KYb)
    
    ## free block temporaries early
    rm(GX, D2X, KXb, GY, D2Y, KYb)
    invisible(gc())
  }
  
  ## row/col mean vectors after your scaling
  rX <- rowSumX / (n - 2)  # equals mean(row)*n/(n-2) since mean(row)=rowSum/n
  rY <- rowSumY / (n - 2)
  
  ## constant terms in your A,B
  cX <- totalSumX / ((n - 1) * (n - 2))  # mean(KX)*n^2/((n-1)(n-2)) with mean=totalSum/n^2
  cY <- totalSumY / ((n - 1) * (n - 2))
  
  ## -------- Pass 2: accumulate sums for SIC, sum(A^2), sum(B^2) without storing full A,B --------
  sumAB <- 0
  sumA2 <- 0
  sumB2 <- 0
  
  for (b in seq_along(idx_list)) {
    idx <- idx_list[[b]]
    nb <- length(idx)
    if (verbose) message(sprintf("Pass 2 block %d / %d (rows %d-%d)", b, length(idx_list), idx[1], idx[nb]))
    
    ## recompute kernel blocks
    GX <- X[idx, , drop = FALSE] %*% t(X)
    D2X <- matrix(X_norm[idx], nrow = nb, ncol = n) +
      matrix(X_norm,      nrow = nb, ncol = n, byrow = TRUE) -
      2 * GX
    D2X[D2X < 0] <- 0
    KXb <- dnorm(sqrt(D2X), sd = h)
    KXb[cbind(seq_len(nb), idx)] <- 0
    
    GY <- Y[idx, , drop = FALSE] %*% t(Y)
    D2Y <- matrix(Y_norm[idx], nrow = nb, ncol = n) +
      matrix(Y_norm,      nrow = nb, ncol = n, byrow = TRUE) -
      2 * GY
    D2Y[D2Y < 0] <- 0
    KYb <- dnorm(sqrt(D2Y), sd = v)
    KYb[cbind(seq_len(nb), idx)] <- 0
    
    ## center in-place using vectors, avoiding RowMeanMat/ColMeanMat
    ## A = KX - rX[idx] (row) - rX (col) + cX
    A <- KXb
    A <- sweep(A, 1, rX[idx], FUN = "-")
    A <- sweep(A, 2, rX,       FUN = "-")
    A <- A + cX
    
    ## B = KY - rY[idx] - rY + cY
    B <- KYb
    B <- sweep(B, 1, rY[idx], FUN = "-")
    B <- sweep(B, 2, rY,       FUN = "-")
    B <- B + cY
    
    ## diag already 0 by construction above (A,B diagonal entries are 0 as well after centering? 
    ## Your original sets diag(A)=diag(B)=0 after centering.
    ## We enforce exactly that now:
    A[cbind(seq_len(nb), idx)] <- 0
    B[cbind(seq_len(nb), idx)] <- 0
    
    sumAB <- sumAB + sum(A * B)
    sumA2 <- sumA2 + sum(A * A)
    sumB2 <- sumB2 + sum(B * B)
    
    rm(GX, D2X, KXb, GY, D2Y, KYb, A, B)
    invisible(gc())
  }
  
  SIC  <- sumAB / (n * (n - 3))
  sdsq <- (sumA2 * sumB2) / (n * (n - 3))^2
  
  test_stat <- (sqrt(n * (n - 1) / 2) * SIC) / sqrt(sdsq)
  pval.b <- 1 - pnorm(test_stat)
  
  return(list(SIC = SIC, sd_sq = sdsq, pval.b = pval.b, test_stat = test_stat))
}
