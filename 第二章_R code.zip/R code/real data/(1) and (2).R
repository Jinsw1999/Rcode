rm(list = ls())
startTime<-Sys.time()

library(energy)
library(doParallel)
library(foreach)
library(IndepTest)

big5_raw <- read.csv("data.csv",header=TRUE, sep="\t")

#######################
##data pre-processing##
#######################

age_error <- which(big5_raw$age > 90)
missing_error <- which(big5_raw==0,arr.ind = TRUE)
total_error <- union(age_error,c(missing_error[,1]))
big5_data <- big5_raw[-total_error,]

p1 <- 50 ## dimension of X
p2 <- 10 
q <- 1 ## dimension of Y
N <- nrow(big5_data) 

#######################################
## (1): Sampling in the whole dataset##
#######################################
n <- 500 
M <- 100
h <- 0.3
v <- 0.4

DW_ECCFIC_pvalue1 = HSIC_LY_pvalue = DC_pvalue = HSIC_pvalue = HHG_pvalue = IPC_pvalue = rep(0,1)

runfunc1 <- function(k){
  set.seed(k)
  library(energy)
  library(dHSIC)
  library(HHG)
  library(IndepTest)
  source('IPC.R')
  source("DW-ECCFIC and LY test.R")
  
  row_sample <- sample(1:N,size=n)
  X <- as.matrix(big5_data[row_sample,8:57],nrow=n,ncol=p1)
  Y <- as.matrix(big5_data[row_sample,2],nrow=n,ncol=q)
  
  ##----------------------------------
  ## DW_ECCFIC test
  result_1 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "silverman", bw_scale = TRUE, bw_coe = v,hX_scale = TRUE, hX_coe = h)
  DW_ECCFIC1 <- result_1$pval
  ##----------------------------------
  ## HSIC_LY test
  v_n <- v*1.06*n^(-1/5)*sd(Y)
  h_n <- 3*(4/n/(p1+2))^(1/(p1+4))*mean(apply(X,2,sd))
  result2 <- HSIC_LY(X,Y,h_n,v_n)
  HSIC_LY_p_value<- result2$pval.b
  ##-----------------------------------
  ## DC test
  DC <- dcov.test(X,Y,R=199)
  ##--------------------------------------
  ## HSIC test
  HSIC <- dhsic.test(X,Y,method="bootstrap",B=199)
  ##--------------------------------------
  ## HHG test
  distX <- as.matrix(dist(X,diag = TRUE,upper = TRUE))
  distY <- as.matrix(dist(Y,diag = TRUE,upper = TRUE))
  hhg <- HHG::hhg.test(distX,distY,nr.perm = 199)
  ##---------------------------------------
  ## IPC test
  IPC_p_value <- IPC.test(X,Y,B=199) 
  ##-----------------------------------
  return(c(DC$p.value,HSIC$p.value,hhg$perm.pval.hhg.sc,IPC_p_value,HSIC_LY_p_value,DW_ECCFIC1))
}

cl<-makeCluster(16)
registerDoParallel(cl)
kdcovresult <- foreach(k=1:M,.combine='rbind') %dopar% {
  runfunc1(k)
}
stopCluster(cl)

colnames(kdcovresult)<-c("DC","HSIC","HHG","IPC","HSIC_LY","DW_ECCFIC")
print(kdcovresult)

DC_pvalue <- mean(kdcovresult[,1])
HSIC_pvalue <- mean(kdcovresult[,2])
HHG_pvalue <- mean(kdcovresult[,3])
IPC_pvalue <- mean(kdcovresult[,4])
HSIC_LY_pvalue <- mean(kdcovresult[,5])
DW_ECCFIC_pvalue1 <- mean(kdcovresult[,6])

pvalue_case1 <- cbind(DW_ECCFIC_pvalue1,HSIC_LY_pvalue,HSIC_pvalue,DC_pvalue,HHG_pvalue,IPC_pvalue)
print(pvalue_case1)
kdcovresult1 <- pvalue_case1
colnames(kdcovresult1)<-c("DW_ECCFIC","HSIC_LY","HSIC","DC","HHG","IPC")

endTime<-Sys.time()
print(difftime(endTime,startTime, units ="mins"))

write.csv(kdcovresult, "case1_pvalue_h_10pq.csv")
write.csv(pvalue_case1, "case1_mean_h_10pq.csv")


#####################
## (2) : age >= 50 ##
#####################

startTime<-Sys.time()

age_over50 <- which(big5_data$age >= 50)
big5_over50 <- big5_data[age_over50,]
n <- length(age_over50)
h <- 0.3
v <- 0.4

runfunc3 <- function(k){
  set.seed(k)
  library(energy)
  library(dHSIC)
  library(HHG)
  library(IndepTest)
  source('IPC.R')
  source("DW-ECCFIC and LY test.R")
  
  if(k < 6){
    nX <- c((8+10*(k-1)):(17+10*(k-1)))
    X <- as.matrix(big5_over50[,nX],nrow=n,ncol=p2)
    Y <- as.matrix(big5_over50[,2],nrow=n,ncol=q)
    
    ## DW_ECCFIC test
    result_1 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "silverman", bw_scale = TRUE, bw_coe = v,hX_scale = TRUE, hX_coe = h)
    DW_ECCFIC1 <- result_1$pval
    ##----------------------------------
    ## HSIC_LY test
    v_n <- v*1.06*n^(-1/5)*sd(Y)
    h_n <- 3*(4/n/(p2+2))^(1/(p2+4))*mean(apply(X,2,sd))
    result3 <- HSIC_LY(X,Y,h_n,v_n)
    HSIC_LY_p_value2<- result3$pval.b
    ##----------------------------------
    ## DC test
    DC <- dcov.test(X,Y,R=199)
    DC_p_value2 <- DC$p.value
    ##--------------------------------------
    ## HSIC test
    HSIC <- dhsic.test(X,Y,method="bootstrap",B=199)
    HSIC_p_value2 <- HSIC$p.value
    ##--------------------------------------
    ## HHG test
    distX <- as.matrix(dist(X,diag = TRUE,upper = TRUE))
    distY <- as.matrix(dist(Y,diag = TRUE,upper = TRUE))
    hhg <- HHG::hhg.test(distX,distY,nr.perm = 199)
    HHG_p_value2 <- hhg$perm.pval.hhg.sc
    ##---------------------------------------
    ## IPC test
    IPC_p_value2 <- IPC.test(X,Y,B=199) 
    ##-----------------------------------
    result_2 <- c(DW_ECCFIC1,HSIC_LY_p_value2,HSIC_p_value2,DC_p_value2,HHG_p_value2,IPC_p_value2)
    return(result_2)
  }else{
    nX <- c(8:57)
    X <- as.matrix(big5_over50[,nX],nrow=n,ncol=p1)
    Y <- as.matrix(big5_over50[,2],nrow=n,ncol=q)
    ##----------------------------------
    ## DW_ECCFIC test
    result_1 <- DW_ECCFIC(X,Y,kernel_family = "gaussian",bw_Y_method = "silverman", bw_scale = TRUE, bw_coe = v,hX_scale = TRUE, hX_coe = h)
    DW_ECCFIC1 <- result_1$pval
    ##----------------------------------
    ## HSIC_LY test
    v_n <- v*1.06*n^(-1/5)*sd(Y)
    h_n <- 3*(4/n/(p1+2))^(1/(p1+4))*mean(apply(X,2,sd))
    result3 <- HSIC_LY(X,Y,h_n,v_n)
    HSIC_LY_p_value2<- result3$pval.b
    ##-----------------------------------
    ## DC test
    DC <- dcov.test(X,Y,R=199)
    DC_p_value2 <- DC$p.value
    ##--------------------------------------
    ## HSIC test
    HSIC <- dhsic.test(X,Y,method="bootstrap",B=199)
    HSIC_p_value2 <- HSIC$p.value
    ##--------------------------------------
    ## HHG test
    distX <- as.matrix(dist(X,diag = TRUE,upper = TRUE))
    distY <- as.matrix(dist(Y,diag = TRUE,upper = TRUE))
    hhg <- HHG::hhg.test(distX,distY,nr.perm = 199)
    HHG_p_value2 <- hhg$perm.pval.hhg.sc
    ##---------------------------------------
    ## IPC test
    IPC_p_value2 <- IPC.test(X,Y,B=199) 
    ##-----------------------------------
    result_2 <- c(DW_ECCFIC1,HSIC_LY_p_value2,HSIC_p_value2,DC_p_value2,HHG_p_value2,IPC_p_value2)
    return(result_2)
  }
  
}

cl<-makeCluster(6)
registerDoParallel(cl)
kdcovresult <- foreach(k=1:6,.combine='rbind') %dopar% {
  runfunc3(k)
}
stopCluster(cl)

pvalue_case3 <- kdcovresult
colnames(pvalue_case3) <-c("DW_ECCFIC","HSIC_LY","HSIC","DC","HHG","IPC")

endTime<-Sys.time()
print(difftime(endTime,startTime, units ="mins"))
print(pvalue_case3)

write.csv(pvalue_case3, "case_2_h_10pq.csv") 






