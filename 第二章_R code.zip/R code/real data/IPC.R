## Implementing the Improved Projection variance test
IPC <- function(X,Y){
  p <- ncol(X)
  q <- ncol(Y)
  n <- nrow(Y)
  sigmay <- median(apply(Y^2,1,sum))
  sigmax <- median(apply(X^2,1,sum))
  Y <- cbind(rep(sqrt(sigmay),n),Y)
  Y <- t(scale(t(Y),center = FALSE))/sqrt(q)
  CroY <- Y%*%t(Y)
  CroY <- ifelse(CroY>1,1,CroY)
  CroY <- ifelse(CroY< -1,-1,CroY)
  BY <- acos(CroY)
  diag(BY) <- 0
  RowMeanBY <- matrix(apply(BY, 1, mean),nrow = n)*n/(n-2)
  ColMeanBY <- matrix(apply(BY, 2, mean),nrow = n)*n/(n-2)
  RowMeanMat <- RowMeanBY%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat <- t(ColMeanBY%*%matrix(rep(1,n),nrow = 1))
  B <- BY-RowMeanMat-ColMeanMat+mean(BY)*n^2/((n-1)*(n-2))
  
  X <- cbind(rep(sqrt(sigmax),n),X)
  X <- t(scale(t(X),center = FALSE))/sqrt(p)
  CroX <- X%*%t(X)
  CroX <- ifelse(CroX>1,1,CroX)
  CroX <- ifelse(CroX< -1,-1,CroX)
  AX <- acos(CroX)
  diag(AX) <- 0
  RowMeanAX <- matrix(apply(AX, 1, mean),nrow = n)*n/(n-2)
  ColMeanAX <- matrix(apply(AX, 2, mean),nrow = n)*n/(n-2)
  RowMeanMat <- RowMeanAX%*%matrix(rep(1,n),nrow = 1)
  ColMeanMat <- t(ColMeanAX%*%matrix(rep(1,n),nrow = 1))
  A <- AX-RowMeanMat-ColMeanMat+mean(AX)*n^2/((n-1)*(n-2))
  
  IPC <- sum(A*B)/(n*(n-3))
  return(IPC)
}

IPC.test <- function(X,Y,B){
  IPC_stat <- IPC(X,Y)
  IPC_perm <- rep(0,B)
  n <- nrow(Y)
  for (j in 1:(B)) {
    Y_per <- as.matrix(Y[sample(1:n,n),])
    IPC_perm[j] <- IPC(X,Y_per)
  }
  pval <- (1+length(which(IPC_perm>IPC_stat)))/(B+1)
  return(pval)
}

# library(dcov)
# pcov.test <- function(X,Y,B){
#   PCOV_stat <- pcov(X,Y)
#   PCOV_perm <- rep(0,B)
#   n <- nrow(Y)
#   for (j in 1:B) {
#     Y_per <- as.matrix(Y[sample(1:n,n),])
#     PCOV_perm[j] <- pcov(X,Y_per)
#   }
#   pval <- (1+length(which(PCOV_perm>PCOV_stat)))/(B+1)
#   return(pval)
# }